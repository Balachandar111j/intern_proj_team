# Data and model

## Why OULAD

The Open University Learning Analytics Dataset has the kind of data a college LMS actually records:

- About 32k students across 7 modules and 4 course presentations (2013–2014).
- Dated assessments: tutor-marked (TMA), computer-marked (CMA) and exams.
- Daily clicks on the virtual learning environment (around 10 million rows).
- Final results: Pass, Distinction, Fail or Withdrawn.

That lets the model use **only features the app also stores**. The UCI Student Performance dataset would have trained on parental education and lifestyle columns the app never collects.

## Prediction task

- **When:** day 90 of a presentation (`PREDICTION_DAY`, configurable).
- **Who:** students registered and not yet withdrawn on that day.
- **Target:** `at_risk = 1` if the final result is Fail or Withdrawn.
- **Inputs:** only records dated on or before day 90. A unit test adds future rows and checks the features don't change.

## Feature contract (`app/ml/features.py`)

| Feature | Meaning |
|---|---|
| `n_due`, `submit_rate` | Assessments due so far, and the share submitted |
| `avg_score`, `min_score`, `last_score` | Scores of submissions so far |
| `late_rate` | Share of submissions after the due day |
| `total_clicks`, `active_days` | Platform activity so far |
| `clicks_last_14`, `click_trend` | Recent activity, and its change versus the two weeks before |
| `days_since_last_active` | Recency of activity |
| `pre_start_clicks`, `registration_lead` | Preparation before the course started |
| `prev_attempts`, `studied_credits` | Prior attempts, and workload |

- **Not inputs:** gender, age band, disability, deprivation band (IMD), region and education. They are used only to audit errors by group.
- **One function for both paths:**
  - The same function builds features from the OULAD CSVs for training and from MySQL for serving.
  - `test_db_features_match_dataset_features` checks the two paths agree on every student.

## Training and selection (`app/ml/train.py`)

- **Temporal split:**
  - train on 2013B and 2013J
  - validate on 2014B
  - test once on 2014J
- **Candidates:**
  - no-skill baseline
  - logistic regression (log-scaled counts, standardised)
  - random forest
  - XGBoost
- **Selection:** the deployable model with the best validation ROC-AUC. Random forest is reported for comparison.
- **Calibration:** Platt scaling on validation, so 30% means about 30%.
- **Thresholds, set on validation:**
  - high = the best F1
  - medium = the highest threshold that still catches 85% of at-risk students
- **Explanations:** exact SHAP values, with no `shap` dependency at runtime.
  - XGBoost uses its built-in TreeSHAP.
  - Logistic regression uses coefficient × standardised value.
- **Outputs:** `model.joblib`, `metadata.json` (all metrics), `model_card.md`, `feature_importance.png` and `validation_report.json`.

## The app's students

- `export_seed` samples students from presentations the model never trained on (default: DDD-2014J and FFF-2014J).
- It exports only records up to the prediction day, so the app genuinely runs "as of day 90".
- Final results go into `enrollment_outcomes`. The admin backtest compares live flags with them.

## Topic mastery and recommendations

- **Mapping:** assessments are mapped to curriculum topics in date order (`app/seed/curriculum.py`).
- **Mastery:**
  - Mastery is the recency-weighted mean score. Later work counts more.
  - Missed assessments are shown as "Not submitted", never silently scored as zero.
- **Recommendations:**
  - Candidates come from topics that need work, plus the next upcoming topic.
  - They are ranked by need, prerequisite bonus, difficulty fit, length, risk urgency and past feedback, with at most 2 per topic and 2 tutor quizzes.
  - Each one is stored with a plain-language reason.

## Retraining on real data

```bash
python -m app.ml.prepare_real --zip ~/Downloads/anonymisedData.zip
```

Then report the numbers from `backend/artifacts/risk_model/model_card.md`.
