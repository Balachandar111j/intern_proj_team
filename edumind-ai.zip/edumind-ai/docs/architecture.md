# Architecture

## Request flow (student opens the dashboard)

1. React calls `GET /api/v1/students/me/dashboard`. The browser sends the HttpOnly session cookie.
2. `get_current_student` decodes the JWT, loads the user, and checks the role and profile.
3. Services read **source records** (assessments, results, daily engagement) and the **latest stored prediction**.
4. The response includes the risk level, the calibrated probability, the SHAP reason codes and the KPIs.

Predictions are produced by a **batch scoring job**, not on every page view:

- The scoring job runs at seed time or from Admin > Rescore.
- It is the usual production pattern for risk models: cheap reads, reproducible outputs, an audit trail.

## Layers

| Layer | Code | Notes |
|---|---|---|
| API | `app/api/v1/endpoints` | Thin handlers, Pydantic schemas, ownership checks |
| Auth | `app/core/security.py`, `deps.py` | Argon2 hashes; JWT in an HttpOnly, SameSite=Lax cookie (Secure in production); a CSRF header is required on writes; bearer tokens for API clients |
| Services | `app/services` | Analytics, mastery, recommendations, predictions, audit |
| ML | `app/ml` | Loader + validation, shared features, training, calibrated model with SHAP |
| Tutor | `app/rag` | Providers (OpenAI / offline), ingestion, Chroma store, LangGraph workflow |
| Data | `app/models`, `migrations` | 23 MySQL tables, CHECK constraints for enums, Alembic migrations |

## Database (main tables)

```mermaid
erDiagram
  users ||--o| student_profiles : has
  users ||--o| faculty_profiles : has
  faculty_profiles ||--o{ faculty_courses : teaches
  courses ||--o{ faculty_courses : ""
  student_profiles ||--o{ enrollments : ""
  courses ||--o{ enrollments : ""
  enrollments ||--o| enrollment_outcomes : "final result (evaluation only)"
  courses ||--o{ topics : ""
  topics ||--o{ topic_prerequisites : ""
  courses ||--o{ assessments : ""
  assessments ||--o{ assessment_topics : ""
  topics ||--o{ assessment_topics : ""
  student_profiles ||--o{ assessment_results : ""
  assessments ||--o{ assessment_results : ""
  student_profiles ||--o{ engagement_daily : ""
  model_versions ||--o{ predictions : ""
  student_profiles ||--o{ predictions : ""
  predictions ||--o{ risk_reviews : "faculty decision"
  topics ||--o{ learning_resources : ""
  learning_resources ||--o{ recommendations : ""
  student_profiles ||--o{ recommendations : ""
  users ||--o{ documents : owns
  documents ||--o{ document_chunks : "text + embedding"
  users ||--o{ chat_sessions : ""
  chat_sessions ||--o{ chat_messages : ""
  users ||--o{ audit_logs : actor
```

Rules the schema follows:

- **Source and derived data stay apart.**
  - Source records live in their own tables.
  - Derived outputs live in `predictions`, `recommendations` and `topic` mastery, which is computed rather than stored.
- **Every prediction is traceable.** It stores the model version, the as-of day, the feature snapshot and the explanation.
- **Final results are kept separately** (`enrollment_outcomes`). They are never model inputs; they're used to check past predictions.
- **The database enforces valid values.** Enums are VARCHAR columns with CHECK constraints, so MySQL itself rejects a role like `superadmin`.

## AI tutor workflow (LangGraph)

```
guard ──blocked──▶ END
  │
retrieve ──no relevant passage──▶ insufficient ──▶ END
  │
personalize (student's weak topics) ─▶ generate ─▶ verify_citations ─▶ END
```

- **Access control in the query.** Chroma `where` filter: `course_id = X AND (visibility = 'course' OR owner_id = me)`. Another student's private notes are never retrieved.
- **Grounding.** The model must answer only from numbered passages and cite them. `verify_citations` removes any `[n]` that wasn't retrieved and flags ungrounded answers.
- **Prompt injection.**
  - A rule-based guard catches requests to override instructions or access other users' data.
  - Retrieved text is labelled as reference material, not instructions.
- **Offline mode.** Without an API key, hashed n-gram embeddings and extractive answers keep the tutor usable, and the tests deterministic.

## API overview

| Area | Endpoints |
|---|---|
| Auth | `POST /auth/login`, `/auth/token`, `/auth/logout`, `/auth/register`, `GET /auth/me` |
| Student | `GET /students/me/dashboard`, `/courses/{id}/analytics`, `/prediction`, `/mastery`, `/recommendations`; `POST .../recommendations/refresh`; `PATCH /students/me/recommendations/{id}` |
| Faculty | `GET /faculty/courses`, `/courses/{id}/students?risk=high`, `/courses/{id}/analytics`, `/courses/{id}/students/{sid}`; `POST /faculty/predictions/{id}/reviews` |
| Tutor | `GET /tutor/courses`; `GET/POST /tutor/documents`; `DELETE /tutor/documents/{id}`; `GET/POST /tutor/sessions`; `GET/POST /tutor/sessions/{id}/messages` |
| Admin | `GET /admin/overview`, `POST /admin/rescore` |
| Ops | `GET /health`, `GET /ready` |

Interactive docs: `/docs`.
