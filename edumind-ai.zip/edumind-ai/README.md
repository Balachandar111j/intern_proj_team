# EduMind AI: adaptive learning intelligence platform

EduMind tells each student where they stand in a course, explains why, recommends what to study next, and answers questions from the course notes with page citations. Faculty see which students need a check-in and record what they decided.

> **Data notice.** The repository ships with a model and demo students generated from *synthetic* data in the OULAD format, so everything runs out of the box. Swap in the real dataset with one command (see [Use the real OULAD data](#use-the-real-oulad-data)) before reporting any results.

## What it does

- **Student dashboard**
  - Risk of failing or withdrawing, as a calibrated probability.
  - The reasons behind it, computed as SHAP values.
  - Scores vs class average, and weekly activity.
- **Topic mastery path**
  - Each topic marked as mastered, developing, needs work, not submitted or coming up.
  - Prerequisite gaps flagged.
- **"Do this next"**
  - Ranked, explained recommendations: readings, courses and AI-tutor quizzes.
  - Completion and feedback tracking.
- **AI tutor (RAG)**
  - Answers only from course notes, with page citations, or says it can't find the answer.
  - Quiz mode and three explanation levels.
  - Students can upload private PDFs.
- **Faculty view**
  - Class risk triage and the most common risk drivers.
  - Student drill-down, with a logged review of every flag (book a check-in / agree / dismiss).
- **Admin view**
  - Active model metrics and model comparison.
  - A live backtest of predictions against known outcomes.
  - Rescoring and an audit trail.

## Architecture

```mermaid
flowchart LR
  subgraph Browser
    UI[React + TypeScript<br/>Tailwind, Recharts]
  end
  subgraph App["FastAPI app (one Docker image)"]
    API[REST API /api/v1<br/>cookie auth, RBAC, CSRF]
    SVC[Services<br/>analytics, mastery, recommendations]
    ML[Risk model<br/>XGBoost / LR + SHAP]
    RAG[LangGraph tutor<br/>guard → retrieve → generate → verify]
    VEC[(Chroma index)]
  end
  DB[(MySQL 8)]
  LLM[OpenAI API]
  UI -- same origin --> API
  API --> SVC --> DB
  API --> ML
  ML --> DB
  API --> RAG --> VEC
  RAG --> LLM
  RAG -. chunks + embeddings .-> DB
```

- **Modular monolith.** One deployable unit with clear service boundaries, and no microservices until scale needs them.
- **One feature function for training and serving** (`app/ml/features.py`).
  - A test proves MySQL-built features equal dataset-built features.
  - This prevents training-serving skew.
- **Batch scoring.** Predictions are stored with the model version and the exact feature values, so every flag is auditable.
- **MySQL is the source of truth for the tutor.**
  - Chroma is a rebuildable index.
  - The app survives hosts that wipe the disk on restart.

More detail is in [docs/architecture.md](docs/architecture.md) and [docs/data-and-model.md](docs/data-and-model.md).

## Quick start (Docker, recommended)

You need Docker Desktop.

```bash
cp .env.example .env          # optional: add OPENAI_API_KEY for generated tutor answers
docker compose up --build
```

- **Open the app:** <http://localhost:8000>
- **Demo password:** `EduMind@2026`, or your `DEMO_PASSWORD`.

| Account | What you'll see |
|---|---|
| `student@edumind.demo` | A struggling student: high risk, weak topics, recommendations |
| `student2@edumind.demo` | A student who is on track |
| `faculty@edumind.demo` | Class triage and student reviews |
| `admin@edumind.demo` | Model health, backtest, rescoring |

- **API docs:** <http://localhost:8000/docs>. Use **Authorize** with a demo email and password.
- **Health checks:** `/health` (process) and `/ready` (database and model).

## Run without Docker (macOS)

```bash
brew install mysql node@22 python@3.12
brew services start mysql
mysql -uroot -e "CREATE DATABASE edumind CHARACTER SET utf8mb4; CREATE USER 'edumind'@'%' IDENTIFIED BY 'edumind_local_pw'; GRANT ALL ON edumind.* TO 'edumind'@'%';"

cd backend
python3.12 -m venv .venv && source .venv/bin/activate
pip install -r requirements-dev.txt
alembic upgrade head
python -m app.seed              # loads demo data, scores students, indexes course notes
uvicorn app.main:app --reload   # http://127.0.0.1:8000

# second terminal
cd frontend && npm install && npm run dev   # http://localhost:5173 (proxies /api to FastAPI)
```

## Use the real OULAD data

1. Download `anonymisedData.zip` from <https://analyse.kmi.open.ac.uk/open_dataset>. The licence is CC BY 4.0.
2. Run the switch:

   ```bash
   cd backend && source .venv/bin/activate
   python -m app.ml.prepare_real --zip ~/Downloads/anonymisedData.zip
   ```

   - This validates the files and retrains and evaluates the model.
   - It also writes the model card and exports a fresh seed sample.
3. Reset the database so it reseeds:
   - Docker: `docker compose down -v && docker compose up --build`
   - Local: `alembic downgrade base && alembic upgrade head && python -m app.seed`
4. Read `backend/artifacts/risk_model/model_card.md`. These are the numbers to report.

## Tests and quality

```bash
cd backend && pytest          # 33 tests: full pipeline on fresh synthetic data + a throwaway MySQL DB
ruff check . && ruff format --check .
cd ../frontend && npm test && npm run build
```

The tests cover:

- **Data:** feature leakage, training-serving parity, model and explanation outputs.
- **Auth:** cookies, CSRF, rate limits.
- **Access control:** student ownership and faculty course scoping.
- **Tutor:** grounding, refusal, prompt-injection guard, private-document isolation, citation verification.
- **Database:** migrations up and down.

CI runs everything on each push (`.github/workflows/ci.yml`).

## Deploy

- **Setup:** Render (Docker web service) plus a free managed MySQL (Aiven).
- **Guide:** [docs/deployment.md](docs/deployment.md).
- **Blueprint:** `render.yaml`.

## Project structure

```text
backend/
  app/
    api/v1/endpoints/   auth, students, faculty, tutor, admin
    core/               config, security (Argon2 + JWT), deps (RBAC), rate limiting
    models/             SQLAlchemy models (23 tables)
    ml/                 oulad loader, features, train, model (SHAP), synthetic, export_seed, prepare_real
    rag/                providers (OpenAI / offline), ingest, Chroma store, LangGraph tutor
    services/           analytics, mastery, recommendations, predictions, audit
    seed/               curriculum mapping + seeding
  migrations/           Alembic
  artifacts/risk_model/ model.joblib, metadata.json, model_card.md, feature_importance.png
  seed_data/            app-ready student sample (records up to the prediction day only)
  tests/
frontend/src/           pages, components (TopicRoute, RiskSummary, charts), api client
docs/                   architecture, data and model, deployment, demo script
```

## Limitations

- **Data source:** OULAD is distance learning at the Open University. Behaviour at an Indian college will differ, so retrain on local data before real use.
- **Synthetic labels:** module contents are anonymised, so course titles and topics are an illustrative curriculum mapped onto real assessments (`app/seed/curriculum.py`). Display names are generated.
- **Mastery method:** mastery is a transparent score-based baseline. Bayesian Knowledge Tracing needs item-level data such as ASSISTments.
- **Recommendation evaluation:** recommendations are content-based. Precision@K needs real relevance judgements; until then the app records completions and ratings.
- **Rate limiting:** limits are in-process. Use Redis when running more than one instance.

## Attribution

Kuzilek J., Hlosta M., Zdrahal Z. *Open University Learning Analytics dataset.* Scientific Data 4:170171 (2017). CC BY 4.0.
