#!/bin/sh
# Container start: migrate the database, optionally seed demo data, then serve.
set -e

echo "Applying database migrations..."
alembic upgrade head

if [ "${SEED_ON_STARTUP:-false}" = "true" ]; then
  echo "Seeding demo data (skipped automatically if the database already has data)..."
  python -m app.seed
fi

exec uvicorn app.main:app --host 0.0.0.0 --port "${PORT:-8000}" --proxy-headers --forwarded-allow-ips="*"
