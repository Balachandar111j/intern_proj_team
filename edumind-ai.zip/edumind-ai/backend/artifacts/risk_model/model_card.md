# Model card: dropout_fail_risk

> **SYNTHETIC DATA.** This model was trained on generated data in the OULAD format. Its metrics only show the pipeline works; they are not evidence about real students. Retrain on the real OULAD files before reporting results.

- **Version:** `xgboost-synthetic-d90-20261020135602`
- **Algorithm:** xgboost (selected on validation ROC-AUC among deployable models)
- **Data:** synthetic; trained 2026-10-20T13:56:02+00:00
- **Prediction point:** day 90 of a course presentation
- **Population:** students registered and not withdrawn on day 90
- **Label:** at_risk = final_result in {Fail, Withdrawn}

## Intended use
- Early-warning signal for faculty, who review every flag before acting.
- Not for grading, admissions, or any automatic decision about a student.

## Data split (temporal)
- Train: 2013B, 2013J (1681 students)
- Validation: 2014B (837) — model choice, calibration, thresholds
- Test: 2014J (852) — evaluated once

## Model comparison
| Model | Val ROC-AUC | Val PR-AUC | Test ROC-AUC | Test PR-AUC | Test Brier |
|---|---|---|---|---|---|
| baseline_prior | 0.5 | 0.2724 | 0.5 | 0.2782 | 0.2008 |
| logistic_regression | 0.8847 | 0.7826 | 0.8986 | 0.8156 | 0.1057 |
| random_forest | 0.892 | 0.8026 | 0.9024 | 0.8104 | 0.1069 |
| xgboost | 0.8856 | 0.8043 | 0.8842 | 0.7942 | 0.112 |

Comparison rows use uncalibrated probabilities. Random forest is compared but not deployable here, because the app explains predictions with exact SHAP values available for XGBoost and logistic regression.

## Thresholds
- High risk: p >= 0.4
- Medium risk: p >= 0.16
- How chosen: high = threshold with the best F1 on validation; medium = highest threshold that still catches >= 85% of at-risk students on validation

## Test results (calibrated model)
- ROC-AUC 0.8842 (baseline 0.5), PR-AUC 0.7942, Brier 0.1114
- At-risk rate in test: 0.2782
- High flag: precision 0.7293, recall 0.7046, flags 27% of students
- Medium or high flag: precision 0.5452, recall 0.865, flags 44% of students

### Calibration (test)
| Predicted bin | n | Mean predicted | Observed rate |
|---|---|---|---|
| 0.0-0.1 | 402 | 0.041 | 0.052 |
| 0.1-0.2 | 114 | 0.144 | 0.211 |
| 0.2-0.3 | 59 | 0.247 | 0.169 |
| 0.3-0.4 | 48 | 0.348 | 0.312 |
| 0.4-0.5 | 44 | 0.456 | 0.455 |
| 0.5-0.6 | 37 | 0.555 | 0.514 |
| 0.6-0.7 | 30 | 0.653 | 0.767 |
| 0.7-0.8 | 33 | 0.759 | 0.727 |
| 0.8-0.9 | 37 | 0.858 | 0.973 |
| 0.9-1.0 | 48 | 0.949 | 0.938 |

## Fairness audit (test, groups with n >= 30)
Demographics are not model inputs; they are used only here to check for uneven errors.

**gender**

| Group | n | At-risk rate | ROC-AUC | Recall (high) | Precision (high) |
|---|---|---|---|---|---|
| F | 435 | 0.301 | 0.8631 | 0.6718 | 0.7154 |
| M | 417 | 0.254 | 0.9076 | 0.7453 | 0.7453 |

**age_band**

| Group | n | At-risk rate | ROC-AUC | Recall (high) | Precision (high) |
|---|---|---|---|---|---|
| 0-35 | 627 | 0.284 | 0.8828 | 0.7247 | 0.7247 |
| 35-55 | 207 | 0.256 | 0.8933 | 0.6604 | 0.7609 |

**disability**

| Group | n | At-risk rate | ROC-AUC | Recall (high) | Precision (high) |
|---|---|---|---|---|---|
| N | 766 | 0.281 | 0.8829 | 0.7116 | 0.7427 |
| Y | 86 | 0.256 | 0.8999 | 0.6364 | 0.6087 |

**imd_band**

| Group | n | At-risk rate | ROC-AUC | Recall (high) | Precision (high) |
|---|---|---|---|---|---|
| 0-10% | 84 | 0.155 | 0.896 | 0.6923 | 0.6 |
| 10-20% | 83 | 0.361 | 0.8283 | 0.6667 | 0.8333 |
| 20-30% | 77 | 0.325 | 0.8308 | 0.6 | 0.6818 |
| 30-40% | 86 | 0.209 | 0.8979 | 0.6667 | 0.6 |
| 40-50% | 89 | 0.281 | 0.9144 | 0.76 | 0.7037 |
| 50-60% | 88 | 0.205 | 0.8905 | 0.7778 | 0.7368 |
| 60-70% | 81 | 0.321 | 0.9476 | 0.8462 | 1.0 |
| 70-80% | 100 | 0.22 | 0.8467 | 0.5909 | 0.5652 |
| 80-90% | 76 | 0.355 | 0.8964 | 0.7778 | 0.75 |
| 90-100% | 88 | 0.375 | 0.8782 | 0.6667 | 0.7586 |

## Most influential features (mean |SHAP|, test)
- Average score: 0.911300003528595
- Recent activity (14 days): 0.4507000148296356
- Latest score: 0.4146000146865845
- Platform activity: 0.3968000113964081
- Study workload (credits): 0.3930000066757202
- Assessments due: 0.2556000053882599
- Submission rate: 0.23690000176429749
- Lowest score: 0.2206999957561493

## Limitations
- Trained on Open University distance-learning courses; behaviour may differ elsewhere.
- Clicks measure platform activity, not learning; offline study is invisible to the model.
- A risk estimate is a probability, not a verdict. Faculty review is required.
- Probabilities are calibrated on one validation presentation; recalibrate when moving to new courses.
