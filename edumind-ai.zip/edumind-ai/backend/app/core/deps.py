"""Authentication and authorization dependencies shared by all endpoints."""

from collections.abc import Callable

import jwt
from fastapi import Depends, HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.security import decode_access_token
from app.db.session import get_db
from app.models import FacultyCourse, FacultyProfile, StudentProfile, User

UNAUTHORIZED = HTTPException(
    status_code=status.HTTP_401_UNAUTHORIZED,
    detail="Not authenticated",
    headers={"WWW-Authenticate": "Bearer"},
)


def _token_from_request(request: Request) -> str | None:
    auth = request.headers.get("Authorization", "")
    if auth.lower().startswith("bearer "):
        return auth[7:].strip() or None
    return request.cookies.get(settings.COOKIE_NAME)


def get_current_user(request: Request, db: Session = Depends(get_db)) -> User:
    token = _token_from_request(request)
    if not token:
        raise UNAUTHORIZED
    try:
        payload = decode_access_token(token)
        user_id = int(payload["sub"])
    except (jwt.InvalidTokenError, KeyError, ValueError):
        raise UNAUTHORIZED from None
    user = db.get(User, user_id)
    if user is None or not user.is_active:
        raise UNAUTHORIZED
    return user


def require_roles(*roles: str) -> Callable[..., User]:
    def checker(user: User = Depends(get_current_user)) -> User:
        if user.role not in roles:
            raise HTTPException(status.HTTP_403_FORBIDDEN, "You do not have access to this resource")
        return user

    return checker


def get_current_student(
    user: User = Depends(require_roles("student")), db: Session = Depends(get_db)
) -> StudentProfile:
    profile = db.scalar(select(StudentProfile).where(StudentProfile.user_id == user.id))
    if profile is None:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Student profile not found")
    return profile


def get_current_faculty(
    user: User = Depends(require_roles("faculty")), db: Session = Depends(get_db)
) -> FacultyProfile:
    profile = db.scalar(select(FacultyProfile).where(FacultyProfile.user_id == user.id))
    if profile is None:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Faculty profile not found")
    return profile


def faculty_course_ids(db: Session, faculty: FacultyProfile) -> set[int]:
    rows = db.scalars(select(FacultyCourse.course_id).where(FacultyCourse.faculty_id == faculty.id))
    return set(rows)


def ensure_faculty_teaches(db: Session, faculty: FacultyProfile, course_id: int) -> None:
    if course_id not in faculty_course_ids(db, faculty):
        # 404 rather than 403 so the API doesn't reveal which courses exist.
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Course not found")


def client_ip(request: Request) -> str:
    forwarded = request.headers.get("X-Forwarded-For")
    if forwarded:
        return forwarded.split(",")[0].strip()[:45]
    return (request.client.host if request.client else "unknown")[:45]
