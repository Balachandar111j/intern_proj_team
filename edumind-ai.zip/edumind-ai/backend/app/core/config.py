"""Application settings, loaded from environment variables (and a local .env file)."""

from functools import lru_cache
from pathlib import Path

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

BACKEND_DIR = Path(__file__).resolve().parents[2]
REPO_DIR = BACKEND_DIR.parent


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=(REPO_DIR / ".env", BACKEND_DIR / ".env"),
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # --- App -----------------------------------------------------------------
    APP_NAME: str = "EduMind AI"
    APP_ENV: str = Field(default="development", pattern="^(development|test|production)$")
    LOG_LEVEL: str = "INFO"

    # --- Database ------------------------------------------------------------
    DATABASE_URL: str = "mysql+pymysql://edumind:edumind_local_pw@127.0.0.1:3306/edumind"
    # Path to a CA certificate for TLS database connections (e.g. Aiven). Optional.
    DB_SSL_CA: str | None = None
    # Alternatively, the CA certificate contents (useful on hosts that only take env vars).
    DB_SSL_CA_PEM: str | None = None

    # --- Auth ----------------------------------------------------------------
    JWT_SECRET_KEY: str = "dev-only-change-me-dev-only-change-me"
    JWT_EXPIRE_MINUTES: int = 120
    COOKIE_NAME: str = "edumind_session"
    COOKIE_SECURE: bool = False
    LOGIN_RATE_LIMIT_PER_MINUTE: int = 10
    TUTOR_RATE_LIMIT_PER_MINUTE: int = 20

    # --- Paths ---------------------------------------------------------------
    ARTIFACTS_DIR: Path = BACKEND_DIR / "artifacts"
    SEED_DATA_DIR: Path = BACKEND_DIR / "seed_data"
    UPLOAD_DIR: Path = BACKEND_DIR / "var" / "uploads"
    CHROMA_DIR: Path = BACKEND_DIR / "var" / "chroma"
    FRONTEND_DIST_DIR: Path | None = None

    # --- ML ------------------------------------------------------------------
    # The platform runs "as of" this day of each course presentation. Predictions
    # only use data recorded on or before it.
    PREDICTION_DAY: int = 90

    # --- AI tutor ------------------------------------------------------------
    LLM_PROVIDER: str = Field(default="auto", pattern="^(auto|openai|local)$")
    OPENAI_API_KEY: str | None = None
    OPENAI_CHAT_MODEL: str = "gpt-5-mini"
    OPENAI_EMBEDDING_MODEL: str = "text-embedding-3-small"
    MAX_UPLOAD_MB: int = 10
    RETRIEVAL_TOP_K: int = 5

    # --- Seeding -------------------------------------------------------------
    DEMO_PASSWORD: str | None = None
    SEED_ON_STARTUP: bool = False

    @field_validator("OPENAI_API_KEY", "DB_SSL_CA", "DB_SSL_CA_PEM", "DEMO_PASSWORD", mode="before")
    @classmethod
    def _blank_to_none(cls, value):
        if isinstance(value, str) and not value.strip():
            return None
        return value

    @property
    def is_production(self) -> bool:
        return self.APP_ENV == "production"

    @property
    def effective_llm_provider(self) -> str:
        if self.LLM_PROVIDER == "auto":
            return "openai" if self.OPENAI_API_KEY else "local"
        return self.LLM_PROVIDER

    def validate_for_production(self) -> None:
        """Fail fast on unsafe production configuration."""
        if not self.is_production:
            return
        problems = []
        if "dev-only" in self.JWT_SECRET_KEY or len(self.JWT_SECRET_KEY) < 32:
            problems.append("JWT_SECRET_KEY must be a random value of at least 32 characters")
        if not self.COOKIE_SECURE:
            problems.append("COOKIE_SECURE must be true in production (HTTPS only)")
        if problems:
            raise RuntimeError("Unsafe production configuration: " + "; ".join(problems))


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
