"""Generate SYNTHETIC data in the exact OULAD file format.

Purpose: develop and test the pipeline before (or without) the real dataset.
The files are clearly marked as synthetic, and any metrics computed on them say
nothing about real students. Replace them with the real OULAD files for results.

Usage:
    python -m app.ml.synthetic --out ../data/synthetic/oulad --students 350
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

MODULES = {
    # module: (TMA due days, TMA weights, CMA due days)
    "BBB": ([19, 54, 110, 152, 201], [5, 18, 22, 25, 30], []),
    "DDD": ([25, 53, 88, 123, 165, 207], [10, 12.5, 17.5, 20, 20, 20], []),
    "FFF": ([24, 52, 87, 136, 192], [12.5, 12.5, 25, 25, 25], [33, 80, 150, 220]),
}
PRESENTATIONS = {"2013B": 240, "2013J": 268, "2014B": 241, "2014J": 269}
REGIONS = [
    "East Anglian Region",
    "Scotland",
    "North Western Region",
    "South East Region",
    "West Midlands Region",
    "Wales",
    "North Region",
    "South Region",
    "Ireland",
    "South West Region",
    "East Midlands Region",
    "Yorkshire Region",
    "London Region",
]
EDUCATION = [
    "HE Qualification",
    "A Level or Equivalent",
    "Lower Than A Level",
    "Post Graduate Qualification",
    "No Formal quals",
]
IMD = [f"{i * 10}-{i * 10 + 10}%" for i in range(10)]
IMD[0] = "0-10%"


def _sigmoid(x):
    return 1 / (1 + np.exp(-x))


def generate(out_dir: Path, students_per_presentation: int = 350, seed: int = 42) -> None:
    rng = np.random.default_rng(seed)
    out_dir.mkdir(parents=True, exist_ok=True)

    courses, assessments, info, registration, s_assess, vle = [], [], [], [], [], []
    next_student = 100000
    next_assessment = 1000

    for module, (tma_days, tma_weights, cma_days) in MODULES.items():
        site_ids = np.arange(len(courses) * 1000 + 500000, len(courses) * 1000 + 500040)
        for pres, length in PRESENTATIONS.items():
            courses.append((module, pres, length))
            # Assessments ------------------------------------------------------------
            items = []
            for day, w in zip(tma_days, tma_weights, strict=True):
                items.append((next_assessment, "TMA", day + int(rng.integers(-2, 3)), w))
                next_assessment += 1
            for day in cma_days:
                items.append((next_assessment, "CMA", day + int(rng.integers(-2, 3)), 0.0))
                next_assessment += 1
            exam_id = next_assessment
            next_assessment += 1
            for aid, atype, day, w in items:
                assessments.append((module, pres, aid, atype, day, w))
            assessments.append((module, pres, exam_id, "Exam", np.nan, 100.0))

            # Students -------------------------------------------------------------
            n = students_per_presentation
            ids = np.arange(next_student, next_student + n)
            next_student += n
            ability = rng.normal(size=n)
            motivation = 0.4 * ability + np.sqrt(1 - 0.16) * rng.normal(size=n)
            prev_attempts = rng.poisson(np.clip(0.12 - 0.08 * ability, 0.01, None))
            credits = rng.choice([30, 60, 60, 60, 90, 120, 150], size=n)
            workload = (credits - 60) / 60

            reg_day = -np.round(rng.uniform(0, 120, n) * (0.4 + _sigmoid(motivation))).astype(int)
            p_withdraw = _sigmoid(-1.3 - 1.4 * motivation + 0.35 * prev_attempts + 0.5 * workload)
            withdraws = rng.random(n) < p_withdraw
            withdraw_day = np.where(withdraws, np.round(rng.beta(1.3, 2.6, n) * length * 0.85 - 10).astype(int), 10_000)
            unreg = np.where(withdraws & (rng.random(n) < 0.9), withdraw_day, np.nan)

            # Daily platform activity (students x days) ------------------------------
            days = np.arange(-20, length + 1)
            decay = np.maximum(0, -motivation)[:, None] * 0.006 * np.maximum(days, 0)[None, :]
            near_due = np.zeros(len(days))
            for _, _, day, _ in items:
                near_due += ((days >= day - 4) & (days <= day)).astype(float)
            logit = -0.6 + 1.0 * motivation[:, None] - decay + 0.7 * near_due[None, :] - 0.8 * (days < 0)[None, :]
            fading = (days[None, :] > withdraw_day[:, None] - 14) & (days[None, :] <= withdraw_day[:, None])
            logit = logit - 1.2 * fading
            active = rng.random(logit.shape) < _sigmoid(logit)
            active &= days[None, :] <= withdraw_day[:, None]
            s_idx, d_idx = np.nonzero(active)
            lam = np.exp(1.5 + 0.35 * motivation[s_idx] + 0.4 * near_due[d_idx])
            day_clicks = rng.poisson(lam) + 1
            split = rng.random(len(s_idx)) < 0.5  # some days spread over two resources
            first = np.where(split, np.maximum(1, day_clicks // 2), day_clicks)
            for mask, amount in ((np.ones(len(s_idx), bool), first), (split, day_clicks - first)):
                keep = mask & (amount > 0)
                vle.append(
                    pd.DataFrame(
                        {
                            "code_module": module,
                            "code_presentation": pres,
                            "id_student": ids[s_idx[keep]],
                            "id_site": rng.choice(site_ids, keep.sum()),
                            "date": days[d_idx[keep]],
                            "sum_click": amount[keep],
                        }
                    )
                )

            # Submissions -------------------------------------------------------------
            tma_scores = np.zeros((n, len(tma_days)))
            for aid, atype, day, _ in items:
                alive = withdraw_day > day
                p_sub = _sigmoid(2.0 + 1.5 * motivation + 0.4 * ability - 0.4 * workload)
                if atype == "CMA":
                    p_sub = _sigmoid(2.4 + 1.3 * motivation)
                submits = alive & (rng.random(n) < p_sub)
                offset = np.round(rng.normal(-3, 3.5, n)).astype(int) - (motivation > 0.8) * 2
                sub_day = day + offset
                noise = rng.normal(0, 9, n)
                score = np.clip(np.round(62 + 13 * ability + 4 * motivation + noise), 0, 100)
                if atype == "CMA":
                    score = np.clip(score + 8, 0, 100)
                for i in np.nonzero(submits)[0]:
                    s_assess.append((aid, ids[i], int(sub_day[i]), 0, float(score[i])))
                if atype == "TMA":
                    col = [a for a, t, _, _ in items if t == "TMA"].index(aid)
                    tma_scores[:, col] = np.where(submits, score, 0)

            # Exam and final result ----------------------------------------------------
            exam = np.clip(np.round(55 + 15 * ability + 3 * motivation + rng.normal(0, 12, n)), 0, 100)
            tma_avg = tma_scores @ (np.array(tma_weights) / sum(tma_weights))
            overall = 0.5 * tma_avg + 0.5 * exam
            result = np.where(overall >= 40, "Pass", "Fail")
            result = np.where((overall >= 74) & (exam >= 70), "Distinction", result)
            result = np.where(withdraws, "Withdrawn", result)
            sits_exam = ~withdraws
            for i in np.nonzero(sits_exam)[0]:
                s_assess.append((exam_id, ids[i], length - 2, 0, float(exam[i])))

            for i in range(n):
                info.append(
                    (
                        module,
                        pres,
                        ids[i],
                        rng.choice(["M", "F"]),
                        rng.choice(REGIONS),
                        rng.choice(EDUCATION, p=[0.15, 0.43, 0.39, 0.02, 0.01]),
                        rng.choice(IMD),
                        rng.choice(["0-35", "35-55", "55<="], p=[0.7, 0.28, 0.02]),
                        int(prev_attempts[i]),
                        int(credits[i]),
                        rng.choice(["N", "Y"], p=[0.9, 0.1]),
                        result[i],
                    )
                )
                registration.append(
                    (module, pres, ids[i], int(reg_day[i]), None if np.isnan(unreg[i]) else int(unreg[i]))
                )

    pd.DataFrame(courses, columns=["code_module", "code_presentation", "module_presentation_length"]).to_csv(
        out_dir / "courses.csv", index=False
    )
    pd.DataFrame(
        assessments,
        columns=["code_module", "code_presentation", "id_assessment", "assessment_type", "date", "weight"],
    ).to_csv(out_dir / "assessments.csv", index=False, na_rep="?")
    pd.DataFrame(
        info,
        columns=[
            "code_module",
            "code_presentation",
            "id_student",
            "gender",
            "region",
            "highest_education",
            "imd_band",
            "age_band",
            "num_of_prev_attempts",
            "studied_credits",
            "disability",
            "final_result",
        ],
    ).to_csv(out_dir / "studentInfo.csv", index=False)
    pd.DataFrame(
        registration,
        columns=["code_module", "code_presentation", "id_student", "date_registration", "date_unregistration"],
    ).to_csv(out_dir / "studentRegistration.csv", index=False, na_rep="?")
    pd.DataFrame(s_assess, columns=["id_assessment", "id_student", "date_submitted", "is_banked", "score"]).to_csv(
        out_dir / "studentAssessment.csv", index=False
    )
    pd.concat(vle).to_csv(out_dir / "studentVle.csv", index=False)
    pd.DataFrame(
        columns=["id_site", "code_module", "code_presentation", "activity_type", "week_from", "week_to"]
    ).to_csv(out_dir / "vle.csv", index=False)
    (out_dir / "SYNTHETIC_DATA.txt").write_text(
        "These files are SYNTHETIC. They mimic the OULAD file format so the pipeline can be\n"
        "developed and tested. Do not report model metrics computed on them as real results.\n"
        "Replace them with the real OULAD files from https://analyse.kmi.open.ac.uk/open_dataset\n"
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--students", type=int, default=350, help="students per course presentation")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    generate(args.out, args.students, args.seed)
    print(f"Synthetic OULAD-format data written to {args.out}")


if __name__ == "__main__":
    main()
