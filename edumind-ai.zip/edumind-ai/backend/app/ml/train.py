"""Train, compare, calibrate and document the early-warning risk model.

Task: on day ``--day`` of a course presentation, estimate the probability that a
still-enrolled student will finish with Fail or Withdrawn.

Split (temporal, by presentation, so the test set is "the future"):
    train      2013B, 2013J
    validation 2014B   (model selection, calibration, thresholds)
    test       2014J   (touched once, for the final report)

Usage:
    python -m app.ml.train --data-dir ../data/raw/oulad --day 90
"""

from __future__ import annotations

import argparse
import json
from datetime import UTC, datetime
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    average_precision_score,
    brier_score_loss,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import FunctionTransformer, StandardScaler
from xgboost import XGBClassifier

from app.core.config import settings
from app.ml import oulad
from app.ml.features import EXCLUDED_FROM_MODEL, FEATURE_COLUMNS, build_labelled_dataset
from app.ml.model import FEATURE_LABELS, RiskModel, _logit, log_counts

SEED = 42
TRAIN_PRESENTATIONS = ["2013B", "2013J"]
VAL_PRESENTATION = "2014B"
TEST_PRESENTATION = "2014J"
DEPLOYABLE = {"logistic_regression", "xgboost"}  # algorithms with a runtime explainer
SUBGROUP_COLUMNS = ["gender", "age_band", "disability", "imd_band"]


def candidate_models() -> dict[str, object]:
    return {
        "baseline_prior": DummyClassifier(strategy="prior"),
        "logistic_regression": Pipeline(
            [
                ("log_counts", FunctionTransformer(log_counts)),
                ("impute", SimpleImputer(strategy="median")),
                ("scale", StandardScaler()),
                ("model", LogisticRegression(C=1.0, max_iter=2000)),
            ]
        ),
        "random_forest": Pipeline(
            [
                ("impute", SimpleImputer(strategy="median")),
                (
                    "model",
                    RandomForestClassifier(n_estimators=300, min_samples_leaf=5, n_jobs=-1, random_state=SEED),
                ),
            ]
        ),
        "xgboost": XGBClassifier(
            n_estimators=300,
            max_depth=4,
            learning_rate=0.05,
            subsample=0.9,
            colsample_bytree=0.9,
            min_child_weight=3,
            reg_lambda=1.0,
            eval_metric="logloss",
            random_state=SEED,
            n_jobs=2,
        ),
    }


# --- Metrics ---------------------------------------------------------------------
def threshold_metrics(y: np.ndarray, p: np.ndarray, t: float) -> dict:
    pred = (p >= t).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
    return {
        "threshold": round(float(t), 4),
        "precision": round(float(precision_score(y, pred, zero_division=0)), 4),
        "recall": round(float(recall_score(y, pred, zero_division=0)), 4),
        "f1": round(float(f1_score(y, pred, zero_division=0)), 4),
        "flagged_rate": round(float(pred.mean()), 4),
        "confusion": {"tp": int(tp), "fp": int(fp), "fn": int(fn), "tn": int(tn)},
    }


def ranking_metrics(y: np.ndarray, p: np.ndarray) -> dict:
    both = len(np.unique(y)) == 2
    return {
        "roc_auc": round(float(roc_auc_score(y, p)), 4) if both else None,
        "pr_auc": round(float(average_precision_score(y, p)), 4) if both else None,
        "brier": round(float(brier_score_loss(y, p)), 4),
        "positive_rate": round(float(y.mean()), 4),
        "n": int(len(y)),
    }


def calibration_table(y: np.ndarray, p: np.ndarray, bins: int = 10) -> list[dict]:
    edges = np.linspace(0, 1, bins + 1)
    idx = np.clip(np.digitize(p, edges) - 1, 0, bins - 1)
    rows = []
    for b in range(bins):
        mask = idx == b
        if mask.sum() == 0:
            continue
        rows.append(
            {
                "bin": f"{edges[b]:.1f}-{edges[b + 1]:.1f}",
                "n": int(mask.sum()),
                "mean_predicted": round(float(p[mask].mean()), 3),
                "observed_rate": round(float(y[mask].mean()), 3),
            }
        )
    return rows


def choose_thresholds(y: np.ndarray, p: np.ndarray, target_recall: float = 0.85) -> dict:
    grid = np.round(np.arange(0.05, 0.96, 0.01), 2)
    f1s = [f1_score(y, (p >= t).astype(int), zero_division=0) for t in grid]
    high = float(grid[int(np.argmax(f1s))])
    medium = None
    for t in sorted(grid[grid < high], reverse=True):
        if recall_score(y, (p >= t).astype(int), zero_division=0) >= target_recall:
            medium = float(t)
            break
    if medium is None:
        medium = round(high * 0.6, 2)
    return {
        "high": high,
        "medium": medium,
        "objective": (
            f"high = threshold with the best F1 on validation; medium = highest threshold "
            f"that still catches >= {target_recall:.0%} of at-risk students on validation"
        ),
    }


def subgroup_report(df: pd.DataFrame, p: np.ndarray, t_high: float) -> dict:
    out = {}
    for col in SUBGROUP_COLUMNS:
        rows = []
        for group, idx in df.groupby(col, dropna=False).groups.items():
            mask = df.index.isin(idx)
            y = df.at_risk.values[mask]
            if mask.sum() < 30:
                continue
            pr = p[mask]
            row = {"group": str(group), "n": int(mask.sum()), "at_risk_rate": round(float(y.mean()), 3)}
            row.update({k: v for k, v in ranking_metrics(y, pr).items() if k == "roc_auc"})
            tm = threshold_metrics(y, pr, t_high)
            row.update(
                {"recall_high": tm["recall"], "precision_high": tm["precision"], "flagged_rate": tm["flagged_rate"]}
            )
            rows.append(row)
        out[col] = rows
    return out


# --- Training ----------------------------------------------------------------------
def fit_calibrator(raw: np.ndarray, y: np.ndarray) -> LogisticRegression:
    calibrator = LogisticRegression(C=1e4, max_iter=1000)
    calibrator.fit(_logit(raw), y)
    return calibrator


def train(data_dir: Path, day: int, out_dir: Path) -> dict:
    data = oulad.load(data_dir)
    oulad.write_report(data.report, out_dir / "validation_report.json")
    df = build_labelled_dataset(data, day)

    train_df = df[df.presentation.isin(TRAIN_PRESENTATIONS)].reset_index(drop=True)
    val_df = df[df.presentation == VAL_PRESENTATION].reset_index(drop=True)
    test_df = df[df.presentation == TEST_PRESENTATION].reset_index(drop=True)
    assert not set(train_df.presentation) & {VAL_PRESENTATION, TEST_PRESENTATION}, "split leak"
    for name, part in (("train", train_df), ("validation", val_df), ("test", test_df)):
        if part.at_risk.nunique() < 2:
            raise ValueError(f"The {name} split needs both at-risk and not-at-risk students")
    assert not set(FEATURE_COLUMNS) & set(EXCLUDED_FROM_MODEL), "demographics must not be features"

    X_tr, y_tr = train_df[FEATURE_COLUMNS], train_df.at_risk.values
    X_va, y_va = val_df[FEATURE_COLUMNS], val_df.at_risk.values
    X_te, y_te = test_df[FEATURE_COLUMNS], test_df.at_risk.values

    fitted, comparison = {}, {}
    for name, model in candidate_models().items():
        model.fit(X_tr, y_tr)
        fitted[name] = model
        p_va = model.predict_proba(X_va)[:, 1]
        p_te = model.predict_proba(X_te)[:, 1]
        comparison[name] = {"validation": ranking_metrics(y_va, p_va), "test": ranking_metrics(y_te, p_te)}

    # Model selection uses validation only; the test split stays untouched until the end.
    deployable = {k: v for k, v in comparison.items() if k in DEPLOYABLE}
    best = max(deployable, key=lambda k: deployable[k]["validation"]["roc_auc"] or 0)
    estimator = fitted[best]

    calibrator = fit_calibrator(estimator.predict_proba(X_va)[:, 1], y_va)
    p_va_cal = calibrator.predict_proba(_logit(estimator.predict_proba(X_va)[:, 1]))[:, 1]
    thresholds = choose_thresholds(y_va, p_va_cal)

    version = f"{best}-{data.data_source}-d{day}-{datetime.now(UTC):%Y%m%d%H%M%S}"
    reference = {c: (None if pd.isna(v) else round(float(v), 2)) for c, v in X_tr.median().items()}
    risk_model = RiskModel(
        algorithm=best,
        estimator=estimator,
        calibrator=calibrator,
        feature_columns=FEATURE_COLUMNS,
        thresholds={"high": thresholds["high"], "medium": thresholds["medium"]},
        reference=reference,
        version=version,
    )

    # --- Final, one-time evaluation on the held-out future presentation ---------------
    p_te = risk_model.predict_proba(X_te)
    test_eval = {
        **ranking_metrics(y_te, p_te),
        "at_high": threshold_metrics(y_te, p_te, thresholds["high"]),
        "at_medium_or_high": threshold_metrics(y_te, p_te, thresholds["medium"]),
        "calibration": calibration_table(y_te, p_te),
        "baseline_roc_auc": comparison["baseline_prior"]["test"]["roc_auc"],
    }
    contrib = risk_model.contributions(X_te)
    importance = contrib.abs().mean().sort_values(ascending=False).round(4).to_dict()

    metadata = {
        "name": "dropout_fail_risk",
        "version": version,
        "algorithm": best,
        "data_source": data.data_source,
        "prediction_day": day,
        "label": "at_risk = final_result in {Fail, Withdrawn}",
        "population": f"students registered and not withdrawn on day {day}",
        "features": FEATURE_COLUMNS,
        "excluded_from_model": EXCLUDED_FROM_MODEL,
        "split": {
            "train": TRAIN_PRESENTATIONS,
            "validation": VAL_PRESENTATION,
            "test": TEST_PRESENTATION,
            "sizes": {"train": len(train_df), "validation": len(val_df), "test": len(test_df)},
        },
        "comparison": comparison,
        "thresholds": thresholds,
        "test": test_eval,
        "subgroups": subgroup_report(test_df, p_te, thresholds["high"]),
        "global_importance": importance,
        "reference_medians": reference,
        "trained_at": datetime.now(UTC).isoformat(timespec="seconds"),
        "library_versions": _versions(),
    }

    out_dir.mkdir(parents=True, exist_ok=True)
    joblib.dump(risk_model, out_dir / "model.joblib")
    (out_dir / "metadata.json").write_text(json.dumps(metadata, indent=2))
    (out_dir / "model_card.md").write_text(model_card(metadata))
    _plot_importance(importance, out_dir / "feature_importance.png", data.data_source)
    return metadata


def _versions() -> dict:
    import sklearn
    import xgboost

    return {"scikit-learn": sklearn.__version__, "xgboost": xgboost.__version__, "pandas": pd.__version__}


def _plot_importance(importance: dict, path: Path, source: str) -> None:
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return
    items = list(importance.items())[:12][::-1]
    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.barh([FEATURE_LABELS.get(k, k) for k, _ in items], [v for _, v in items], color="#3b6fd8")
    ax.set_xlabel("Mean |SHAP value| (log-odds), test set")
    title = "What drives the risk prediction"
    if source == "synthetic":
        title += "  [SYNTHETIC DATA]"
    ax.set_title(title)
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def model_card(m: dict) -> str:
    warn = ""
    if m["data_source"] == "synthetic":
        warn = (
            "\n> **SYNTHETIC DATA.** This model was trained on generated data in the OULAD format. "
            "Its metrics only show the pipeline works; they are not evidence about real students. "
            "Retrain on the real OULAD files before reporting results.\n"
        )
    t = m["test"]
    lines = [
        f"# Model card: {m['name']}",
        warn,
        f"- **Version:** `{m['version']}`",
        f"- **Algorithm:** {m['algorithm']} (selected on validation ROC-AUC among deployable models)",
        f"- **Data:** {m['data_source']}; trained {m['trained_at']}",
        f"- **Prediction point:** day {m['prediction_day']} of a course presentation",
        f"- **Population:** {m['population']}",
        f"- **Label:** {m['label']}",
        "",
        "## Intended use",
        "- Early-warning signal for faculty, who review every flag before acting.",
        "- Not for grading, admissions, or any automatic decision about a student.",
        "",
        "## Data split (temporal)",
        f"- Train: {', '.join(m['split']['train'])} ({m['split']['sizes']['train']} students)",
        f"- Validation: {m['split']['validation']} ({m['split']['sizes']['validation']}) — model choice, calibration, thresholds",
        f"- Test: {m['split']['test']} ({m['split']['sizes']['test']}) — evaluated once",
        "",
        "## Model comparison",
        "| Model | Val ROC-AUC | Val PR-AUC | Test ROC-AUC | Test PR-AUC | Test Brier |",
        "|---|---|---|---|---|---|",
    ]
    for name, r in m["comparison"].items():
        v, te = r["validation"], r["test"]
        lines.append(f"| {name} | {v['roc_auc']} | {v['pr_auc']} | {te['roc_auc']} | {te['pr_auc']} | {te['brier']} |")
    lines += [
        "",
        "Comparison rows use uncalibrated probabilities. Random forest is compared but not deployable "
        "here, because the app explains predictions with exact SHAP values available for "
        "XGBoost and logistic regression.",
        "",
        "## Thresholds",
        f"- High risk: p >= {m['thresholds']['high']}",
        f"- Medium risk: p >= {m['thresholds']['medium']}",
        f"- How chosen: {m['thresholds']['objective']}",
        "",
        "## Test results (calibrated model)",
        f"- ROC-AUC {t['roc_auc']} (baseline {t['baseline_roc_auc']}), PR-AUC {t['pr_auc']}, Brier {t['brier']}",
        f"- At-risk rate in test: {t['positive_rate']}",
        f"- High flag: precision {t['at_high']['precision']}, recall {t['at_high']['recall']}, "
        f"flags {t['at_high']['flagged_rate']:.0%} of students",
        f"- Medium or high flag: precision {t['at_medium_or_high']['precision']}, recall "
        f"{t['at_medium_or_high']['recall']}, flags {t['at_medium_or_high']['flagged_rate']:.0%} of students",
        "",
        "### Calibration (test)",
        "| Predicted bin | n | Mean predicted | Observed rate |",
        "|---|---|---|---|",
    ]
    lines += [f"| {r['bin']} | {r['n']} | {r['mean_predicted']} | {r['observed_rate']} |" for r in t["calibration"]]
    lines += [
        "",
        "## Fairness audit (test, groups with n >= 30)",
        "Demographics are not model inputs; they are used only here to check for uneven errors.",
    ]
    for col, rows in m["subgroups"].items():
        lines += [
            "",
            f"**{col}**",
            "",
            "| Group | n | At-risk rate | ROC-AUC | Recall (high) | Precision (high) |",
            "|---|---|---|---|---|---|",
        ]
        lines += [
            f"| {r['group']} | {r['n']} | {r['at_risk_rate']} | {r.get('roc_auc')} | {r['recall_high']} | {r['precision_high']} |"
            for r in rows
        ]
    lines += [
        "",
        "## Most influential features (mean |SHAP|, test)",
        *[f"- {FEATURE_LABELS.get(k, k)}: {v}" for k, v in list(m["global_importance"].items())[:8]],
        "",
        "## Limitations",
        "- Trained on Open University distance-learning courses; behaviour may differ elsewhere.",
        "- Clicks measure platform activity, not learning; offline study is invisible to the model.",
        "- A risk estimate is a probability, not a verdict. Faculty review is required.",
        "- Probabilities are calibrated on one validation presentation; recalibrate when moving to new courses.",
    ]
    return "\n".join(lines) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--data-dir", type=Path, required=True)
    parser.add_argument("--day", type=int, default=settings.PREDICTION_DAY)
    parser.add_argument("--out", type=Path, default=settings.ARTIFACTS_DIR / "risk_model")
    args = parser.parse_args()
    meta = train(args.data_dir, args.day, args.out)
    t = meta["test"]
    print(f"Trained {meta['version']}")
    print(f"Test ROC-AUC {t['roc_auc']} (baseline {t['baseline_roc_auc']}), PR-AUC {t['pr_auc']}")
    print(f"High flag precision {t['at_high']['precision']} recall {t['at_high']['recall']}")
    print(f"Artifacts: {args.out}")


if __name__ == "__main__":
    main()
