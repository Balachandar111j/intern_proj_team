"""The deployable risk model: calibrated probabilities + per-student SHAP explanations.

Explanations are exact SHAP values without the heavy `shap` package:
  * XGBoost: the booster's built-in TreeSHAP (``pred_contribs=True``).
  * Logistic regression: coefficient x standardized value, which equals the
    linear SHAP value relative to the training mean.
Both are in log-odds units: positive = pushes risk up, negative = pulls it down.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from app.ml.features import COUNT_FEATURES, FEATURE_COLUMNS

RISK_LEVELS = ("low", "medium", "high")


def log_counts(X):
    """Log-transform count features (used inside the logistic-regression pipeline)."""
    X = np.asarray(X, dtype=float).copy()
    idx = [FEATURE_COLUMNS.index(c) for c in COUNT_FEATURES]
    X[:, idx] = np.log1p(np.clip(X[:, idx], 0, None))
    return X


def _logit(p: np.ndarray) -> np.ndarray:
    p = np.clip(p, 1e-6, 1 - 1e-6)
    return np.log(p / (1 - p)).reshape(-1, 1)


@dataclass
class RiskModel:
    algorithm: str
    estimator: object
    calibrator: object
    feature_columns: list[str]
    thresholds: dict[str, float]
    reference: dict[str, float]  # training medians, used in human-readable reasons
    version: str = ""
    extra: dict = field(default_factory=dict)

    # --- Probabilities --------------------------------------------------------
    def raw_proba(self, X: pd.DataFrame) -> np.ndarray:
        return self.estimator.predict_proba(X[self.feature_columns])[:, 1]

    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        return self.calibrator.predict_proba(_logit(self.raw_proba(X)))[:, 1]

    def risk_level(self, p: float) -> str:
        if p >= self.thresholds["high"]:
            return "high"
        if p >= self.thresholds["medium"]:
            return "medium"
        return "low"

    # --- Explanations -----------------------------------------------------------
    def contributions(self, X: pd.DataFrame) -> pd.DataFrame:
        X = X[self.feature_columns]
        if self.algorithm == "xgboost":
            import xgboost as xgb

            booster = self.estimator.get_booster()
            contrib = booster.predict(xgb.DMatrix(X, feature_names=self.feature_columns), pred_contribs=True)
            values = contrib[:, :-1]  # last column is the bias term
        elif self.algorithm == "logistic_regression":
            transformed = self.estimator[:-1].transform(X)
            values = transformed * self.estimator[-1].coef_[0]
        else:
            raise ValueError(f"No explainer for algorithm {self.algorithm!r}")
        return pd.DataFrame(values, columns=self.feature_columns, index=X.index)

    def explain_row(self, features: pd.Series, contrib: pd.Series, top_n: int = 4) -> list[dict]:
        """Top factors for one student, as structured data plus a readable sentence."""
        ranked = contrib.reindex(contrib.abs().sort_values(ascending=False).index)
        factors = []
        for feature, value in ranked.items():
            if abs(value) < 0.05 or len(factors) >= top_n:
                continue
            raw = features.get(feature)
            factors.append(
                {
                    "feature": feature,
                    "label": FEATURE_LABELS.get(feature, feature),
                    "value": None if pd.isna(raw) else float(raw),
                    "typical": self.reference.get(feature),
                    "contribution": round(float(value), 4),
                    "direction": "increases_risk" if value > 0 else "decreases_risk",
                    "reason": describe(feature, raw, features, self.reference),
                }
            )
        return factors


FEATURE_LABELS = {
    "n_due": "Assessments due",
    "submit_rate": "Submission rate",
    "avg_score": "Average score",
    "min_score": "Lowest score",
    "last_score": "Latest score",
    "late_rate": "Late submissions",
    "total_clicks": "Platform activity",
    "active_days": "Active days",
    "clicks_last_14": "Recent activity (14 days)",
    "click_trend": "Activity trend",
    "days_since_last_active": "Days since last active",
    "pre_start_clicks": "Preparation before start",
    "registration_lead": "Early registration",
    "prev_attempts": "Previous attempts",
    "studied_credits": "Study workload (credits)",
}


def _fmt(x, pct=False) -> str:
    if x is None or pd.isna(x):
        return "n/a"
    return f"{x:.0%}" if pct else f"{x:,.0f}"


def describe(feature: str, value, row: pd.Series, ref: dict) -> str:
    typical = ref.get(feature)
    if value is None or pd.isna(value):
        if feature in ("avg_score", "min_score", "last_score", "late_rate"):
            return "No marked submissions yet"
        return f"{FEATURE_LABELS.get(feature, feature)}: not available"
    match feature:
        case "submit_rate":
            n_due = int(row.get("n_due") or 0)
            return f"Submitted {round(value * n_due)} of {n_due} assessments due so far"
        case "avg_score":
            return f"Average assessment score {_fmt(value)}% (typical {_fmt(typical)}%)"
        case "min_score":
            return f"Lowest assessment score so far {_fmt(value)}%"
        case "last_score":
            return f"Most recent assessment score {_fmt(value)}%"
        case "late_rate":
            return f"{_fmt(value, pct=True)} of submissions were late"
        case "total_clicks":
            return f"{_fmt(value)} learning-platform interactions so far (typical {_fmt(typical)})"
        case "active_days":
            return f"Active on {_fmt(value)} days so far (typical {_fmt(typical)})"
        case "clicks_last_14":
            return f"{_fmt(value)} interactions in the last two weeks (typical {_fmt(typical)})"
        case "click_trend":
            change = np.expm1(value)
            if change <= -0.15:
                return f"Activity fell about {_fmt(-change, pct=True)} in the last two weeks"
            if change >= 0.15:
                return f"Activity rose about {_fmt(change, pct=True)} in the last two weeks"
            return "Activity steady over the last four weeks"
        case "days_since_last_active":
            return f"Last active {_fmt(value)} days ago"
        case "pre_start_clicks":
            return f"{_fmt(value)} interactions before the course started (typical {_fmt(typical)})"
        case "registration_lead":
            return f"Registered {_fmt(value)} days before the start (typical {_fmt(typical)})"
        case "prev_attempts":
            return f"Previous attempts at this module: {_fmt(value)}"
        case "studied_credits":
            return f"Studying {_fmt(value)} credits this term (typical {_fmt(typical)})"
        case "n_due":
            return f"{_fmt(value)} assessments due so far"
    return f"{FEATURE_LABELS.get(feature, feature)}: {value}"
