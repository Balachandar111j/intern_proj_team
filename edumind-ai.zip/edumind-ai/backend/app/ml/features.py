"""The feature contract: one function computes model inputs for training AND serving.

Training calls it with frames built from OULAD CSVs; the live API calls it with
frames built from MySQL. Because both paths share this code, the model sees the
same features in production that it saw in training (no training-serving skew).

Every feature only uses records dated on or before ``as_of_day``. That is what
makes the prediction honest: the model cannot peek at the future.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

KEY = ["student_key", "course_key"]

FEATURE_COLUMNS: list[str] = [
    "n_due",  # assessments due so far
    "submit_rate",  # share of due assessments submitted
    "avg_score",  # mean score of submissions so far
    "min_score",  # weakest submission so far
    "last_score",  # most recent submission
    "late_rate",  # share of submissions that were late
    "total_clicks",  # learning-platform clicks so far
    "active_days",  # days with any platform activity
    "clicks_last_14",  # clicks in the most recent two weeks
    "click_trend",  # log-change in clicks: last 2 weeks vs the 2 before
    "days_since_last_active",  # days since the last platform activity
    "pre_start_clicks",  # engagement before the course started
    "registration_lead",  # days registered before the start
    "prev_attempts",  # previous attempts at this module
    "studied_credits",  # total credits studied this term (workload)
]
COUNT_FEATURES = ["n_due", "total_clicks", "active_days", "clicks_last_14", "pre_start_clicks"]

# Demographics are NOT model inputs. They are only used to audit model fairness.
EXCLUDED_FROM_MODEL = ["gender", "age_band", "disability", "imd_band", "highest_education", "region"]


def active_enrollments(enrollments: pd.DataFrame, as_of_day: int) -> pd.DataFrame:
    """Students registered by ``as_of_day`` who had not withdrawn on or before it."""
    registered = enrollments.registered_day.isna() | (enrollments.registered_day <= as_of_day)
    still_in = enrollments.unregistered_day.isna() | (enrollments.unregistered_day > as_of_day)
    return enrollments[registered & still_in]


def compute_features(
    enrollments: pd.DataFrame,
    assessments: pd.DataFrame,
    results: pd.DataFrame,
    clicks: pd.DataFrame,
    as_of_day: int,
) -> pd.DataFrame:
    """Return one row per (student_key, course_key) in ``enrollments`` with FEATURE_COLUMNS."""
    base = enrollments[KEY + ["registered_day", "prev_attempts", "studied_credits"]].copy()
    out = base.set_index(KEY)

    # --- Assessments -----------------------------------------------------------
    graded = assessments[assessments.assessment_type != "Exam"]
    due = graded[graded.due_day.notna() & (graded.due_day <= as_of_day)]
    n_due = due.groupby("course_key").size().rename("n_due")
    out = out.join(n_due, on="course_key")
    out["n_due"] = out["n_due"].fillna(0)

    res = results[results.submitted_day <= as_of_day].merge(
        assessments[["assessment_id", "course_key", "assessment_type", "due_day"]],
        on="assessment_id",
        how="inner",
    )
    res = res[res.assessment_type != "Exam"]
    # Only results for the course this enrollment belongs to.
    res = res.merge(base[KEY], on=KEY, how="inner")

    submitted_due = res[res.assessment_id.isin(due.assessment_id)]
    n_sub_due = submitted_due.groupby(KEY).size().rename("n_submitted_due")
    out = out.join(n_sub_due)
    out["n_submitted_due"] = out["n_submitted_due"].fillna(0)
    out["submit_rate"] = np.where(out.n_due > 0, out.n_submitted_due / out.n_due.replace(0, 1), np.nan)

    # Tie-break same-day submissions by due date: ids differ between OULAD and MySQL,
    # due dates don't, so both paths agree on which score is "last".
    scored = res[res.score.notna()].sort_values(["submitted_day", "due_day", "assessment_type", "score"], kind="stable")
    grp = scored.groupby(KEY)
    out = out.join(grp.score.mean().rename("avg_score"))
    out = out.join(grp.score.min().rename("min_score"))
    out = out.join(grp.score.last().rename("last_score"))

    with_due = res[res.due_day.notna()]
    late = (with_due.submitted_day > with_due.due_day).groupby([with_due.student_key, with_due.course_key])
    out = out.join(late.mean().rename("late_rate"))

    # --- Engagement ------------------------------------------------------------
    clk = clicks[clicks.day <= as_of_day].merge(base[KEY], on=KEY, how="inner")
    cgrp = clk.groupby(KEY)
    out = out.join(cgrp.clicks.sum().rename("total_clicks"))
    out = out.join(cgrp.size().rename("active_days"))
    out = out.join(cgrp.day.max().rename("last_active_day"))
    last14 = clk[clk.day > as_of_day - 14].groupby(KEY).clicks.sum().rename("clicks_last_14")
    prev14 = (
        clk[(clk.day > as_of_day - 28) & (clk.day <= as_of_day - 14)].groupby(KEY).clicks.sum().rename("clicks_prev_14")
    )
    pre = clk[clk.day < 0].groupby(KEY).clicks.sum().rename("pre_start_clicks")
    out = out.join(last14).join(prev14).join(pre)
    for col in ["total_clicks", "active_days", "clicks_last_14", "clicks_prev_14", "pre_start_clicks"]:
        out[col] = out[col].fillna(0)
    out["click_trend"] = np.log1p(out.clicks_last_14) - np.log1p(out.clicks_prev_14)
    # No activity at all counts as "inactive since well before the start".
    out["days_since_last_active"] = (as_of_day - out.last_active_day).fillna(as_of_day + 30)

    # --- Registration and workload ----------------------------------------------
    out["registration_lead"] = -out.registered_day
    out["prev_attempts"] = out.prev_attempts.fillna(0)
    out["studied_credits"] = out.studied_credits.fillna(0)

    out = out[FEATURE_COLUMNS].astype(float)
    return out.reset_index()


def build_labelled_dataset(data, as_of_day: int) -> pd.DataFrame:
    """Features + label for every enrollment still active at ``as_of_day``.

    Label ``at_risk`` = 1 when the final result was Fail or Withdrawn.
    """
    from app.ml.oulad import AT_RISK_RESULTS

    active = active_enrollments(data.enrollments, as_of_day)
    feats = compute_features(active, data.assessments, data.results, data.clicks, as_of_day)
    meta = active[KEY + ["final_result", *EXCLUDED_FROM_MODEL]]
    df = feats.merge(meta, on=KEY, how="left")
    df["at_risk"] = df.final_result.isin(AT_RISK_RESULTS).astype(int)
    df["presentation"] = df.course_key.str.split("-").str[-1]
    return df
