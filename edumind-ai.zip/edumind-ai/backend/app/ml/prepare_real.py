"""Switch the platform from synthetic data to the real OULAD dataset in one command.

    python -m app.ml.prepare_real --zip ~/Downloads/anonymisedData.zip

Steps: unzip -> validate -> train and evaluate the model -> export the app's seed
sample. Afterwards, reset the database so it reseeds (see README).
"""

from __future__ import annotations

import argparse
import shutil
import zipfile
from pathlib import Path

from app.core.config import REPO_DIR, settings
from app.ml.export_seed import export
from app.ml.train import train


def unpack(zip_path: Path, dest: Path) -> Path:
    if dest.exists():
        shutil.rmtree(dest)
    dest.mkdir(parents=True)
    with zipfile.ZipFile(zip_path) as zf:
        for member in zf.namelist():  # refuse paths that escape the target folder
            if member.startswith("/") or ".." in Path(member).parts:
                raise SystemExit(f"Unsafe path in zip: {member}")
        zf.extractall(dest)
    found = sorted(dest.rglob("courses.csv"))
    if not found:
        raise SystemExit("courses.csv not found in the zip. Is this the OULAD anonymisedData.zip?")
    return found[0].parent


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--zip", type=Path, required=True, help="path to OULAD anonymisedData.zip")
    parser.add_argument("--day", type=int, default=settings.PREDICTION_DAY)
    parser.add_argument("--courses", nargs="+", default=["DDD-2014J", "FFF-2014J"])
    parser.add_argument("--per-course", type=int, default=150)
    args = parser.parse_args()

    data_dir = unpack(args.zip.expanduser(), REPO_DIR / "data" / "raw" / "oulad")
    print(f"Unpacked to {data_dir}. Training (this reads ~10 million click rows; allow a few minutes)...")
    meta = train(data_dir, args.day, settings.ARTIFACTS_DIR / "risk_model")
    t = meta["test"]
    print(
        f"Model {meta['version']}: test ROC-AUC {t['roc_auc']} (baseline {t['baseline_roc_auc']}), PR-AUC {t['pr_auc']}"
    )
    manifest = export(data_dir, args.courses, args.per_course, args.day, settings.SEED_DATA_DIR)
    print(f"Seed sample: {manifest['students']} students from {', '.join(manifest['courses'])}")
    print("Model card: backend/artifacts/risk_model/model_card.md")
    print("Next: reset the database so it reseeds with the real data (see README, 'Use the real OULAD data').")


if __name__ == "__main__":
    main()
