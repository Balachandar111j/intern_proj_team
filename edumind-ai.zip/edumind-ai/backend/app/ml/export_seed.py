"""Export a compact, app-ready sample of students for the live platform.

The app runs "as of" the prediction day, so only records dated on or before that
day are exported. Final results are exported separately as outcomes, which the
app never shows to the model but uses to check its own earlier predictions.

Usage:
    python -m app.ml.export_seed --data-dir ../data/raw/oulad --courses DDD-2014J FFF-2014J
"""

from __future__ import annotations

import argparse
import json
from datetime import UTC, datetime
from pathlib import Path

import numpy as np

from app.core.config import settings
from app.ml import oulad
from app.ml.features import active_enrollments

ATTRIBUTION = (
    "Kuzilek J., Hlosta M., Zdrahal Z. Open University Learning Analytics dataset. "
    "Sci. Data 4:170171 (2017). Licensed CC BY 4.0. https://analyse.kmi.open.ac.uk/open_dataset"
)


def export(data_dir: Path, courses: list[str], per_course: int, day: int, out_dir: Path, seed: int = 7) -> dict:
    data = oulad.load(data_dir)
    rng = np.random.default_rng(seed)
    unknown = set(courses) - set(data.courses.course_key)
    if unknown:
        raise SystemExit(f"Unknown course(s): {sorted(unknown)}. Available: {sorted(data.courses.course_key)}")

    active = active_enrollments(data.enrollments, day)
    chosen = []
    for course in courses:
        pool = active[active.course_key == course]
        take = min(per_course, len(pool))
        chosen.append(pool.iloc[rng.choice(len(pool), size=take, replace=False)])
    import pandas as pd

    enroll = pd.concat(chosen).reset_index(drop=True)
    students = set(enroll.student_key)

    assess = data.assessments[data.assessments.course_key.isin(courses)]
    results = data.results[
        data.results.student_key.isin(students)
        & data.results.assessment_id.isin(assess.assessment_id)
        & (data.results.submitted_day <= day)
    ]
    clicks = data.clicks[
        data.clicks.student_key.isin(students) & data.clicks.course_key.isin(courses) & (data.clicks.day <= day)
    ]
    # Only keep clicks for the (student, course) pairs that were sampled.
    clicks = clicks.merge(enroll[["student_key", "course_key"]], on=["student_key", "course_key"])

    out_dir.mkdir(parents=True, exist_ok=True)
    data.courses[data.courses.course_key.isin(courses)].to_csv(out_dir / "courses.csv", index=False)
    assess.to_csv(out_dir / "assessments.csv", index=False)
    enroll[
        ["student_key", "course_key", "registered_day", "unregistered_day", "prev_attempts", "studied_credits"]
    ].to_csv(out_dir / "enrollments.csv", index=False)
    enroll[["student_key", "course_key", "final_result"]].to_csv(out_dir / "outcomes.csv", index=False)
    results.to_csv(out_dir / "results.csv", index=False)
    clicks.to_csv(out_dir / "clicks.csv", index=False)
    manifest = {
        "data_source": data.data_source,
        "prediction_day": day,
        "courses": courses,
        "students": len(students),
        "rows": {"results": len(results), "clicks": len(clicks)},
        "created_at": datetime.now(UTC).isoformat(timespec="seconds"),
        "attribution": ATTRIBUTION if data.data_source == "oulad" else "Synthetic data (OULAD format)",
    }
    (out_dir / "manifest.json").write_text(json.dumps(manifest, indent=2))
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--data-dir", type=Path, required=True)
    parser.add_argument("--courses", nargs="+", default=["DDD-2014J", "FFF-2014J"])
    parser.add_argument("--per-course", type=int, default=150)
    parser.add_argument("--day", type=int, default=settings.PREDICTION_DAY)
    parser.add_argument("--out", type=Path, default=settings.SEED_DATA_DIR)
    args = parser.parse_args()
    manifest = export(args.data_dir, args.courses, args.per_course, args.day, args.out)
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
