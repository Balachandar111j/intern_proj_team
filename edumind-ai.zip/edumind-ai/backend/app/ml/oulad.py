"""Load and validate the Open University Learning Analytics Dataset (OULAD).

Source: https://analyse.kmi.open.ac.uk/open_dataset (CC BY 4.0).
Kuzilek J., Hlosta M., Zdrahal Z. Open University Learning Analytics dataset.
Sci. Data 4:170171 (2017).

The loader turns the seven OULAD CSV files into four normalized tables (the
"feature contract" inputs) that the live app can also produce from MySQL:

    enrollments  student_key, course_key, registered_day, unregistered_day,
                 prev_attempts, studied_credits, final_result, + demographics
    assessments  course_key, assessment_id, assessment_type, due_day, weight
    results      student_key, assessment_id, submitted_day, score, is_banked
    clicks       student_key, course_key, day, clicks   (one row per active day)
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
import pandas as pd

EXPECTED_COLUMNS: dict[str, list[str]] = {
    "courses.csv": ["code_module", "code_presentation", "module_presentation_length"],
    "assessments.csv": [
        "code_module",
        "code_presentation",
        "id_assessment",
        "assessment_type",
        "date",
        "weight",
    ],
    "studentInfo.csv": [
        "code_module",
        "code_presentation",
        "id_student",
        "gender",
        "region",
        "highest_education",
        "imd_band",
        "age_band",
        "num_of_prev_attempts",
        "studied_credits",
        "disability",
        "final_result",
    ],
    "studentRegistration.csv": [
        "code_module",
        "code_presentation",
        "id_student",
        "date_registration",
        "date_unregistration",
    ],
    "studentAssessment.csv": ["id_assessment", "id_student", "date_submitted", "is_banked", "score"],
    "studentVle.csv": [
        "code_module",
        "code_presentation",
        "id_student",
        "id_site",
        "date",
        "sum_click",
    ],
}
FINAL_RESULTS = {"Pass", "Distinction", "Fail", "Withdrawn"}
DEMOGRAPHIC_COLUMNS = ["gender", "age_band", "disability", "imd_band", "highest_education", "region"]
AT_RISK_RESULTS = {"Fail", "Withdrawn"}


class DatasetValidationError(ValueError):
    pass


@dataclass
class OuladData:
    courses: pd.DataFrame
    enrollments: pd.DataFrame
    assessments: pd.DataFrame
    results: pd.DataFrame
    clicks: pd.DataFrame
    data_source: str = "oulad"
    report: dict = field(default_factory=dict)


def course_key(module: pd.Series, presentation: pd.Series) -> pd.Series:
    return module.astype(str) + "-" + presentation.astype(str)


def _read(path: Path, name: str, **kwargs) -> pd.DataFrame:
    file = path / name
    if not file.exists():
        raise DatasetValidationError(f"Missing file: {file}")
    df = pd.read_csv(file, na_values=["?", ""], keep_default_na=True, **kwargs)
    missing = set(EXPECTED_COLUMNS[name]) - set(df.columns)
    if missing:
        raise DatasetValidationError(f"{name} is missing columns: {sorted(missing)}")
    return df


def detect_source(data_dir: Path) -> str:
    marker = data_dir / "SYNTHETIC_DATA.txt"
    return "synthetic" if marker.exists() else "oulad"


def load(data_dir: str | Path) -> OuladData:
    """Read, validate and normalize an OULAD-format directory."""
    data_dir = Path(data_dir)
    report: dict = {"data_dir": str(data_dir), "data_source": detect_source(data_dir), "checks": []}

    def check(name: str, ok: bool, detail: str = "") -> None:
        report["checks"].append({"check": name, "passed": bool(ok), "detail": detail})

    courses = _read(data_dir, "courses.csv")
    assessments = _read(data_dir, "assessments.csv")
    info = _read(data_dir, "studentInfo.csv")
    registration = _read(data_dir, "studentRegistration.csv")
    student_assessment = _read(data_dir, "studentAssessment.csv")
    vle = _read(
        data_dir,
        "studentVle.csv",
        usecols=EXPECTED_COLUMNS["studentVle.csv"],
        dtype={"id_student": "int64", "id_site": "int64", "date": "int32", "sum_click": "int32"},
    )
    report["row_counts"] = {
        "courses": len(courses),
        "assessments": len(assessments),
        "studentInfo": len(info),
        "studentRegistration": len(registration),
        "studentAssessment": len(student_assessment),
        "studentVle": len(vle),
    }

    # --- Courses ---------------------------------------------------------------
    courses = courses.assign(
        course_key=course_key(courses.code_module, courses.code_presentation),
        module_code=courses.code_module.astype(str),
        presentation=courses.code_presentation.astype(str),
        length_days=courses.module_presentation_length.astype(int),
    )[["course_key", "module_code", "presentation", "length_days"]]
    check("course keys unique", courses.course_key.is_unique)

    # --- Assessments -------------------------------------------------------------
    assessments = assessments.assign(
        course_key=course_key(assessments.code_module, assessments.code_presentation),
        assessment_id=assessments.id_assessment.astype(int).astype(str),
        due_day=pd.to_numeric(assessments["date"], errors="coerce"),
        weight=pd.to_numeric(assessments.weight, errors="coerce").fillna(0.0),
    )[["course_key", "assessment_id", "assessment_type", "due_day", "weight"]]
    check(
        "assessment types valid",
        assessments.assessment_type.isin(["TMA", "CMA", "Exam"]).all(),
        str(sorted(assessments.assessment_type.unique().tolist())),
    )
    check("assessment ids unique", assessments.assessment_id.is_unique)
    missing_due = int(assessments.due_day.isna().sum())
    check("assessment due dates present (exams may be missing)", True, f"{missing_due} missing")

    # --- Enrollments -------------------------------------------------------------
    info = info.assign(course_key=course_key(info.code_module, info.code_presentation))
    registration = registration.assign(course_key=course_key(registration.code_module, registration.code_presentation))
    enrollments = info.merge(
        registration[["course_key", "id_student", "date_registration", "date_unregistration"]],
        on=["course_key", "id_student"],
        how="left",
        validate="one_to_one",
    )
    enrollments = enrollments.rename(
        columns={
            "id_student": "student_key",
            "date_registration": "registered_day",
            "date_unregistration": "unregistered_day",
            "num_of_prev_attempts": "prev_attempts",
        }
    )
    enrollments["student_key"] = enrollments.student_key.astype(int)
    enrollments = enrollments[
        [
            "student_key",
            "course_key",
            "registered_day",
            "unregistered_day",
            "prev_attempts",
            "studied_credits",
            "final_result",
            *DEMOGRAPHIC_COLUMNS,
        ]
    ]
    dupes = int(enrollments.duplicated(["student_key", "course_key"]).sum())
    check("one enrollment per student and course", dupes == 0, f"{dupes} duplicates")
    bad_results = set(enrollments.final_result.dropna().unique()) - FINAL_RESULTS
    check("final_result values valid", not bad_results, str(sorted(bad_results)))
    check(
        "every enrollment belongs to a known course",
        enrollments.course_key.isin(courses.course_key).all(),
    )

    # --- Results -------------------------------------------------------------------
    results = student_assessment.rename(columns={"id_student": "student_key", "date_submitted": "submitted_day"})
    results = results.assign(
        assessment_id=results.id_assessment.astype(int).astype(str),
        student_key=results.student_key.astype(int),
        score=pd.to_numeric(results.score, errors="coerce"),
        is_banked=results.is_banked.fillna(0).astype(int).astype(bool),
    )[["student_key", "assessment_id", "submitted_day", "score", "is_banked"]]
    out_of_range = int(((results.score < 0) | (results.score > 100)).sum())
    check("scores within 0-100", out_of_range == 0, f"{out_of_range} out of range")
    orphan = int((~results.assessment_id.isin(assessments.assessment_id)).sum())
    check("results reference known assessments", orphan == 0, f"{orphan} orphan rows")
    results = results[results.assessment_id.isin(assessments.assessment_id)]
    report["missing_scores"] = int(results.score.isna().sum())

    # --- Clicks (aggregate to one row per student, course and day) -----------------
    vle["course_key"] = course_key(vle.code_module, vle.code_presentation)
    check("click counts non-negative", bool((vle.sum_click >= 0).all()))
    clicks = (
        vle.groupby(["id_student", "course_key", "date"], observed=True, sort=False)["sum_click"]
        .sum()
        .reset_index()
        .rename(columns={"id_student": "student_key", "date": "day", "sum_click": "clicks"})
    )
    clicks["student_key"] = clicks.student_key.astype(int)

    report["summary"] = {
        "students": int(enrollments.student_key.nunique()),
        "enrollments": len(enrollments),
        "courses": len(courses),
        "final_result_distribution": enrollments.final_result.value_counts().to_dict(),
    }
    failed = [c for c in report["checks"] if not c["passed"]]
    report["passed"] = not failed
    if failed:
        raise DatasetValidationError(
            "Dataset validation failed: " + "; ".join(f"{c['check']} ({c['detail']})" for c in failed)
        )
    return OuladData(
        courses=courses,
        enrollments=enrollments,
        assessments=assessments,
        results=results,
        clicks=clicks,
        data_source=report["data_source"],
        report=report,
    )


def write_report(report: dict, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, indent=2, default=_json_default))


def _json_default(value):
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return float(value)
    return str(value)
