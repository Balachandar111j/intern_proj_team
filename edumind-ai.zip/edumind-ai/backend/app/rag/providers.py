"""LLM and embedding providers behind one small interface.

* OpenAI: real embeddings and answers (set OPENAI_API_KEY).
* Local: an offline fallback so the tutor still works for demos and tests
  without a key. It uses hashed word n-gram embeddings for retrieval and
  returns the most relevant passages instead of a generated answer.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from functools import lru_cache
from typing import Protocol

import numpy as np

from app.core.config import settings

log = logging.getLogger(__name__)


@dataclass
class ChatResult:
    text: str
    provider: str
    model: str


class EmbeddingProvider(Protocol):
    name: str

    def embed(self, texts: list[str]) -> list[list[float]]: ...


class ChatProvider(Protocol):
    name: str

    def complete(self, system: str, user: str) -> ChatResult: ...


# --- Local fallback -----------------------------------------------------------------
class LocalEmbeddings:
    name = "local-hashing-1024"

    def __init__(self):
        from sklearn.feature_extraction.text import HashingVectorizer

        self._vec = HashingVectorizer(
            n_features=1024, alternate_sign=False, norm="l2", ngram_range=(1, 2), stop_words="english"
        )

    def embed(self, texts: list[str]) -> list[list[float]]:
        return self._vec.transform(texts).toarray().astype(np.float32).tolist()


_SENTENCE = re.compile(r"(?<=[.!?])\s+")
_WORD = re.compile(r"[a-z0-9]+")


def keyword_overlap(question: str, text: str) -> int:
    q = {w for w in _WORD.findall(question.lower()) if len(w) > 2} - _STOP
    return len(q & set(_WORD.findall(text.lower())))


class LocalChat:
    """Extractive answers: picks the sentences that best match the question."""

    name = "local"
    model = "extractive"

    def answer_from_passages(self, question: str, passages: list[dict]) -> ChatResult:
        q_words = set(_WORD.findall(question.lower())) - _STOP
        ranked = []
        for p in passages:
            for sentence in _SENTENCE.split(p["content"].replace("\n", " ")):
                if len(sentence) < 40 or "\u00b7 Topic" in sentence:
                    continue  # skip page headers and fragments
                words = set(_WORD.findall(sentence.lower()))
                overlap = len(q_words & words)
                if overlap:
                    ranked.append((overlap, p["ref"], sentence.strip()))
        ranked.sort(key=lambda x: -x[0])
        seen, unique = set(), []
        for item in ranked:  # overlapping chunks repeat sentences; keep each once
            key = item[2].lower()
            if key not in seen:
                seen.add(key)
                unique.append(item)
        best = unique[:4] or [(0, passages[0]["ref"], passages[0]["content"][:400])]
        lines = [f"- {s} [{ref}]" for _, ref, s in best]
        text = (
            "**Offline mode** (no OpenAI key configured): here are the most relevant passages "
            "from your course notes.\n\n" + "\n".join(lines)
        )
        return ChatResult(text=text, provider=self.name, model=self.model)

    def complete(self, system: str, user: str) -> ChatResult:  # pragma: no cover - not used directly
        return ChatResult(text="", provider=self.name, model=self.model)


_STOP = {
    "the",
    "a",
    "an",
    "is",
    "are",
    "what",
    "how",
    "why",
    "of",
    "to",
    "in",
    "and",
    "or",
    "do",
    "does",
    "i",
    "me",
    "my",
    "it",
    "for",
    "on",
    "with",
    "can",
    "you",
    "explain",
    "please",
    "this",
    "that",
}


# --- OpenAI -----------------------------------------------------------------------------
class OpenAIEmbeddings:
    def __init__(self, api_key: str, model: str):
        from openai import OpenAI

        self._client = OpenAI(api_key=api_key, timeout=60, max_retries=2)
        self.model = model
        self.name = f"openai-{model}"

    def embed(self, texts: list[str]) -> list[list[float]]:
        out: list[list[float]] = []
        for i in range(0, len(texts), 96):
            batch = [t.replace("\n", " ")[:8000] for t in texts[i : i + 96]]
            resp = self._client.embeddings.create(model=self.model, input=batch)
            out.extend(d.embedding for d in sorted(resp.data, key=lambda d: d.index))
        return out


class OpenAIChat:
    name = "openai"

    def __init__(self, api_key: str, model: str):
        from openai import OpenAI

        self._client = OpenAI(api_key=api_key, timeout=90, max_retries=2)
        self.model = model

    def complete(self, system: str, user: str) -> ChatResult:
        resp = self._client.chat.completions.create(
            model=self.model,
            messages=[{"role": "system", "content": system}, {"role": "user", "content": user}],
        )
        return ChatResult(text=(resp.choices[0].message.content or "").strip(), provider=self.name, model=self.model)


@lru_cache
def get_embeddings() -> EmbeddingProvider:
    if settings.effective_llm_provider == "openai":
        if not settings.OPENAI_API_KEY:
            raise RuntimeError("LLM_PROVIDER=openai requires OPENAI_API_KEY")
        return OpenAIEmbeddings(settings.OPENAI_API_KEY, settings.OPENAI_EMBEDDING_MODEL)
    return LocalEmbeddings()


@lru_cache
def get_chat() -> ChatProvider | LocalChat:
    if settings.effective_llm_provider == "openai":
        return OpenAIChat(settings.OPENAI_API_KEY or "", settings.OPENAI_CHAT_MODEL)
    return LocalChat()
