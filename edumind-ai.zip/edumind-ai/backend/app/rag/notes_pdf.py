"""Render a course's notes (from the curriculum) into a PDF, one topic per page."""

from __future__ import annotations

from pathlib import Path

from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import PageBreak, Paragraph, SimpleDocTemplate, Spacer

from app.seed.curriculum import CourseSpec


def render_course_notes(spec: CourseSpec, path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    styles = getSampleStyleSheet()
    doc = SimpleDocTemplate(
        str(path),
        pagesize=A4,
        leftMargin=2.2 * cm,
        rightMargin=2.2 * cm,
        topMargin=2 * cm,
        bottomMargin=2 * cm,
        title=f"{spec.title} - Course notes",
    )
    story = []
    for i, topic in enumerate(spec.topics):
        if i:
            story.append(PageBreak())
        story.append(Paragraph(f"{spec.title} &middot; Topic {i + 1}", styles["Normal"]))
        story.append(Paragraph(topic.title, styles["Heading1"]))
        story.append(Paragraph(topic.description, styles["Italic"]))
        story.append(Spacer(1, 0.4 * cm))
        for para in (topic.notes or "").strip().split("\n"):
            if para.strip():
                story.append(Paragraph(para.strip(), styles["BodyText"]))
                story.append(Spacer(1, 0.2 * cm))
    doc.build(story)
    return path
