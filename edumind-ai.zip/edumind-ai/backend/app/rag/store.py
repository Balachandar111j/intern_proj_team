"""Vector index (Chroma) with access-control filters applied inside the query.

MySQL (document_chunks) is the source of truth for chunks and embeddings; the
Chroma index is a fast cache that can be rebuilt from it at any time. That keeps
the tutor working on hosts with ephemeral disks (e.g. free cloud tiers).
"""

from __future__ import annotations

import logging
import re
import threading
from functools import lru_cache

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.models import Document, DocumentChunk
from app.rag.providers import get_embeddings

log = logging.getLogger(__name__)
_lock = threading.Lock()


@lru_cache
def _client():
    import chromadb
    from chromadb.config import Settings as ChromaSettings

    settings.CHROMA_DIR.mkdir(parents=True, exist_ok=True)
    return chromadb.PersistentClient(path=str(settings.CHROMA_DIR), settings=ChromaSettings(anonymized_telemetry=False))


def collection():
    name = "chunks-" + re.sub(r"[^a-zA-Z0-9._-]", "-", get_embeddings().name)
    return _client().get_or_create_collection(
        name, embedding_function=None, configuration={"hnsw": {"space": "cosine"}}
    )


def access_filter(user_id: int, course_id: int) -> dict:
    """Course material shared with the class, plus the user's own private uploads."""
    return {"$and": [{"course_id": course_id}, {"$or": [{"visibility": "course"}, {"owner_id": user_id}]}]}


def _metadata(chunk: DocumentChunk, doc: Document) -> dict:
    return {
        "document_id": doc.id,
        "course_id": doc.course_id,
        "owner_id": doc.owner_id,
        "visibility": doc.visibility,
        "page": chunk.page_number,
        "title": doc.title,
    }


def add_chunks(chunks: list[DocumentChunk], doc: Document) -> None:
    if not chunks:
        return
    with _lock:
        collection().upsert(
            ids=[str(c.id) for c in chunks],
            embeddings=[c.embedding for c in chunks],
            documents=[c.content for c in chunks],
            metadatas=[_metadata(c, doc) for c in chunks],
        )


def delete_chunks(chunk_ids: list[int]) -> None:
    if chunk_ids:
        with _lock:
            collection().delete(ids=[str(i) for i in chunk_ids])


def search(query: str, user_id: int, course_id: int, k: int | None = None) -> list[dict]:
    col = collection()
    if col.count() == 0:
        return []
    embedding = get_embeddings().embed([query])[0]
    res = col.query(
        query_embeddings=[embedding],
        n_results=k or settings.RETRIEVAL_TOP_K,
        where=access_filter(user_id, course_id),
    )
    hits = []
    for cid, doc, meta, dist in zip(
        res["ids"][0], res["documents"][0], res["metadatas"][0], res["distances"][0], strict=True
    ):
        hits.append(
            {
                "chunk_id": int(cid),
                "content": doc,
                "document_id": meta["document_id"],
                "title": meta["title"],
                "page": meta["page"],
                "similarity": round(1 - float(dist), 4),
            }
        )
    return hits


def sync_index(db: Session) -> dict:
    """Re-embed chunks made with another embedding model, then make Chroma match MySQL."""
    emb = get_embeddings()
    stale = db.scalars(
        select(DocumentChunk).where(
            (DocumentChunk.embedding_model != emb.name) | DocumentChunk.embedding_model.is_(None)
        )
    ).all()
    for i in range(0, len(stale), 64):
        batch = stale[i : i + 64]
        vectors = emb.embed([c.content for c in batch])
        for c, v in zip(batch, vectors, strict=True):
            c.embedding, c.embedding_model = v, emb.name
    db.commit()

    rows = db.execute(
        select(DocumentChunk, Document)
        .join(Document, Document.id == DocumentChunk.document_id)
        .where(Document.status == "ready")
    ).all()
    col = collection()
    indexed = set(col.get(include=[])["ids"]) if col.count() else set()
    wanted = {str(c.id) for c, _ in rows}
    missing = [(c, d) for c, d in rows if str(c.id) not in indexed]
    by_doc: dict[int, tuple[Document, list[DocumentChunk]]] = {}
    for c, d in missing:
        by_doc.setdefault(d.id, (d, []))[1].append(c)
    for d, chunks in by_doc.values():
        add_chunks(chunks, d)
    extra = indexed - wanted
    if extra:
        delete_chunks([int(i) for i in extra])
    result = {"re_embedded": len(stale), "added": len(missing), "removed": len(extra), "total": len(wanted)}
    log.info("Vector index synced: %s", result)
    return result
