"""Document ingestion: validate -> extract text per page -> chunk -> embed -> index."""

from __future__ import annotations

import logging
import re
from pathlib import Path

from pypdf import PdfReader
from sqlalchemy.orm import Session

from app.models import Document, DocumentChunk
from app.rag import store
from app.rag.providers import get_embeddings

log = logging.getLogger(__name__)
CHUNK_CHARS, OVERLAP_CHARS, MAX_PAGES = 1000, 150, 300


class IngestError(ValueError):
    pass


def extract_pages(path: Path) -> list[str]:
    with path.open("rb") as fh:
        if fh.read(5) != b"%PDF-":
            raise IngestError("File is not a PDF")
    try:
        reader = PdfReader(str(path))
    except Exception as exc:  # pypdf raises many types for corrupt files
        raise IngestError("Could not read the PDF") from exc
    if reader.is_encrypted:
        raise IngestError("Encrypted PDFs are not supported")
    if len(reader.pages) > MAX_PAGES:
        raise IngestError(f"PDF has more than {MAX_PAGES} pages")
    return [_clean(page.extract_text() or "") for page in reader.pages]


def _clean(text: str) -> str:
    text = text.replace("\x00", " ")
    text = re.sub(r"-\n(\w)", r"\1", text)  # re-join hyphenated line breaks
    text = re.sub(r"[ \t]+", " ", text)
    return re.sub(r"\n{3,}", "\n\n", text).strip()


def chunk_page(text: str) -> list[str]:
    """Split on paragraph/sentence boundaries into ~CHUNK_CHARS pieces with overlap."""
    if len(text) <= CHUNK_CHARS:
        return [text] if text else []
    sentences = re.split(r"(?<=[.!?])\s+|\n{2,}", text)
    chunks, current = [], ""
    for s in sentences:
        if current and len(current) + len(s) + 1 > CHUNK_CHARS:
            chunks.append(current.strip())
            current = current[-OVERLAP_CHARS:] + " " + s
        else:
            current = f"{current} {s}" if current else s
    if current.strip():
        chunks.append(current.strip())
    return chunks


def ingest(db: Session, doc: Document) -> Document:
    """Process a stored PDF into chunks. Marks the document ready or failed."""
    try:
        pages = extract_pages(Path(doc.storage_path))
        pieces = [(i + 1, c) for i, page in enumerate(pages) for c in chunk_page(page)]
        if not pieces:
            raise IngestError("No extractable text found (scanned PDFs need OCR first)")
        emb = get_embeddings()
        vectors = emb.embed([c for _, c in pieces])
        chunks = [
            DocumentChunk(
                document_id=doc.id,
                chunk_index=i,
                page_number=page,
                content=content,
                embedding=vec,
                embedding_model=emb.name,
            )
            for i, ((page, content), vec) in enumerate(zip(pieces, vectors, strict=True))
        ]
        db.add_all(chunks)
        doc.page_count, doc.chunk_count, doc.status, doc.error = len(pages), len(chunks), "ready", None
        db.commit()
        store.add_chunks(chunks, doc)
    except IngestError as exc:
        db.rollback()
        doc.status, doc.error = "failed", str(exc)
        db.commit()
    except Exception:
        db.rollback()
        log.exception("Ingestion failed for document %s", doc.id)
        doc.status, doc.error = "failed", "Processing failed. Please try another file."
        db.commit()
    return doc
