from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class Factor(BaseModel):
    feature: str
    label: str
    value: float | None
    typical: float | None
    contribution: float
    direction: Literal["increases_risk", "decreases_risk"]
    reason: str


class PredictionOut(BaseModel):
    id: int
    risk_level: Literal["low", "medium", "high"]
    risk_probability: float
    as_of_day: int
    model_version: str
    algorithm: str
    data_source: str
    thresholds: dict
    factors: list[Factor]
    created_at: str


class CourseSummary(BaseModel):
    course_id: int
    code: str
    title: str
    as_of_day: int
    length_days: int
    data_source: str
    risk: PredictionOut | None
    kpis: dict


class StudentInfo(BaseModel):
    id: int
    full_name: str
    student_code: str
    department: str | None


class DashboardOut(BaseModel):
    student: StudentInfo
    courses: list[CourseSummary]


class MasteryOut(BaseModel):
    topic_id: int
    title: str
    sequence: int
    status: Literal["mastered", "developing", "weak", "missed", "upcoming"]
    mastery: float | None
    class_mastery: float | None
    evidence: list[dict]
    weak_prerequisites: list[str]
    next_due_day: int | None


class ResourceOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    title: str
    resource_type: str
    url: str | None
    provider: str
    difficulty: str
    est_minutes: int
    topic_id: int


class RecommendationOut(BaseModel):
    id: int
    rank: int
    score: float
    reason: str
    status: str
    rating: int | None
    topic: str
    resource: ResourceOut


class RecommendationUpdate(BaseModel):
    status: Literal["opened", "completed", "dismissed"] | None = None
    rating: int | None = Field(default=None, ge=1, le=5)
