"""Source academic records. Predictions and recommendations live in separate tables."""

from sqlalchemy import (
    BigInteger,
    Boolean,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.session import Base
from app.models.base import TimestampMixin, str_enum


class Course(TimestampMixin, Base):
    """One run (presentation) of a module, e.g. DDD-2014J."""

    __tablename__ = "courses"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    code: Mapped[str] = mapped_column(String(32), unique=True)
    title: Mapped[str] = mapped_column(String(150))
    module_code: Mapped[str] = mapped_column(String(16))
    presentation: Mapped[str] = mapped_column(String(16))
    length_days: Mapped[int] = mapped_column(Integer)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    data_source: Mapped[str] = mapped_column(str_enum("oulad", "synthetic", name="data_source"))

    topics: Mapped[list["Topic"]] = relationship(back_populates="course", order_by="Topic.sequence")
    assessments: Mapped[list["Assessment"]] = relationship(back_populates="course")


class FacultyCourse(Base):
    __tablename__ = "faculty_courses"

    faculty_id: Mapped[int] = mapped_column(ForeignKey("faculty_profiles.id", ondelete="CASCADE"), primary_key=True)
    course_id: Mapped[int] = mapped_column(ForeignKey("courses.id", ondelete="CASCADE"), primary_key=True)


class Enrollment(TimestampMixin, Base):
    __tablename__ = "enrollments"
    __table_args__ = (UniqueConstraint("student_id", "course_id", name="uq_enrollment"),)

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    student_id: Mapped[int] = mapped_column(ForeignKey("student_profiles.id", ondelete="CASCADE"), index=True)
    course_id: Mapped[int] = mapped_column(ForeignKey("courses.id", ondelete="CASCADE"), index=True)
    # Day relative to course start (negative = registered before the start).
    registered_day: Mapped[int | None] = mapped_column(Integer, nullable=True)
    unregistered_day: Mapped[int | None] = mapped_column(Integer, nullable=True)
    prev_attempts: Mapped[int] = mapped_column(Integer, default=0)
    studied_credits: Mapped[int] = mapped_column(Integer, default=0)

    course: Mapped[Course] = relationship()


class EnrollmentOutcome(TimestampMixin, Base):
    """Final result, known only after the course ends. Never used as a model input;
    kept so the platform can evaluate its own earlier predictions."""

    __tablename__ = "enrollment_outcomes"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    enrollment_id: Mapped[int] = mapped_column(ForeignKey("enrollments.id", ondelete="CASCADE"), unique=True)
    final_result: Mapped[str] = mapped_column(str_enum("Pass", "Distinction", "Fail", "Withdrawn", name="final_result"))


class Topic(TimestampMixin, Base):
    __tablename__ = "topics"
    __table_args__ = (UniqueConstraint("course_id", "title", name="uq_topic_title"),)

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    course_id: Mapped[int] = mapped_column(ForeignKey("courses.id", ondelete="CASCADE"), index=True)
    title: Mapped[str] = mapped_column(String(120))
    sequence: Mapped[int] = mapped_column(Integer)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)

    course: Mapped[Course] = relationship(back_populates="topics")


class TopicPrerequisite(Base):
    __tablename__ = "topic_prerequisites"

    topic_id: Mapped[int] = mapped_column(ForeignKey("topics.id", ondelete="CASCADE"), primary_key=True)
    prerequisite_id: Mapped[int] = mapped_column(ForeignKey("topics.id", ondelete="CASCADE"), primary_key=True)


class Assessment(TimestampMixin, Base):
    __tablename__ = "assessments"
    __table_args__ = (UniqueConstraint("course_id", "external_id", name="uq_assessment_ext"),)

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    course_id: Mapped[int] = mapped_column(ForeignKey("courses.id", ondelete="CASCADE"), index=True)
    external_id: Mapped[str] = mapped_column(String(32))
    title: Mapped[str] = mapped_column(String(80))
    assessment_type: Mapped[str] = mapped_column(str_enum("TMA", "CMA", "Exam", name="assessment_type"))
    due_day: Mapped[int | None] = mapped_column(Integer, nullable=True)
    weight: Mapped[float] = mapped_column(Float, default=0.0)

    course: Mapped[Course] = relationship(back_populates="assessments")


class AssessmentTopic(Base):
    __tablename__ = "assessment_topics"

    assessment_id: Mapped[int] = mapped_column(ForeignKey("assessments.id", ondelete="CASCADE"), primary_key=True)
    topic_id: Mapped[int] = mapped_column(ForeignKey("topics.id", ondelete="CASCADE"), primary_key=True)


class AssessmentResult(TimestampMixin, Base):
    __tablename__ = "assessment_results"
    __table_args__ = (
        UniqueConstraint("student_id", "assessment_id", name="uq_result"),
        Index("ix_result_assessment", "assessment_id"),
    )

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    student_id: Mapped[int] = mapped_column(ForeignKey("student_profiles.id", ondelete="CASCADE"), index=True)
    assessment_id: Mapped[int] = mapped_column(ForeignKey("assessments.id", ondelete="CASCADE"))
    submitted_day: Mapped[int] = mapped_column(Integer)
    score: Mapped[float | None] = mapped_column(Float, nullable=True)
    is_banked: Mapped[bool] = mapped_column(Boolean, default=False)


class EngagementDaily(Base):
    """Total learning-platform clicks per student, course and day."""

    __tablename__ = "engagement_daily"
    __table_args__ = (
        UniqueConstraint("student_id", "course_id", "day", name="uq_engagement_day"),
        Index("ix_engagement_course_day", "course_id", "day"),
    )

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    student_id: Mapped[int] = mapped_column(ForeignKey("student_profiles.id", ondelete="CASCADE"))
    course_id: Mapped[int] = mapped_column(ForeignKey("courses.id", ondelete="CASCADE"))
    day: Mapped[int] = mapped_column(Integer)
    clicks: Mapped[int] = mapped_column(Integer)
