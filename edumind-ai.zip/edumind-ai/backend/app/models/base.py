from datetime import datetime

from sqlalchemy import DateTime, Enum, func
from sqlalchemy.orm import Mapped, mapped_column


class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), nullable=False)


def str_enum(*values: str, name: str) -> Enum:
    """A VARCHAR column with a CHECK constraint, so the database rejects unknown values."""
    return Enum(*values, name=name, native_enum=False, create_constraint=True, length=20)
