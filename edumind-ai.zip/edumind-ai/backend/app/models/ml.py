"""Derived intelligence: model versions, predictions, reviews and recommendations."""

from datetime import datetime

from sqlalchemy import (
    JSON,
    BigInteger,
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    SmallInteger,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.session import Base
from app.models.base import TimestampMixin, str_enum


class ModelVersion(TimestampMixin, Base):
    __tablename__ = "model_versions"
    __table_args__ = (UniqueConstraint("name", "version", name="uq_model_version"),)

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(60))
    version: Mapped[str] = mapped_column(String(100))
    algorithm: Mapped[str] = mapped_column(String(60))
    prediction_day: Mapped[int] = mapped_column(Integer)
    data_source: Mapped[str] = mapped_column(String(20))
    metrics: Mapped[dict] = mapped_column(JSON)
    thresholds: Mapped[dict] = mapped_column(JSON)
    features: Mapped[list] = mapped_column(JSON)
    artifact_path: Mapped[str] = mapped_column(String(500))
    is_active: Mapped[bool] = mapped_column(Boolean, default=False)


class Prediction(TimestampMixin, Base):
    __tablename__ = "predictions"
    __table_args__ = (Index("ix_prediction_lookup", "student_id", "course_id", "created_at"),)

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    student_id: Mapped[int] = mapped_column(ForeignKey("student_profiles.id", ondelete="CASCADE"))
    course_id: Mapped[int] = mapped_column(ForeignKey("courses.id", ondelete="CASCADE"))
    model_version_id: Mapped[int] = mapped_column(ForeignKey("model_versions.id"))
    as_of_day: Mapped[int] = mapped_column(Integer)
    risk_probability: Mapped[float] = mapped_column(Float)
    risk_level: Mapped[str] = mapped_column(str_enum("low", "medium", "high", name="risk_level"))
    # Top contributing factors (feature, value, contribution, human-readable reason).
    explanation: Mapped[list] = mapped_column(JSON)
    # Exact feature values the model saw, for audit and debugging.
    features: Mapped[dict] = mapped_column(JSON)

    model_version: Mapped[ModelVersion] = relationship()


class RiskReview(TimestampMixin, Base):
    """Faculty decision on a risk flag. Predictions never act on students automatically."""

    __tablename__ = "risk_reviews"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    prediction_id: Mapped[int] = mapped_column(ForeignKey("predictions.id", ondelete="CASCADE"), index=True)
    reviewer_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    decision: Mapped[str] = mapped_column(str_enum("confirmed", "dismissed", "follow_up", name="review_decision"))
    note: Mapped[str | None] = mapped_column(Text, nullable=True)


class LearningResource(TimestampMixin, Base):
    __tablename__ = "learning_resources"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    topic_id: Mapped[int] = mapped_column(ForeignKey("topics.id", ondelete="CASCADE"), index=True)
    title: Mapped[str] = mapped_column(String(200))
    resource_type: Mapped[str] = mapped_column(
        str_enum("video", "article", "course", "practice", "tutor_quiz", name="resource_type")
    )
    url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    provider: Mapped[str] = mapped_column(String(80))
    difficulty: Mapped[str] = mapped_column(
        str_enum("beginner", "intermediate", "advanced", name="resource_difficulty")
    )
    est_minutes: Mapped[int] = mapped_column(Integer)


class Recommendation(TimestampMixin, Base):
    __tablename__ = "recommendations"
    __table_args__ = (Index("ix_reco_lookup", "student_id", "course_id", "status"),)

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    student_id: Mapped[int] = mapped_column(ForeignKey("student_profiles.id", ondelete="CASCADE"))
    course_id: Mapped[int] = mapped_column(ForeignKey("courses.id", ondelete="CASCADE"))
    resource_id: Mapped[int] = mapped_column(ForeignKey("learning_resources.id", ondelete="CASCADE"))
    rank: Mapped[int] = mapped_column(Integer)
    score: Mapped[float] = mapped_column(Float)
    reason: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(
        str_enum("new", "opened", "completed", "dismissed", name="reco_status"), default="new"
    )
    rating: Mapped[int | None] = mapped_column(SmallInteger, nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), onupdate=func.now())

    resource: Mapped[LearningResource] = relationship()
