"""Import every model so SQLAlchemy metadata (and Alembic autogenerate) can see them."""

from app.models.academic import (
    Assessment,
    AssessmentResult,
    AssessmentTopic,
    Course,
    EngagementDaily,
    Enrollment,
    EnrollmentOutcome,
    FacultyCourse,
    Topic,
    TopicPrerequisite,
)
from app.models.audit import AuditLog
from app.models.ml import LearningResource, ModelVersion, Prediction, Recommendation, RiskReview
from app.models.tutor import ChatMessage, ChatSession, Document, DocumentChunk
from app.models.user import FacultyProfile, StudentProfile, User

__all__ = [
    "Assessment",
    "AssessmentResult",
    "AssessmentTopic",
    "AuditLog",
    "ChatMessage",
    "ChatSession",
    "Course",
    "Document",
    "DocumentChunk",
    "EngagementDaily",
    "Enrollment",
    "EnrollmentOutcome",
    "FacultyCourse",
    "FacultyProfile",
    "LearningResource",
    "ModelVersion",
    "Prediction",
    "Recommendation",
    "RiskReview",
    "StudentProfile",
    "Topic",
    "TopicPrerequisite",
    "User",
]
