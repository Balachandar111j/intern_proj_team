"""Load the exported dataset sample into MySQL and prepare a ready-to-demo platform.

Steps: courses + curriculum -> students + records -> staff accounts -> resources
-> model registry + batch scoring -> recommendations -> course notes for the tutor.

Usage:
    python -m app.seed            # seeds only if the database is empty
"""

from __future__ import annotations

import argparse
import json
import logging
from pathlib import Path

import pandas as pd
from sqlalchemy import func, insert, select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.security import hash_password
from app.db.session import SessionLocal
from app.models import (
    Assessment,
    AssessmentResult,
    AssessmentTopic,
    Course,
    Document,
    EngagementDaily,
    Enrollment,
    EnrollmentOutcome,
    FacultyCourse,
    FacultyProfile,
    LearningResource,
    Prediction,
    StudentProfile,
    Topic,
    TopicPrerequisite,
    User,
)
from app.rag.ingest import ingest
from app.rag.notes_pdf import render_course_notes
from app.seed.curriculum import course_spec, display_name, map_assessments_to_topics
from app.services import predictions, recommendations

log = logging.getLogger("seed")
DEV_DEFAULT_PASSWORD = "EduMind@2026"
DEMO_STUDENT = "student@edumind.demo"
DEMO_STUDENT_2 = "student2@edumind.demo"
FACULTY = "faculty@edumind.demo"
ADMIN = "admin@edumind.demo"


def demo_password() -> str:
    if settings.DEMO_PASSWORD:
        return settings.DEMO_PASSWORD
    if settings.is_production:
        raise SystemExit("Set DEMO_PASSWORD before seeding a production database.")
    return DEV_DEFAULT_PASSWORD


def is_seeded(db: Session) -> bool:
    return (db.scalar(select(func.count()).select_from(Course)) or 0) > 0


def _num(v):
    return None if pd.isna(v) else int(v)


def seed(db: Session, seed_dir: Path, ingest_notes: bool = True) -> dict:
    manifest = json.loads((seed_dir / "manifest.json").read_text())
    source = manifest["data_source"]
    courses_df = pd.read_csv(seed_dir / "courses.csv")
    assess_df = pd.read_csv(seed_dir / "assessments.csv")
    enroll_df = pd.read_csv(seed_dir / "enrollments.csv")
    outcomes_df = pd.read_csv(seed_dir / "outcomes.csv")
    results_df = pd.read_csv(seed_dir / "results.csv")
    clicks_df = pd.read_csv(seed_dir / "clicks.csv")
    password_hash = hash_password(demo_password())

    # --- Courses, topics, assessments ------------------------------------------------
    course_ids: dict[str, int] = {}
    assessment_ids: dict[str, int] = {}
    specs = {}
    for c in courses_df.itertuples():
        c_assess = assess_df[assess_df.course_key == c.course_key].sort_values("due_day", na_position="last")
        graded = c_assess[c_assess.assessment_type != "Exam"]
        spec = course_spec(c.module_code, len(graded))
        specs[c.course_key] = spec
        course = Course(
            code=c.course_key,
            title=spec.title,
            module_code=c.module_code,
            presentation=c.presentation,
            length_days=int(c.length_days),
            description=spec.description,
            data_source=source,
        )
        db.add(course)
        db.flush()
        course_ids[c.course_key] = course.id

        topic_ids = []
        for i, t in enumerate(spec.topics):
            topic = Topic(course_id=course.id, title=t.title, sequence=i + 1, description=t.description)
            db.add(topic)
            db.flush()
            topic_ids.append(topic.id)
        by_title = dict(zip([t.title for t in spec.topics], topic_ids, strict=True))
        for t in spec.topics:
            for p in t.prerequisites:
                db.add(TopicPrerequisite(topic_id=by_title[t.title], prerequisite_id=by_title[p]))
            for r in t.resources:
                db.add(LearningResource(topic_id=by_title[t.title], **r.__dict__))
            db.add(
                LearningResource(
                    topic_id=by_title[t.title],
                    title=f"Practice quiz: {t.title}",
                    resource_type="tutor_quiz",
                    url=None,
                    provider="EduMind AI tutor",
                    difficulty="beginner",
                    est_minutes=15,
                )
            )

        counters = {"TMA": 0, "CMA": 0}
        mapping = map_assessments_to_topics(len(graded), len(topic_ids))
        graded_ids = list(graded.assessment_id.astype(str))
        for a in c_assess.itertuples():
            if a.assessment_type == "Exam":
                title = "Final exam"
            else:
                counters[a.assessment_type] += 1
                title = f"{a.assessment_type} {counters[a.assessment_type]}"
            assessment = Assessment(
                course_id=course.id,
                external_id=str(a.assessment_id),
                title=title,
                assessment_type=a.assessment_type,
                due_day=_num(a.due_day),
                weight=float(a.weight),
            )
            db.add(assessment)
            db.flush()
            assessment_ids[str(a.assessment_id)] = assessment.id
            if a.assessment_type != "Exam":
                topic_idx = mapping[graded_ids.index(str(a.assessment_id))]
                db.add(AssessmentTopic(assessment_id=assessment.id, topic_id=topic_ids[topic_idx]))

    # --- Students and their records ------------------------------------------------------
    student_ids: dict[int, int] = {}
    for key in sorted(enroll_df.student_key.unique()):
        user = User(
            email=f"s{key}@students.edumind.demo",
            full_name=display_name(int(key)),
            password_hash=password_hash,
            role="student",
        )
        db.add(user)
        db.flush()
        profile = StudentProfile(
            user_id=user.id, student_code=f"OU{key}", external_ref=str(key), department="AI & Data Science"
        )
        db.add(profile)
        db.flush()
        student_ids[int(key)] = profile.id

    outcome_of = {(r.student_key, r.course_key): r.final_result for r in outcomes_df.itertuples()}
    for e in enroll_df.itertuples():
        enrollment = Enrollment(
            student_id=student_ids[int(e.student_key)],
            course_id=course_ids[e.course_key],
            registered_day=_num(e.registered_day),
            unregistered_day=_num(e.unregistered_day),
            prev_attempts=int(e.prev_attempts),
            studied_credits=int(e.studied_credits),
        )
        db.add(enrollment)
        db.flush()
        outcome = outcome_of.get((e.student_key, e.course_key))
        if isinstance(outcome, str):
            db.add(EnrollmentOutcome(enrollment_id=enrollment.id, final_result=outcome))

    result_rows = [
        {
            "student_id": student_ids[int(r.student_key)],
            "assessment_id": assessment_ids[str(r.assessment_id)],
            "submitted_day": int(r.submitted_day),
            "score": None if pd.isna(r.score) else float(r.score),
            "is_banked": bool(r.is_banked),
        }
        for r in results_df.itertuples()
    ]
    if result_rows:
        db.execute(insert(AssessmentResult), result_rows)
    click_rows = [
        {
            "student_id": student_ids[int(r.student_key)],
            "course_id": course_ids[r.course_key],
            "day": int(r.day),
            "clicks": int(r.clicks),
        }
        for r in clicks_df.itertuples()
    ]
    for i in range(0, len(click_rows), 5000):
        db.execute(insert(EngagementDaily), click_rows[i : i + 5000])

    # --- Staff accounts --------------------------------------------------------------------
    faculty_user = User(email=FACULTY, full_name="Dr. Ananya Rao", password_hash=password_hash, role="faculty")
    admin_user = User(email=ADMIN, full_name="Platform Admin", password_hash=password_hash, role="admin")
    db.add_all([faculty_user, admin_user])
    db.flush()
    faculty = FacultyProfile(user_id=faculty_user.id, employee_code="FAC001", department="AI & Data Science")
    db.add(faculty)
    db.flush()
    for cid in course_ids.values():
        db.add(FacultyCourse(faculty_id=faculty.id, course_id=cid))
    db.commit()

    # --- Predictions, demo accounts, recommendations ----------------------------------------
    n_pred = predictions.score(db)
    _assign_demo_students(db, list(course_ids.values())[0])
    n_reco = 0
    for e in db.scalars(select(Enrollment)).all():
        n_reco += len(recommendations.generate(db, e.student_id, e.course_id))
    db.commit()

    # --- Course notes for the AI tutor --------------------------------------------------------
    n_docs = 0
    if ingest_notes:
        for key, cid in course_ids.items():
            spec = specs[key]
            if not any(t.notes for t in spec.topics):
                continue
            pdf = render_course_notes(spec, settings.UPLOAD_DIR / f"course-notes-{key}.pdf")
            doc = Document(
                owner_id=faculty_user.id,
                course_id=cid,
                title=f"{spec.title} - Course notes",
                filename=pdf.name,
                storage_path=str(pdf),
                visibility="course",
                status="processing",
            )
            db.add(doc)
            db.commit()
            ingest(db, doc)
            n_docs += doc.status == "ready"

    return {
        "data_source": source,
        "courses": len(course_ids),
        "students": len(student_ids),
        "results": len(result_rows),
        "engagement_rows": len(click_rows),
        "predictions": n_pred,
        "recommendations": n_reco,
        "documents": n_docs,
    }


def _assign_demo_students(db: Session, course_id: int) -> None:
    """Give memorable logins to one high-risk and one on-track student."""
    preds = db.scalars(select(Prediction).where(Prediction.course_id == course_id)).all()

    def engaged(p: Prediction) -> bool:
        f = p.features
        return (f.get("active_days") or 0) >= 8 and (f.get("avg_score") is not None)

    high = sorted([p for p in preds if p.risk_level == "high" and engaged(p)], key=lambda p: p.risk_probability)
    low = sorted(
        [p for p in preds if p.risk_level == "low" and engaged(p)], key=lambda p: -(p.features.get("avg_score") or 0)
    )
    picks = []
    if high:
        picks.append((high[len(high) // 2], DEMO_STUDENT))
    if low:
        picks.append((low[0], DEMO_STUDENT_2))
    for pred, email in picks:
        profile = db.get(StudentProfile, pred.student_id)
        db.get(User, profile.user_id).email = email
    db.commit()


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--seed-dir", type=Path, default=settings.SEED_DATA_DIR)
    parser.add_argument("--skip-notes", action="store_true", help="don't ingest course notes")
    args = parser.parse_args()
    with SessionLocal() as db:
        if is_seeded(db):
            print("Database already has data; skipping seed. To reseed: alembic downgrade base && alembic upgrade head")
            return
        summary = seed(db, args.seed_dir, ingest_notes=not args.skip_notes)
    print(json.dumps(summary, indent=2))
    print(f"\nDemo logins (password: {'from DEMO_PASSWORD' if settings.DEMO_PASSWORD else DEV_DEFAULT_PASSWORD}):")
    for email in (DEMO_STUDENT, DEMO_STUDENT_2, FACULTY, ADMIN):
        print(f"  {email}")


if __name__ == "__main__":
    main()
