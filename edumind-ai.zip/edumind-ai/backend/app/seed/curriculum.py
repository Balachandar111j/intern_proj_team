"""Demo curriculum mapped onto OULAD modules.

OULAD module contents are anonymised (they are only called AAA..GGG), so the
course titles, topics and notes below are an illustrative curriculum. Each
course's real assessments are mapped onto its topics in date order. Edit this
file to model your own department's courses.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Resource:
    title: str
    resource_type: str  # video | article | course | practice | tutor_quiz
    url: str | None
    provider: str
    difficulty: str  # beginner | intermediate | advanced
    est_minutes: int


@dataclass
class TopicSpec:
    title: str
    description: str
    prerequisites: list[str] = field(default_factory=list)
    resources: list[Resource] = field(default_factory=list)
    notes: str = ""


@dataclass
class CourseSpec:
    title: str
    description: str
    topics: list[TopicSpec]


def R(title, rtype, url, provider, difficulty, minutes) -> Resource:
    return Resource(title, rtype, url, provider, difficulty, minutes)


DATA_SCIENCE = CourseSpec(
    title="Data Science Foundations",
    description="Python, data wrangling, statistics, visualisation and first machine-learning models.",
    topics=[
        TopicSpec(
            "Python Programming Basics",
            "Variables, data types, control flow, functions and collections.",
            [],
            [
                R(
                    "The Python Tutorial",
                    "article",
                    "https://docs.python.org/3/tutorial/",
                    "Python.org",
                    "beginner",
                    120,
                ),
                R("Kaggle Learn: Python", "course", "https://www.kaggle.com/learn/python", "Kaggle", "beginner", 300),
            ],
            notes="""Python is the main language of data science because it is readable and has a rich ecosystem of libraries.
A variable is a name bound to a value. Python is dynamically typed: the type belongs to the value, not the name. The core built-in types are int, float, str and bool, plus the collections list, tuple, dict and set.
Lists are ordered and mutable, so you can append and change items. Tuples are ordered and immutable, which makes them safe to use as dictionary keys. Dictionaries map keys to values and give fast lookup by key. Sets store unique items and support union and intersection.
Control flow uses if, elif and else for decisions, for loops to iterate over any iterable, and while loops to repeat until a condition changes. A list comprehension such as [x * 2 for x in values if x > 0] builds a new list in one readable line.
Functions are defined with def. Good functions do one job, take inputs as parameters and return a result rather than printing it. Default parameter values make functions flexible, and docstrings explain what a function does.
Errors are handled with try and except. Catch specific exceptions such as ValueError instead of a bare except, so real bugs are not hidden.
In practice, data scientists write small, tested functions for cleaning and feature engineering, then combine them into pipelines. Readable names and short functions make analysis code easier to review and reuse.""",
        ),
        TopicSpec(
            "Data Wrangling with Pandas",
            "DataFrames, selection, cleaning, grouping and joining tables.",
            ["Python Programming Basics"],
            [
                R(
                    "10 minutes to pandas",
                    "article",
                    "https://pandas.pydata.org/docs/user_guide/10min.html",
                    "pandas docs",
                    "beginner",
                    30,
                ),
                R("Kaggle Learn: Pandas", "course", "https://www.kaggle.com/learn/pandas", "Kaggle", "beginner", 240),
            ],
            notes="""pandas provides the DataFrame, a table with labelled rows and columns, and the Series, a single labelled column.
Data is usually loaded with read_csv. After loading, inspect it with head, info and describe to check column types, missing values and value ranges before doing any analysis.
Selection uses loc for labels and iloc for positions. Boolean filtering, for example df[df["score"] < 40], keeps rows that match a condition.
Cleaning is most of the work. Missing values can be counted with isna().sum(), filled with fillna, or dropped with dropna. The right choice depends on why the value is missing: filling a missing exam score with zero means something very different from filling it with the class average. Duplicates are removed with drop_duplicates, and types are fixed with astype or pd.to_numeric.
groupby splits data into groups, applies a calculation and combines the results. For example df.groupby("course")["score"].mean() gives the average score per course. agg lets you compute several statistics at once.
merge joins two tables on shared keys, like a SQL join. Always check the row count after a merge: an unexpected increase usually means duplicate keys.
In real projects, a wrangling step is written as a function that takes raw data and returns clean data, so the same cleaning runs in training and in production.""",
        ),
        TopicSpec(
            "Statistics and Probability",
            "Descriptive statistics, distributions, probability and hypothesis testing.",
            [],
            [
                R(
                    "Khan Academy: Statistics and probability",
                    "course",
                    "https://www.khanacademy.org/math/statistics-probability",
                    "Khan Academy",
                    "beginner",
                    600,
                ),
                R(
                    "Seeing Theory: visual probability",
                    "article",
                    "https://seeing-theory.brown.edu/",
                    "Brown University",
                    "beginner",
                    60,
                ),
            ],
            notes="""Descriptive statistics summarise data. The mean is the average, the median is the middle value and is robust to outliers, and the mode is the most frequent value. Spread is measured with the range, the variance and the standard deviation.
Probability measures how likely an event is, from 0 (impossible) to 1 (certain). For independent events, the probability that both happen is the product of their probabilities. Conditional probability P(A given B) is the probability of A when we already know B happened.
A distribution describes how values are spread. The normal distribution is symmetric and bell shaped: about 68 percent of values fall within one standard deviation of the mean and about 95 percent within two. Many real variables, such as click counts, are skewed instead, so check the shape before assuming normality.
Sampling matters because we usually observe a sample, not the whole population. The central limit theorem says the mean of many samples is approximately normally distributed, which is why confidence intervals work.
A hypothesis test asks whether an observed effect could easily be due to chance. The p-value is the probability of seeing a result at least this extreme if the null hypothesis were true. A small p-value is evidence against the null hypothesis, but it does not measure how large or important the effect is.
Correlation measures how two variables move together. Correlation does not prove causation: students who study more may also differ in many other ways.""",
        ),
        TopicSpec(
            "Data Visualization",
            "Choosing charts, matplotlib and seaborn, and honest visual design.",
            ["Data Wrangling with Pandas"],
            [
                R(
                    "Kaggle Learn: Data Visualization",
                    "course",
                    "https://www.kaggle.com/learn/data-visualization",
                    "Kaggle",
                    "beginner",
                    240,
                ),
                R(
                    "seaborn tutorial",
                    "article",
                    "https://seaborn.pydata.org/tutorial.html",
                    "seaborn docs",
                    "intermediate",
                    90,
                ),
            ],
            notes="""A chart should answer one clear question. Choose the chart from the question, not from what looks impressive.
Use a line chart to show change over time, such as weekly study activity. Use a bar chart to compare categories, such as average score per subject. Use a histogram to show the distribution of one numeric variable, such as exam scores. Use a scatter plot to show the relationship between two numeric variables, such as study hours against marks. Use a box plot to compare distributions across groups.
matplotlib is the foundation library: you create a figure and axes, then draw on the axes. seaborn builds on matplotlib and makes statistical charts with less code, for example sns.histplot or sns.boxplot directly from a DataFrame.
Honest design matters. Bar charts should start at zero, because a cut-off axis exaggerates differences. Label axes with units, give the chart a title that states the takeaway, and avoid 3D effects that distort size.
Colour should carry meaning. Use one highlight colour to draw attention to the important series and grey for context. Check that the chart is readable for colour-blind viewers.
In dashboards, every chart should lead to an action. A chart that shows a student's falling activity is useful only if it helps someone decide what to do next.""",
        ),
        TopicSpec(
            "Machine Learning Fundamentals",
            "Supervised learning, train/test splits, regression and classification.",
            ["Data Wrangling with Pandas", "Statistics and Probability"],
            [
                R(
                    "Kaggle Learn: Intro to Machine Learning",
                    "course",
                    "https://www.kaggle.com/learn/intro-to-machine-learning",
                    "Kaggle",
                    "beginner",
                    180,
                ),
                R(
                    "Google Machine Learning Crash Course",
                    "course",
                    "https://developers.google.com/machine-learning/crash-course",
                    "Google",
                    "beginner",
                    900,
                ),
                R(
                    "scikit-learn: Getting started",
                    "article",
                    "https://scikit-learn.org/stable/getting_started.html",
                    "scikit-learn docs",
                    "intermediate",
                    45,
                ),
            ],
            notes="""Machine learning builds models that learn patterns from examples. In supervised learning every training example has a known answer, called the label or target.
Regression predicts a number, such as a final mark. Classification predicts a category, such as whether a student will pass or not.
Features are the inputs the model uses. Good features are available at the moment the prediction is made. Using information from the future, such as the final exam score to predict passing, is called data leakage and produces models that look excellent in testing but fail in real use.
Data is split into a training set, used to fit the model, and a test set, used once at the end to estimate real-world performance. When predicting the future, split by time: train on earlier periods and test on a later one.
Overfitting happens when a model memorises the training data, including its noise, and performs poorly on new data. Simpler models, more data and regularisation reduce overfitting. Underfitting happens when the model is too simple to capture the pattern.
Common models include linear and logistic regression, decision trees, random forests and gradient boosting such as XGBoost. Always compare against a simple baseline, such as predicting the average, so you know the model adds real value.
scikit-learn gives every model the same interface: fit to train and predict to make predictions. Pipelines chain preprocessing and the model so the exact same steps run in training and in production.""",
        ),
        TopicSpec(
            "Model Evaluation and Validation",
            "Cross-validation, confusion matrices, precision, recall and calibration.",
            ["Machine Learning Fundamentals"],
            [
                R(
                    "scikit-learn: Cross-validation",
                    "article",
                    "https://scikit-learn.org/stable/modules/cross_validation.html",
                    "scikit-learn docs",
                    "intermediate",
                    60,
                ),
                R(
                    "scikit-learn: Metrics and scoring",
                    "article",
                    "https://scikit-learn.org/stable/modules/model_evaluation.html",
                    "scikit-learn docs",
                    "advanced",
                    90,
                ),
            ],
            notes="""A model is only useful if we can measure how well it works on data it has not seen.
Cross-validation splits the training data into k folds, trains k times, and averages the scores. It gives a more stable estimate than a single split. For time-ordered problems, use a time-based split instead of shuffling.
For classification, the confusion matrix counts true positives, false positives, true negatives and false negatives. Accuracy is the share of correct predictions, but it is misleading when classes are imbalanced: if only 10 percent of students fail, predicting that nobody fails is 90 percent accurate and completely useless.
Precision is the share of flagged cases that were truly positive. Recall is the share of true positives that the model caught. There is a trade-off: lowering the decision threshold catches more at-risk students (higher recall) but also flags more students who were fine (lower precision). The right threshold depends on the cost of each kind of mistake.
ROC-AUC measures how well the model ranks positives above negatives across all thresholds; 0.5 is random and 1.0 is perfect. PR-AUC is more informative when positives are rare.
Calibration asks whether predicted probabilities match reality: among students given a 30 percent risk, about 30 percent should actually be at risk. Calibrated probabilities can be trusted and compared.
Finally, check performance across student groups. A model that works well on average can still make more mistakes for one group, which is a fairness problem.""",
        ),
    ],
)

APPLIED_ML = CourseSpec(
    title="Applied Machine Learning",
    description="Linear algebra, regression, classification, feature engineering, evaluation and an introduction to generative AI.",
    topics=[
        TopicSpec(
            "Linear Algebra for ML",
            "Vectors, matrices, dot products and why models are matrix maths.",
            [],
            [
                R(
                    "Khan Academy: Linear algebra",
                    "course",
                    "https://www.khanacademy.org/math/linear-algebra",
                    "Khan Academy",
                    "intermediate",
                    600,
                ),
            ],
            notes="""Machine learning models represent data as vectors and matrices. A vector is an ordered list of numbers, for example the features of one student. A matrix is a table of numbers, for example the features of all students, with one row per student.
The dot product of two vectors multiplies matching elements and adds the results. A linear model's prediction is the dot product of the feature vector and the weight vector, plus a bias term.
Matrix multiplication applies many dot products at once, which is why a model can score thousands of rows in a single operation. NumPy performs these operations efficiently.
The norm of a vector measures its length. Normalising vectors to length one is common before comparing them. Cosine similarity, the dot product of two normalised vectors, measures how similar their directions are. It is the core operation in semantic search and retrieval-augmented generation, where text is turned into embedding vectors.
Scaling features matters because many algorithms are sensitive to the size of numbers. Standardisation subtracts the mean and divides by the standard deviation so every feature is on a similar scale.""",
        ),
        TopicSpec(
            "Regression Models",
            "Linear regression, loss functions, gradient descent and regularisation.",
            ["Linear Algebra for ML"],
            [
                R(
                    "scikit-learn: Linear models",
                    "article",
                    "https://scikit-learn.org/stable/modules/linear_model.html",
                    "scikit-learn docs",
                    "intermediate",
                    60,
                ),
                R(
                    "Google Machine Learning Crash Course",
                    "course",
                    "https://developers.google.com/machine-learning/crash-course",
                    "Google",
                    "beginner",
                    900,
                ),
            ],
            notes="""Regression predicts a continuous number. Linear regression assumes the target is approximately a weighted sum of the features plus a bias.
The model learns the weights by minimising a loss function. Mean squared error averages the squared differences between predictions and true values; squaring punishes large errors heavily. Mean absolute error is less sensitive to outliers and easier to explain: it is the average size of the error in the target's own units.
Gradient descent finds good weights step by step. It computes the slope of the loss with respect to each weight and moves the weights a small step downhill. The learning rate controls the step size: too large and training diverges, too small and it is very slow.
Regularisation discourages large weights to reduce overfitting. Ridge regression adds the squared size of the weights to the loss; Lasso adds their absolute size and can shrink some weights exactly to zero, which performs feature selection.
Evaluate regression with MAE, RMSE and R squared on a held-out test set, and always compare with a baseline that predicts the training mean.""",
        ),
        TopicSpec(
            "Classification Models",
            "Logistic regression, decision trees, random forests and gradient boosting.",
            ["Regression Models"],
            [
                R(
                    "scikit-learn: Supervised learning",
                    "article",
                    "https://scikit-learn.org/stable/supervised_learning.html",
                    "scikit-learn docs",
                    "intermediate",
                    60,
                ),
                R(
                    "Kaggle Learn: Intermediate Machine Learning",
                    "course",
                    "https://www.kaggle.com/learn/intermediate-machine-learning",
                    "Kaggle",
                    "intermediate",
                    240,
                ),
            ],
            notes="""Classification predicts a category. Logistic regression computes a weighted sum of features like linear regression, then passes it through the sigmoid function to produce a probability between 0 and 1. Its weights are easy to interpret: a positive weight increases the probability of the positive class.
A decision tree asks a sequence of yes or no questions about the features. Trees capture non-linear patterns and interactions, but a single deep tree overfits easily.
A random forest trains many trees on random samples of rows and features and averages their votes. Averaging reduces variance, so forests are robust and need little tuning.
Gradient boosting, used by XGBoost and LightGBM, builds trees one after another, each correcting the errors of the previous ones. It is often the strongest choice for tabular data, but it has more hyperparameters, such as the learning rate, tree depth and number of trees.
Class imbalance is common: far fewer students fail than pass. Options include class weights, choosing the decision threshold carefully, and evaluating with precision, recall and PR-AUC rather than accuracy.
Explainability tools such as SHAP show how much each feature pushed an individual prediction up or down, which helps people trust and check the model.""",
        ),
        TopicSpec(
            "Feature Engineering",
            "Encoding, scaling, aggregation over time and avoiding leakage.",
            [],
            [
                R(
                    "Kaggle Learn: Feature Engineering",
                    "course",
                    "https://www.kaggle.com/learn/feature-engineering",
                    "Kaggle",
                    "intermediate",
                    300,
                ),
                R(
                    "scikit-learn: Preprocessing data",
                    "article",
                    "https://scikit-learn.org/stable/modules/preprocessing.html",
                    "scikit-learn docs",
                    "intermediate",
                    60,
                ),
            ],
            notes="""Feature engineering turns raw data into inputs a model can learn from. Better features usually help more than a more complex model.
Categorical variables must be encoded. One-hot encoding creates one column per category. Ordinal encoding keeps a natural order, such as education level.
Numeric features often need scaling or transformation. Count data such as clicks is usually skewed, so a log transform makes it easier for linear models to use.
Behavioural data is aggregated over time windows: total activity so far, activity in the last two weeks, and the trend between recent and earlier periods. A drop in activity is often a stronger warning sign than a low total.
The most important rule is to avoid leakage. Every feature must only use information available at the prediction time. Compute features with an explicit cut-off date, and fit scalers and imputers on training data only.
In production, the exact same feature code must run when training and when serving predictions. If the two paths compute features differently, the model receives inputs it never saw in training. This is called training-serving skew, and sharing one feature function is the simplest way to prevent it.""",
        ),
        TopicSpec(
            "Model Evaluation Metrics",
            "Precision, recall, ROC and PR curves, calibration and fairness checks.",
            ["Classification Models"],
            [
                R(
                    "scikit-learn: Metrics and scoring",
                    "article",
                    "https://scikit-learn.org/stable/modules/model_evaluation.html",
                    "scikit-learn docs",
                    "advanced",
                    90,
                ),
                R(
                    "scikit-learn: Probability calibration",
                    "article",
                    "https://scikit-learn.org/stable/modules/calibration.html",
                    "scikit-learn docs",
                    "advanced",
                    45,
                ),
            ],
            notes="""Choose metrics that match the decision the model supports.
Precision answers: of the students we flagged, how many really needed help? Recall answers: of the students who needed help, how many did we flag? F1 is the harmonic mean of the two.
The ROC curve plots the true positive rate against the false positive rate at every threshold, and ROC-AUC summarises it in one number. The precision-recall curve is more informative when the positive class is rare.
A model's raw scores are not always good probabilities. Calibration methods such as Platt scaling and isotonic regression adjust the scores so that a predicted 70 percent really means about 70 percent. Calibration is checked with a reliability table that compares predicted and observed rates in bins.
Thresholds turn probabilities into actions. Choose them on validation data using an explicit objective, for example the highest threshold that still catches 85 percent of at-risk students.
Fairness auditing evaluates the same metrics for each student group. Large gaps in recall between groups mean some students are being missed more often, and should be investigated before the model is used.""",
        ),
        TopicSpec(
            "Generative AI and RAG Basics",
            "Large language models, embeddings, vector search and retrieval-augmented generation.",
            ["Feature Engineering"],
            [
                R(
                    "Hugging Face LLM Course",
                    "course",
                    "https://huggingface.co/learn/llm-course/chapter1/1",
                    "Hugging Face",
                    "intermediate",
                    600,
                ),
                R("OpenAI Cookbook", "article", "https://cookbook.openai.com/", "OpenAI", "intermediate", 60),
            ],
            notes="""A large language model predicts the next token of text. Trained on huge amounts of text, it can explain, summarise, translate and write code, but it can also state false information confidently. This is called hallucination.
An embedding is a vector that represents the meaning of a piece of text. Texts with similar meaning have embeddings that point in similar directions, so cosine similarity finds related passages even when they use different words.
A vector database stores embeddings and finds the nearest ones to a query quickly. Metadata filters, such as course or owner, restrict which documents can be searched. In multi-user systems, this filter is how one user is prevented from retrieving another user's private documents.
Retrieval-augmented generation, or RAG, reduces hallucination by grounding answers in trusted documents. The pipeline is: split documents into chunks, embed and index them, embed the user's question, retrieve the most similar chunks, and ask the model to answer only from those chunks with citations.
Good RAG systems say when the documents do not contain the answer instead of guessing. They also treat retrieved text as data, not instructions, to defend against prompt injection hidden inside documents.
RAG quality is measured on two levels: retrieval quality, meaning whether the right chunks were found, and answer faithfulness, meaning whether the answer is supported by those chunks.""",
        ),
    ],
)

CURRICULUM: dict[str, CourseSpec] = {"DDD": DATA_SCIENCE, "FFF": APPLIED_ML}


def course_spec(module_code: str, n_assessments: int) -> CourseSpec:
    """Curriculum for a module; unknown modules get generic units."""
    if module_code in CURRICULUM:
        return CURRICULUM[module_code]
    units = max(3, min(6, n_assessments))
    return CourseSpec(
        title=f"Module {module_code}",
        description="Course imported from OULAD without a curriculum mapping.",
        topics=[TopicSpec(f"Unit {i + 1}", f"Unit {i + 1} of module {module_code}") for i in range(units)],
    )


def map_assessments_to_topics(n_assessments: int, n_topics: int) -> list[int]:
    """Assessment i (in due-date order) -> topic index, spread evenly across topics."""
    return [min(n_topics - 1, (i * n_topics) // max(1, n_assessments)) for i in range(n_assessments)]


FIRST_NAMES = [
    "Aarav",
    "Diya",
    "Kavin",
    "Meera",
    "Arjun",
    "Nila",
    "Rahul",
    "Sneha",
    "Vikram",
    "Ananya",
    "Karthik",
    "Divya",
    "Rohan",
    "Ishita",
    "Siddharth",
    "Lakshmi",
    "Aditya",
    "Pooja",
    "Harish",
    "Keerthana",
    "Liam",
    "Emma",
    "Noah",
    "Olivia",
    "Mateo",
    "Sofia",
    "Yuki",
    "Chen",
    "Amara",
    "Omar",
]
LAST_NAMES = [
    "Kumar",
    "Sharma",
    "Iyer",
    "Reddy",
    "Nair",
    "Patel",
    "Menon",
    "Rao",
    "Das",
    "Singh",
    "Krishnan",
    "Bose",
    "Gupta",
    "Pillai",
    "Varma",
    "Smith",
    "Garcia",
    "Tanaka",
    "Okafor",
    "Haddad",
]


def display_name(key: int) -> str:
    """Deterministic synthetic display name (OULAD has no names)."""
    return f"{FIRST_NAMES[key % len(FIRST_NAMES)]} {LAST_NAMES[(key // 7) % len(LAST_NAMES)]}"
