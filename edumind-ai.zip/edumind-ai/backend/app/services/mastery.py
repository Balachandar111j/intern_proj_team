"""Topic mastery: a transparent, evidence-based baseline.

Each assessment is mapped to a topic. A topic's mastery is the recency-weighted
average of the student's scores on its assessments (0-1). Missed assessments
are reported separately rather than silently counted as zero.

Next step when item-level data is available (e.g. ASSISTments): replace this
with Bayesian Knowledge Tracing, keeping the same output shape.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.models import Assessment, AssessmentResult, AssessmentTopic, Topic, TopicPrerequisite

MASTERED, DEVELOPING = 0.70, 0.50


@dataclass
class TopicMastery:
    topic_id: int
    title: str
    sequence: int
    status: str  # mastered | developing | weak | missed | upcoming
    mastery: float | None
    class_mastery: float | None
    evidence: list[dict] = field(default_factory=list)
    prerequisites: list[int] = field(default_factory=list)
    weak_prerequisites: list[str] = field(default_factory=list)
    next_due_day: int | None = None


def _weighted(scores: list[tuple[float, int]]) -> float | None:
    """Recency-weighted mean of (score 0-100, submitted_day)."""
    if not scores:
        return None
    ordered = sorted(scores, key=lambda s: s[1])
    weights = [1.0 + 0.5 * i for i in range(len(ordered))]  # later evidence counts more
    return sum(w * s / 100 for w, (s, _) in zip(weights, ordered, strict=True)) / sum(weights)


def status_for(mastery: float | None, missed: bool, due_any: bool) -> str:
    if mastery is None:
        return "missed" if missed else ("upcoming" if not due_any else "missed")
    if mastery >= MASTERED:
        return "mastered"
    if mastery >= DEVELOPING:
        return "developing"
    return "weak"


def topic_mastery(db: Session, student_id: int, course_id: int) -> list[TopicMastery]:
    day = settings.PREDICTION_DAY
    topics = db.scalars(select(Topic).where(Topic.course_id == course_id).order_by(Topic.sequence)).all()
    if not topics:
        return []
    topic_ids = [t.id for t in topics]
    links = db.execute(
        select(AssessmentTopic.topic_id, Assessment.id, Assessment.title, Assessment.due_day)
        .join(Assessment, Assessment.id == AssessmentTopic.assessment_id)
        .where(AssessmentTopic.topic_id.in_(topic_ids), Assessment.assessment_type != "Exam")
    ).all()
    assessment_ids = [a_id for _, a_id, _, _ in links]
    results = db.execute(
        select(
            AssessmentResult.student_id,
            AssessmentResult.assessment_id,
            AssessmentResult.score,
            AssessmentResult.submitted_day,
        ).where(AssessmentResult.assessment_id.in_(assessment_ids), AssessmentResult.submitted_day <= day)
    ).all()
    mine = {a: (s, d) for sid, a, s, d in results if sid == student_id and s is not None}
    by_assessment_all: dict[int, list[float]] = {}
    for _, a, s, _ in results:
        if s is not None:
            by_assessment_all.setdefault(a, []).append(s)

    prereqs = db.execute(
        select(TopicPrerequisite.topic_id, TopicPrerequisite.prerequisite_id).where(
            TopicPrerequisite.topic_id.in_(topic_ids)
        )
    ).all()

    out: list[TopicMastery] = []
    for t in topics:
        t_links = [(a_id, title, due) for tid, a_id, title, due in links if tid == t.id]
        due_now = [(a, title, due) for a, title, due in t_links if due is not None and due <= day]
        upcoming = [due for _, _, due in t_links if due is not None and due > day]
        evidence, scores, class_scores, missed = [], [], [], False
        for a_id, title, due in sorted(t_links, key=lambda x: (x[2] is None, x[2])):
            if a_id in mine:
                s, d = mine[a_id]
                scores.append((s, d))
                evidence.append({"assessment": title, "score": s, "submitted_day": d, "due_day": due})
            elif due is not None and due <= day:
                missed = True
                evidence.append({"assessment": title, "score": None, "submitted_day": None, "due_day": due})
            if a_id in by_assessment_all:
                class_scores.extend(by_assessment_all[a_id])
        mastery = _weighted(scores)
        class_m = sum(class_scores) / len(class_scores) / 100 if class_scores else None
        out.append(
            TopicMastery(
                topic_id=t.id,
                title=t.title,
                sequence=t.sequence,
                status=status_for(mastery, missed, bool(due_now)),
                mastery=None if mastery is None else round(mastery, 3),
                class_mastery=None if class_m is None else round(class_m, 3),
                evidence=evidence,
                prerequisites=[p for tid, p in prereqs if tid == t.id],
                next_due_day=min(upcoming) if upcoming else None,
            )
        )
    by_id = {m.topic_id: m for m in out}
    for m in out:
        m.weak_prerequisites = [
            by_id[p].title for p in m.prerequisites if p in by_id and by_id[p].status in ("weak", "missed")
        ]
    return out
