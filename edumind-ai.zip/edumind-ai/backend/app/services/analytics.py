"""Learning analytics for student and faculty dashboards (computed from source records)."""

from __future__ import annotations

from collections import defaultdict
from statistics import mean, median

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.models import Assessment, AssessmentResult, EngagementDaily, Enrollment


def _week(day: int) -> int:
    return day // 7


def course_assessments(db: Session, course_id: int) -> list[Assessment]:
    return list(
        db.scalars(
            select(Assessment)
            .where(Assessment.course_id == course_id)
            .order_by(Assessment.due_day.is_(None), Assessment.due_day)
        ).all()
    )


def cohort_size(db: Session, course_id: int) -> int:
    return db.scalar(select(func.count()).select_from(Enrollment).where(Enrollment.course_id == course_id)) or 0


def assessment_stats(db: Session, course_id: int) -> dict[int, dict]:
    """Per-assessment class average and submission rate (results up to the current day)."""
    n = cohort_size(db, course_id)
    rows = db.execute(
        select(AssessmentResult.assessment_id, func.avg(AssessmentResult.score), func.count())
        .join(Assessment, Assessment.id == AssessmentResult.assessment_id)
        .where(Assessment.course_id == course_id, AssessmentResult.submitted_day <= settings.PREDICTION_DAY)
        .group_by(AssessmentResult.assessment_id)
    ).all()
    return {
        a: {
            "class_avg": round(float(avg), 1) if avg is not None else None,
            "submission_rate": round(cnt / n, 3) if n else None,
        }
        for a, avg, cnt in rows
    }


def weekly_clicks(db: Session, course_id: int, student_id: int | None = None) -> dict[int, float]:
    q = select(EngagementDaily.day, EngagementDaily.clicks).where(
        EngagementDaily.course_id == course_id, EngagementDaily.day <= settings.PREDICTION_DAY
    )
    if student_id is not None:
        q = q.where(EngagementDaily.student_id == student_id)
    weeks: dict[int, float] = defaultdict(float)
    for day, clicks in db.execute(q).all():
        weeks[_week(day)] += clicks
    return dict(weeks)


def student_course_analytics(db: Session, student_id: int, course_id: int) -> dict:
    day = settings.PREDICTION_DAY
    assessments = course_assessments(db, course_id)
    stats = assessment_stats(db, course_id)
    results = {
        r.assessment_id: r
        for r in db.scalars(
            select(AssessmentResult).where(
                AssessmentResult.student_id == student_id,
                AssessmentResult.submitted_day <= day,
            )
        ).all()
    }
    rows = []
    for a in assessments:
        r = results.get(a.id)
        due = a.due_day
        state = "submitted" if r else ("missed" if due is not None and due <= day else "upcoming")
        rows.append(
            {
                "id": a.id,
                "title": a.title,
                "type": a.assessment_type,
                "due_day": due,
                "weight": a.weight,
                "status": state,
                "score": r.score if r else None,
                "submitted_day": r.submitted_day if r else None,
                "late": bool(r and due is not None and r.submitted_day > due),
                "class_avg": stats.get(a.id, {}).get("class_avg"),
                "class_submission_rate": stats.get(a.id, {}).get("submission_rate"),
            }
        )

    mine = weekly_clicks(db, course_id, student_id)
    total = weekly_clicks(db, course_id)
    n = max(1, cohort_size(db, course_id))
    first_week = min([*mine.keys(), *total.keys(), 0])
    weeks = [
        {"week": w, "you": round(mine.get(w, 0)), "class_avg": round(total.get(w, 0) / n, 1)}
        for w in range(first_week, _week(day) + 1)
    ]

    scored = [r["score"] for r in rows if r["score"] is not None]
    due_rows = [r for r in rows if r["type"] != "Exam" and r["due_day"] is not None and r["due_day"] <= day]
    submitted_due = [r for r in due_rows if r["status"] == "submitted"]
    active_days = (
        db.scalar(
            select(func.count())
            .select_from(EngagementDaily)
            .where(
                EngagementDaily.student_id == student_id,
                EngagementDaily.course_id == course_id,
                EngagementDaily.day <= day,
            )
        )
        or 0
    )
    class_active = (
        db.execute(
            select(func.count())
            .select_from(EngagementDaily)
            .where(EngagementDaily.course_id == course_id, EngagementDaily.day <= day)
            .group_by(EngagementDaily.student_id)
        )
        .scalars()
        .all()
    )
    class_scores = [r["class_avg"] for r in rows if r["class_avg"] is not None and r["score"] is not None]

    return {
        "as_of_day": day,
        "kpis": {
            "avg_score": round(mean(scored), 1) if scored else None,
            "class_avg_score": round(mean(class_scores), 1) if class_scores else None,
            "submitted": len(submitted_due),
            "due": len(due_rows),
            "active_days": active_days,
            "class_median_active_days": median(class_active) if class_active else None,
            "total_clicks": round(sum(mine.values())),
        },
        "assessments": rows,
        "weekly_activity": weeks,
    }
