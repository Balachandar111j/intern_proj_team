"""Shape ORM objects into API responses (shared by student and faculty endpoints)."""

from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import Course, Enrollment, Prediction, Recommendation, Topic
from app.schemas.student import MasteryOut, PredictionOut, RecommendationOut, ResourceOut
from app.services.mastery import TopicMastery


def prediction_out(p: Prediction | None) -> PredictionOut | None:
    if p is None:
        return None
    mv = p.model_version
    return PredictionOut(
        id=p.id,
        risk_level=p.risk_level,
        risk_probability=p.risk_probability,
        as_of_day=p.as_of_day,
        model_version=mv.version,
        algorithm=mv.algorithm,
        data_source=mv.data_source,
        thresholds={k: v for k, v in mv.thresholds.items() if k in ("high", "medium")},
        factors=p.explanation,
        created_at=p.created_at.isoformat(),
    )


def mastery_out(items: list[TopicMastery]) -> list[MasteryOut]:
    return [
        MasteryOut(
            topic_id=m.topic_id,
            title=m.title,
            sequence=m.sequence,
            status=m.status,
            mastery=m.mastery,
            class_mastery=m.class_mastery,
            evidence=m.evidence,
            weak_prerequisites=m.weak_prerequisites,
            next_due_day=m.next_due_day,
        )
        for m in items
    ]


def recommendations_out(db: Session, recos: list[Recommendation]) -> list[RecommendationOut]:
    topic_ids = {r.resource.topic_id for r in recos}
    titles = dict(db.execute(select(Topic.id, Topic.title).where(Topic.id.in_(topic_ids))).all()) if topic_ids else {}
    return [
        RecommendationOut(
            id=r.id,
            rank=r.rank,
            score=r.score,
            reason=r.reason,
            status=r.status,
            rating=r.rating,
            topic=titles.get(r.resource.topic_id, ""),
            resource=ResourceOut.model_validate(r.resource),
        )
        for r in recos
    ]


def enrolled_courses(db: Session, student_id: int) -> list[Course]:
    return list(
        db.scalars(
            select(Course)
            .join(Enrollment, Enrollment.course_id == Course.id)
            .where(Enrollment.student_id == student_id)
        ).all()
    )
