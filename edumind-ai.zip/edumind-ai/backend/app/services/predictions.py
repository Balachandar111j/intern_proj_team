"""Batch scoring: build feature frames from MySQL, predict, explain, store.

This mirrors how risk models usually run in production: a scheduled job scores
everyone, stores predictions with the model version and the exact features, and
the web app only reads stored predictions.
"""

from __future__ import annotations

import json
import logging
from functools import lru_cache
from pathlib import Path

import joblib
import pandas as pd
from sqlalchemy import select, update
from sqlalchemy.orm import Session

from app.core.config import settings
from app.ml.features import active_enrollments, compute_features
from app.ml.model import RiskModel
from app.models import (
    Assessment,
    AssessmentResult,
    Course,
    EngagementDaily,
    Enrollment,
    ModelVersion,
    Prediction,
)

log = logging.getLogger(__name__)


def model_dir() -> Path:
    return settings.ARTIFACTS_DIR / "risk_model"


@lru_cache
def load_model() -> RiskModel:
    path = model_dir() / "model.joblib"
    if not path.exists():
        raise FileNotFoundError(f"No trained model at {path}. Run: python -m app.ml.train --data-dir <oulad dir>")
    return joblib.load(path)


@lru_cache
def load_metadata() -> dict:
    return json.loads((model_dir() / "metadata.json").read_text())


def register_active_model(db: Session) -> ModelVersion:
    """Record the artifact on disk in the model registry and mark it active."""
    meta = load_metadata()
    mv = db.scalar(
        select(ModelVersion).where(ModelVersion.name == meta["name"], ModelVersion.version == meta["version"])
    )
    if mv is None:
        mv = ModelVersion(
            name=meta["name"],
            version=meta["version"],
            algorithm=meta["algorithm"],
            prediction_day=meta["prediction_day"],
            data_source=meta["data_source"],
            metrics={
                "test": {k: v for k, v in meta["test"].items() if k != "calibration"},
                "comparison": meta["comparison"],
            },
            thresholds=meta["thresholds"],
            features=meta["features"],
            artifact_path=str(model_dir() / "model.joblib"),
        )
        db.add(mv)
        db.flush()
    db.execute(update(ModelVersion).where(ModelVersion.id != mv.id).values(is_active=False))
    mv.is_active = True
    return mv


def frames_from_db(db: Session, course_ids: list[int] | None = None) -> dict[str, pd.DataFrame]:
    """Build the four feature-contract frames from MySQL (keys are DB ids)."""
    course_q = select(Course.id, Course.code)
    if course_ids:
        course_q = course_q.where(Course.id.in_(course_ids))
    courses = pd.DataFrame(db.execute(course_q).all(), columns=["course_id", "course_key"])
    ids = courses.course_id.tolist()
    key_of = dict(zip(courses.course_id, courses.course_key, strict=True))

    enroll = pd.DataFrame(
        db.execute(
            select(
                Enrollment.student_id,
                Enrollment.course_id,
                Enrollment.registered_day,
                Enrollment.unregistered_day,
                Enrollment.prev_attempts,
                Enrollment.studied_credits,
            ).where(Enrollment.course_id.in_(ids))
        ).all(),
        columns=["student_key", "course_id", "registered_day", "unregistered_day", "prev_attempts", "studied_credits"],
    )
    assess = pd.DataFrame(
        db.execute(
            select(
                Assessment.id, Assessment.course_id, Assessment.assessment_type, Assessment.due_day, Assessment.weight
            ).where(Assessment.course_id.in_(ids))
        ).all(),
        columns=["assessment_id", "course_id", "assessment_type", "due_day", "weight"],
    )
    results = pd.DataFrame(
        db.execute(
            select(
                AssessmentResult.student_id,
                AssessmentResult.assessment_id,
                AssessmentResult.submitted_day,
                AssessmentResult.score,
                AssessmentResult.is_banked,
            )
            .join(Assessment, Assessment.id == AssessmentResult.assessment_id)
            .where(Assessment.course_id.in_(ids))
        ).all(),
        columns=["student_key", "assessment_id", "submitted_day", "score", "is_banked"],
    )
    clicks = pd.DataFrame(
        db.execute(
            select(
                EngagementDaily.student_id, EngagementDaily.course_id, EngagementDaily.day, EngagementDaily.clicks
            ).where(EngagementDaily.course_id.in_(ids))
        ).all(),
        columns=["student_key", "course_id", "day", "clicks"],
    )
    for df in (enroll, assess, clicks):
        df["course_key"] = df.course_id.map(key_of)
    assess["assessment_id"] = assess.assessment_id.astype(str)
    results["assessment_id"] = results.assessment_id.astype(str)
    for col in ("registered_day", "unregistered_day", "due_day"):
        for df in (enroll, assess):
            if col in df:
                df[col] = pd.to_numeric(df[col], errors="coerce")
    results["score"] = pd.to_numeric(results.score, errors="coerce")
    return {"courses": courses, "enrollments": enroll, "assessments": assess, "results": results, "clicks": clicks}


def score(db: Session, course_ids: list[int] | None = None, as_of_day: int | None = None) -> int:
    """Score every active enrollment and store predictions. Returns the count."""
    day = settings.PREDICTION_DAY if as_of_day is None else as_of_day
    model = load_model()
    mv = register_active_model(db)
    frames = frames_from_db(db, course_ids)
    active = active_enrollments(frames["enrollments"], day)
    if active.empty:
        db.commit()
        return 0
    feats = compute_features(active, frames["assessments"], frames["results"], frames["clicks"], day)
    X = feats[model.feature_columns]
    probs = model.predict_proba(X)
    contrib = model.contributions(X)
    course_id_of = dict(zip(frames["courses"].course_key, frames["courses"].course_id, strict=True))

    rows = []
    for i, row in feats.iterrows():
        p = float(probs[i])
        rows.append(
            Prediction(
                student_id=int(row.student_key),
                course_id=int(course_id_of[row.course_key]),
                model_version_id=mv.id,
                as_of_day=day,
                risk_probability=round(p, 4),
                risk_level=model.risk_level(p),
                explanation=model.explain_row(row, contrib.loc[i]),
                features={c: (None if pd.isna(row[c]) else float(row[c])) for c in model.feature_columns},
            )
        )
    db.add_all(rows)
    db.commit()
    log.info("Stored %d predictions with model %s", len(rows), mv.version)
    return len(rows)


def latest_prediction(db: Session, student_id: int, course_id: int) -> Prediction | None:
    return db.scalar(
        select(Prediction)
        .where(Prediction.student_id == student_id, Prediction.course_id == course_id)
        .order_by(Prediction.created_at.desc(), Prediction.id.desc())
        .limit(1)
    )


def latest_predictions_for_course(db: Session, course_id: int) -> dict[int, Prediction]:
    """Latest prediction per student in a course."""
    preds = db.scalars(select(Prediction).where(Prediction.course_id == course_id).order_by(Prediction.id)).all()
    latest: dict[int, Prediction] = {}
    for p in preds:
        latest[p.student_id] = p
    return latest
