"""Content-based recommendation engine with explainable ranking.

Pipeline: candidate generation -> eligibility filtering -> scoring -> diversity
-> stored with a human-readable reason. Every impression and status change is
kept, so later we can measure whether recommendations are followed and whether
scores improve afterwards (association, not proof of cause).

Collaborative filtering is deliberately not used yet: it needs real interaction
history from many students, which a new platform does not have (cold start).
"""

from __future__ import annotations

from dataclasses import dataclass

from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from app.models import LearningResource, Recommendation, Topic
from app.services.mastery import TopicMastery, topic_mastery
from app.services.predictions import latest_prediction

NEED = {"weak": 1.0, "missed": 1.0, "developing": 0.6, "upcoming": 0.35, "mastered": 0.0}
MAX_RESULTS, MAX_PER_TOPIC, MAX_QUIZZES = 6, 2, 2


@dataclass
class Candidate:
    resource: LearningResource
    topic: TopicMastery
    score: float
    reason: str


def difficulty_fit(mastery: float | None, difficulty: str, status: str) -> float:
    if status == "upcoming":
        return {"beginner": 0.9, "intermediate": 0.8, "advanced": 0.4}[difficulty]
    if mastery is None or mastery < 0.5:
        return {"beginner": 1.0, "intermediate": 0.6, "advanced": 0.2}[difficulty]
    return {"beginner": 0.7, "intermediate": 1.0, "advanced": 0.6}[difficulty]


def _reason(t: TopicMastery, is_prereq_of: list[str], resource: LearningResource) -> str:
    if t.status == "missed":
        base = f"You haven't submitted the {t.title} assessment yet"
    elif t.status == "weak":
        base = f"Your mastery of {t.title} is {t.mastery:.0%} (class {t.class_mastery or 0:.0%})"
    elif t.status == "developing":
        base = f"You're developing in {t.title} ({t.mastery:.0%}); a little practice will lock it in"
    else:
        base = f"{t.title} is coming up next (assessment due day {t.next_due_day})"
    if is_prereq_of:
        base += f". It's a prerequisite for {', '.join(is_prereq_of)}"
    if resource.resource_type == "tutor_quiz":
        base += ". A short quiz with the AI tutor will show what to revise"
    return base + "."


def generate(db: Session, student_id: int, course_id: int) -> list[Recommendation]:
    mastery = topic_mastery(db, student_id, course_id)
    if not mastery:
        return []
    history = db.scalars(
        select(Recommendation).where(Recommendation.student_id == student_id, Recommendation.course_id == course_id)
    ).all()
    done = {r.resource_id for r in history if r.status in ("completed", "dismissed")}
    disliked_types = {r.resource.resource_type for r in history if r.rating is not None and r.rating <= 2}
    prediction = latest_prediction(db, student_id, course_id)
    high_risk = prediction is not None and prediction.risk_level == "high"

    # Topics this one is a prerequisite for, among the student's weak topics.
    weak_titles = {m.topic_id: m.title for m in mastery if m.status in ("weak", "missed")}
    prereq_of: dict[int, list[str]] = {}
    for m in mastery:
        for p in m.prerequisites:
            if m.topic_id in weak_titles:
                prereq_of.setdefault(p, []).append(m.title)

    # Candidate topics: needs work, or the next upcoming one.
    upcoming = sorted(
        [m for m in mastery if m.status == "upcoming" and m.next_due_day is not None],
        key=lambda m: m.next_due_day,
    )[:1]
    candidates_topics = [m for m in mastery if NEED[m.status] >= 0.6] + upcoming
    topic_ids = [m.topic_id for m in candidates_topics]
    resources = db.scalars(select(LearningResource).where(LearningResource.topic_id.in_(topic_ids))).all()
    by_topic = {m.topic_id: m for m in candidates_topics}

    scored: list[Candidate] = []
    for r in resources:
        if r.id in done:
            continue
        t = by_topic[r.topic_id]
        prereq_bonus = 0.3 if prereq_of.get(t.topic_id) else 0.0
        s = 0.55 * NEED[t.status] + 0.25 * difficulty_fit(t.mastery, r.difficulty, t.status) + prereq_bonus
        if r.est_minutes > 180:
            s -= 0.1  # long courses are a big ask mid-term
        if high_risk and r.est_minutes <= 45:
            s += 0.1  # quick wins first when a student is struggling
        if r.resource_type in disliked_types:
            s -= 0.2
        scored.append(Candidate(r, t, round(s, 4), _reason(t, prereq_of.get(t.topic_id, []), r)))

    scored.sort(key=lambda c: (-c.score, c.resource.est_minutes))
    picked, per_topic = [], {}
    for c in scored:
        if per_topic.get(c.topic.topic_id, 0) >= MAX_PER_TOPIC:
            continue
        if (
            c.resource.resource_type == "tutor_quiz"
            and sum(p.resource.resource_type == "tutor_quiz" for p in picked) >= MAX_QUIZZES
        ):
            continue
        picked.append(c)
        per_topic[c.topic.topic_id] = per_topic.get(c.topic.topic_id, 0) + 1
        if len(picked) >= MAX_RESULTS:
            break

    # Replace previous unopened suggestions; keep history of opened/completed ones.
    db.execute(
        delete(Recommendation).where(
            Recommendation.student_id == student_id,
            Recommendation.course_id == course_id,
            Recommendation.status == "new",
        )
    )
    recos = [
        Recommendation(
            student_id=student_id,
            course_id=course_id,
            resource_id=c.resource.id,
            rank=i + 1,
            score=c.score,
            reason=c.reason,
            status="new",
        )
        for i, c in enumerate(picked)
    ]
    db.add_all(recos)
    db.flush()
    return recos


def current(db: Session, student_id: int, course_id: int) -> list[Recommendation]:
    return list(
        db.scalars(
            select(Recommendation)
            .where(
                Recommendation.student_id == student_id,
                Recommendation.course_id == course_id,
                Recommendation.status.in_(("new", "opened")),
            )
            .order_by(Recommendation.rank)
        ).all()
    )


def topic_title(db: Session, topic_id: int) -> str:
    t = db.get(Topic, topic_id)
    return t.title if t else ""
