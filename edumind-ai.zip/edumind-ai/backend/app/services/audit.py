from sqlalchemy.orm import Session

from app.models import AuditLog


def record(
    db: Session,
    action: str,
    actor_id: int | None = None,
    resource_type: str | None = None,
    resource_id: str | int | None = None,
    detail: dict | None = None,
    ip_address: str | None = None,
) -> None:
    """Add an audit entry to the current transaction (the caller commits)."""
    db.add(
        AuditLog(
            actor_id=actor_id,
            action=action,
            resource_type=resource_type,
            resource_id=str(resource_id) if resource_id is not None else None,
            detail=detail,
            ip_address=ip_address,
        )
    )
