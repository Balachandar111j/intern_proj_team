import secrets
from datetime import UTC, datetime

from fastapi import APIRouter, Depends, HTTPException, Request, Response, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.deps import client_ip, get_current_user
from app.core.rate_limit import RateLimiter
from app.core.security import create_access_token, hash_password, verify_password
from app.db.session import get_db
from app.models import StudentProfile, User
from app.schemas.auth import LoginRequest, RegisterRequest, TokenOut, UserOut
from app.services import audit

router = APIRouter(prefix="/auth", tags=["Authentication"])
login_limiter = RateLimiter(limit=settings.LOGIN_RATE_LIMIT_PER_MINUTE)

INVALID_LOGIN = HTTPException(status.HTTP_401_UNAUTHORIZED, "Incorrect email or password")


def _authenticate(db: Session, request: Request, email: str, password: str) -> User:
    email = email.strip().lower()
    login_limiter.check(f"{client_ip(request)}|{email}")
    user = db.scalar(select(User).where(func.lower(User.email) == email))
    if not verify_password(password, user.password_hash if user else None) or not user:
        audit.record(db, "login_failed", detail={"email": email}, ip_address=client_ip(request))
        db.commit()
        raise INVALID_LOGIN
    if not user.is_active:
        raise INVALID_LOGIN
    user.last_login_at = datetime.now(UTC).replace(tzinfo=None)
    audit.record(db, "login", actor_id=user.id, ip_address=client_ip(request))
    db.commit()
    return user


def _set_session_cookie(response: Response, token: str) -> None:
    response.set_cookie(
        key=settings.COOKIE_NAME,
        value=token,
        max_age=settings.JWT_EXPIRE_MINUTES * 60,
        httponly=True,  # not readable from JavaScript, so XSS can't steal it
        secure=settings.COOKIE_SECURE,  # HTTPS only in production
        samesite="lax",
        path="/",
    )


@router.post("/login", response_model=UserOut)
def login(body: LoginRequest, request: Request, response: Response, db: Session = Depends(get_db)):
    """Browser login: sets an HttpOnly session cookie."""
    user = _authenticate(db, request, body.email, body.password)
    _set_session_cookie(response, create_access_token(user.id, user.role))
    return user


@router.post("/token", response_model=TokenOut)
def token(
    request: Request,
    form: OAuth2PasswordRequestForm = Depends(),
    db: Session = Depends(get_db),
):
    """API-client login (used by the Swagger 'Authorize' button): returns a bearer token."""
    user = _authenticate(db, request, form.username, form.password)
    return TokenOut(access_token=create_access_token(user.id, user.role))


@router.post("/logout", status_code=status.HTTP_204_NO_CONTENT)
def logout(response: Response):
    response.delete_cookie(settings.COOKIE_NAME, path="/")


@router.get("/me", response_model=UserOut)
def me(user: User = Depends(get_current_user)):
    return user


@router.post("/register", response_model=UserOut, status_code=status.HTTP_201_CREATED)
def register(body: RegisterRequest, request: Request, response: Response, db: Session = Depends(get_db)):
    """Self-registration creates a student account with no academic records yet.
    Faculty and admin accounts are provisioned by an administrator."""
    login_limiter.check(f"register|{client_ip(request)}")
    user = User(
        email=body.email.lower(),
        full_name=body.full_name,
        password_hash=hash_password(body.password),
        role="student",
    )
    db.add(user)
    try:
        db.flush()
        db.add(StudentProfile(user_id=user.id, student_code=f"SELF-{secrets.token_hex(4).upper()}"))
        audit.record(db, "register", actor_id=user.id, ip_address=client_ip(request))
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status.HTTP_409_CONFLICT, "An account with this email already exists") from None
    _set_session_cookie(response, create_access_token(user.id, user.role))
    return user
