"""Administrator endpoints: platform overview, model monitoring and rescoring."""

from fastapi import APIRouter, Depends, Request
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.deps import client_ip, require_roles
from app.db.session import get_db
from app.models import (
    AuditLog,
    Course,
    Document,
    DocumentChunk,
    Enrollment,
    EnrollmentOutcome,
    ModelVersion,
    User,
)
from app.services import audit, predictions

router = APIRouter(prefix="/admin", tags=["Admin"])


def _backtest(db: Session) -> dict:
    """Compare the latest predictions with known final results of the seeded (historical) students.

    The seeded students come from a course presentation the model never trained on,
    so this is an honest out-of-time check of the live predictions.
    """
    rows = db.execute(
        select(Enrollment.student_id, Enrollment.course_id, EnrollmentOutcome.final_result).join(
            EnrollmentOutcome, EnrollmentOutcome.enrollment_id == Enrollment.id
        )
    ).all()
    latest = {}
    for cid in {c for _, c, _ in rows}:
        for sid, p in predictions.latest_predictions_for_course(db, cid).items():
            latest[(sid, cid)] = p
    pairs = [(latest[(s, c)], r) for s, c, r in rows if (s, c) in latest]
    if not pairs:
        return {"n": 0}

    def summary(flagged_levels: set[str]) -> dict:
        tp = sum(1 for p, r in pairs if p.risk_level in flagged_levels and r in ("Fail", "Withdrawn"))
        fp = sum(1 for p, r in pairs if p.risk_level in flagged_levels and r not in ("Fail", "Withdrawn"))
        fn = sum(1 for p, r in pairs if p.risk_level not in flagged_levels and r in ("Fail", "Withdrawn"))
        return {
            "flagged": tp + fp,
            "precision": round(tp / (tp + fp), 3) if tp + fp else None,
            "recall": round(tp / (tp + fn), 3) if tp + fn else None,
        }

    at_risk = sum(1 for _, r in pairs if r in ("Fail", "Withdrawn"))
    return {
        "n": len(pairs),
        "actual_at_risk_rate": round(at_risk / len(pairs), 3),
        "high": summary({"high"}),
        "medium_or_high": summary({"high", "medium"}),
    }


@router.get("/overview")
def overview(_: User = Depends(require_roles("admin")), db: Session = Depends(get_db)) -> dict:
    users = dict(db.execute(select(User.role, func.count()).group_by(User.role)).all())
    model = db.scalar(select(ModelVersion).where(ModelVersion.is_active.is_(True)))
    recent = db.scalars(select(AuditLog).order_by(AuditLog.id.desc()).limit(15)).all()
    actor_ids = {a.actor_id for a in recent if a.actor_id}
    emails = dict(db.execute(select(User.id, User.email).where(User.id.in_(actor_ids))).all()) if actor_ids else {}
    return {
        "as_of_day": settings.PREDICTION_DAY,
        "users": users,
        "courses": db.scalar(select(func.count()).select_from(Course)),
        "documents": db.scalar(select(func.count()).select_from(Document)),
        "chunks": db.scalar(select(func.count()).select_from(DocumentChunk)),
        "llm_provider": settings.effective_llm_provider,
        "model": None
        if model is None
        else {
            "version": model.version,
            "algorithm": model.algorithm,
            "data_source": model.data_source,
            "prediction_day": model.prediction_day,
            "thresholds": model.thresholds,
            "test_metrics": model.metrics.get("test"),
            "comparison": model.metrics.get("comparison"),
        },
        "backtest": _backtest(db),
        "recent_activity": [
            {
                "action": a.action,
                "actor": emails.get(a.actor_id),
                "resource": a.resource_type,
                "at": a.created_at.isoformat(),
            }
            for a in recent
        ],
    }


@router.post("/rescore")
def rescore(request: Request, user: User = Depends(require_roles("admin")), db: Session = Depends(get_db)) -> dict:
    count = predictions.score(db)
    audit.record(db, "rescore", actor_id=user.id, detail={"predictions": count}, ip_address=client_ip(request))
    db.commit()
    return {"predictions": count}
