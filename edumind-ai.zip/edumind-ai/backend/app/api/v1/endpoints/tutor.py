"""AI tutor: document uploads, chat sessions and grounded answers."""

import uuid
from typing import Literal

from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, UploadFile, status
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.deps import client_ip, faculty_course_ids, get_current_user
from app.core.rate_limit import RateLimiter
from app.db.session import get_db
from app.models import (
    ChatMessage,
    ChatSession,
    Course,
    Document,
    DocumentChunk,
    Enrollment,
    FacultyProfile,
    StudentProfile,
    User,
)
from app.rag import store
from app.rag.graph import run_tutor
from app.rag.ingest import ingest
from app.services import audit

router = APIRouter(prefix="/tutor", tags=["AI tutor"])
tutor_limiter = RateLimiter(limit=settings.TUTOR_RATE_LIMIT_PER_MINUTE)


class SessionIn(BaseModel):
    course_id: int


class MessageIn(BaseModel):
    content: str = Field(min_length=2, max_length=2000)
    mode: Literal["explain", "quiz"] = "explain"
    level: Literal["beginner", "intermediate", "advanced"] = "intermediate"


# --- Access helpers -------------------------------------------------------------------
def _student_id(db: Session, user: User) -> int | None:
    if user.role != "student":
        return None
    return db.scalar(select(StudentProfile.id).where(StudentProfile.user_id == user.id))


def accessible_course_ids(db: Session, user: User) -> set[int]:
    if user.role == "admin":
        return set(db.scalars(select(Course.id)))
    if user.role == "faculty":
        faculty = db.scalar(select(FacultyProfile).where(FacultyProfile.user_id == user.id))
        return faculty_course_ids(db, faculty) if faculty else set()
    sid = _student_id(db, user)
    return set(db.scalars(select(Enrollment.course_id).where(Enrollment.student_id == sid))) if sid else set()


def _require_course(db: Session, user: User, course_id: int) -> Course:
    if course_id not in accessible_course_ids(db, user):
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Course not found")
    return db.get(Course, course_id)


def _own_session(db: Session, user: User, session_id: int) -> ChatSession:
    session = db.get(ChatSession, session_id)
    if session is None or session.user_id != user.id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Chat not found")
    return session


def _doc_out(d: Document, user: User) -> dict:
    return {
        "id": d.id,
        "title": d.title,
        "course_id": d.course_id,
        "visibility": d.visibility,
        "status": d.status,
        "page_count": d.page_count,
        "chunk_count": d.chunk_count,
        "error": d.error,
        "is_mine": d.owner_id == user.id,
        "created_at": d.created_at.isoformat(),
    }


# --- Courses and documents ------------------------------------------------------------------
@router.get("/courses")
def tutor_courses(user: User = Depends(get_current_user), db: Session = Depends(get_db)) -> list[dict]:
    ids = accessible_course_ids(db, user)
    courses = db.scalars(select(Course).where(Course.id.in_(ids)).order_by(Course.id)).all() if ids else []
    return [{"course_id": c.id, "code": c.code, "title": c.title} for c in courses]


@router.get("/documents")
def list_documents(course_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)) -> list[dict]:
    _require_course(db, user, course_id)
    docs = db.scalars(
        select(Document)
        .where(Document.course_id == course_id)
        .where((Document.visibility == "course") | (Document.owner_id == user.id))
        .order_by(Document.id.desc())
    ).all()
    return [_doc_out(d, user) for d in docs]


@router.post("/documents", status_code=status.HTTP_201_CREATED)
async def upload_document(
    request: Request,
    course_id: int = Form(...),
    visibility: Literal["private", "course"] = Form("private"),
    title: str | None = Form(default=None, max_length=200),
    file: UploadFile = File(...),
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> dict:
    _require_course(db, user, course_id)
    if visibility == "course" and user.role == "student":
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Only faculty can share documents with the whole course")
    if not (file.filename or "").lower().endswith(".pdf"):
        raise HTTPException(status.HTTP_415_UNSUPPORTED_MEDIA_TYPE, "Only PDF files are supported")

    limit = settings.MAX_UPLOAD_MB * 1024 * 1024
    settings.UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    path = settings.UPLOAD_DIR / f"{uuid.uuid4().hex}.pdf"  # never trust the client's filename
    size = 0
    with path.open("wb") as out:
        while chunk := await file.read(1024 * 1024):
            size += len(chunk)
            if size > limit:
                out.close()
                path.unlink(missing_ok=True)
                raise HTTPException(
                    status.HTTP_413_CONTENT_TOO_LARGE, f"File is larger than {settings.MAX_UPLOAD_MB} MB"
                )
            out.write(chunk)

    doc = Document(
        owner_id=user.id,
        course_id=course_id,
        title=(title or file.filename or "Document")[:200],
        filename=(file.filename or "upload.pdf")[:255],
        storage_path=str(path),
        visibility=visibility,
    )
    db.add(doc)
    audit.record(
        db,
        "document_upload",
        actor_id=user.id,
        resource_type="document",
        ip_address=client_ip(request),
        detail={"course_id": course_id, "visibility": visibility, "bytes": size},
    )
    db.commit()
    ingest(db, doc)  # synchronous for small files; move to a task queue for large ones
    if doc.status == "failed":
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_CONTENT, doc.error or "Could not process the document")
    return _doc_out(doc, user)


@router.delete("/documents/{document_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_document(
    document_id: int, request: Request, user: User = Depends(get_current_user), db: Session = Depends(get_db)
) -> None:
    doc = db.get(Document, document_id)
    if doc is None or (doc.owner_id != user.id and user.role != "admin"):
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Document not found")
    chunk_ids = list(db.scalars(select(DocumentChunk.id).where(DocumentChunk.document_id == doc.id)))
    store.delete_chunks(chunk_ids)
    from pathlib import Path

    Path(doc.storage_path).unlink(missing_ok=True)
    db.delete(doc)
    audit.record(
        db,
        "document_delete",
        actor_id=user.id,
        resource_type="document",
        resource_id=document_id,
        ip_address=client_ip(request),
    )
    db.commit()


# --- Chat -------------------------------------------------------------------------------------
@router.get("/sessions")
def list_sessions(course_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)) -> list[dict]:
    _require_course(db, user, course_id)
    sessions = db.scalars(
        select(ChatSession)
        .where(ChatSession.user_id == user.id, ChatSession.course_id == course_id)
        .order_by(ChatSession.id.desc())
    ).all()
    return [{"id": s.id, "title": s.title, "created_at": s.created_at.isoformat()} for s in sessions]


@router.post("/sessions", status_code=status.HTTP_201_CREATED)
def create_session(body: SessionIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)) -> dict:
    _require_course(db, user, body.course_id)
    s = ChatSession(user_id=user.id, course_id=body.course_id, title="New chat")
    db.add(s)
    db.commit()
    return {"id": s.id, "title": s.title, "created_at": s.created_at.isoformat()}


@router.get("/sessions/{session_id}/messages")
def list_messages(session_id: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)) -> list[dict]:
    _own_session(db, user, session_id)
    msgs = db.scalars(select(ChatMessage).where(ChatMessage.session_id == session_id).order_by(ChatMessage.id)).all()
    return [
        {
            "id": m.id,
            "role": m.role,
            "content": m.content,
            "citations": m.citations or [],
            "meta": m.meta or {},
            "created_at": m.created_at.isoformat(),
        }
        for m in msgs
    ]


@router.post("/sessions/{session_id}/messages")
def ask(
    session_id: int, body: MessageIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)
) -> dict:
    tutor_limiter.check(f"tutor|{user.id}")
    session = _own_session(db, user, session_id)
    course = _require_course(db, user, session.course_id)
    history = [
        {"role": m.role, "content": m.content}
        for m in db.scalars(
            select(ChatMessage).where(ChatMessage.session_id == session.id).order_by(ChatMessage.id.desc()).limit(4)
        ).all()[::-1]
    ]
    db.add(
        ChatMessage(
            session_id=session.id, role="user", content=body.content, meta={"mode": body.mode, "level": body.level}
        )
    )
    if session.title == "New chat":
        session.title = body.content[:80]
    db.commit()

    result = run_tutor(
        {
            "question": body.content,
            "mode": body.mode,
            "level": body.level,
            "user_id": user.id,
            "course_id": course.id,
            "course_title": course.title,
            "history": history,
        },
        db=db,
        student_id=_student_id(db, user),
    )
    reply = ChatMessage(
        session_id=session.id,
        role="assistant",
        content=result["answer"],
        citations=result.get("citations", []),
        meta={
            "provider": result.get("provider"),
            "model": result.get("model"),
            "grounded": result.get("grounded"),
            "weak_topics": result.get("weak_topics", []),
            "mode": body.mode,
            "level": body.level,
        },
    )
    db.add(reply)
    db.commit()
    return {
        "id": reply.id,
        "role": "assistant",
        "content": reply.content,
        "citations": reply.citations,
        "meta": reply.meta,
        "created_at": reply.created_at.isoformat(),
    }
