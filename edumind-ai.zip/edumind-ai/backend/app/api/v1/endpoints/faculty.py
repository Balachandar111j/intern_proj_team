"""Faculty endpoints: only courses the faculty member teaches are visible."""

from collections import Counter
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.deps import client_ip, ensure_faculty_teaches, faculty_course_ids, get_current_faculty
from app.db.session import get_db
from app.models import (
    Course,
    Enrollment,
    FacultyProfile,
    Prediction,
    RiskReview,
    StudentProfile,
    User,
)
from app.services import analytics, audit
from app.services.mastery import topic_mastery
from app.services.predictions import latest_predictions_for_course
from app.services.views import mastery_out, prediction_out

router = APIRouter(prefix="/faculty", tags=["Faculty"])


class ReviewIn(BaseModel):
    decision: Literal["confirmed", "dismissed", "follow_up"]
    note: str | None = Field(default=None, max_length=2000)


def _reviews_by_prediction(db: Session, prediction_ids: list[int]) -> dict[int, RiskReview]:
    if not prediction_ids:
        return {}
    reviews = db.scalars(
        select(RiskReview).where(RiskReview.prediction_id.in_(prediction_ids)).order_by(RiskReview.id)
    ).all()
    return {r.prediction_id: r for r in reviews}  # latest review wins


@router.get("/courses")
def my_courses(faculty: FacultyProfile = Depends(get_current_faculty), db: Session = Depends(get_db)) -> list[dict]:
    out = []
    for cid in sorted(faculty_course_ids(db, faculty)):
        c = db.get(Course, cid)
        latest = latest_predictions_for_course(db, cid)
        dist = Counter(p.risk_level for p in latest.values())
        out.append(
            {
                "course_id": c.id,
                "code": c.code,
                "title": c.title,
                "data_source": c.data_source,
                "students": analytics.cohort_size(db, cid),
                "as_of_day": settings.PREDICTION_DAY,
                "risk_distribution": {k: dist.get(k, 0) for k in ("high", "medium", "low")},
            }
        )
    return out


@router.get("/courses/{course_id}/students")
def course_students(
    course_id: int,
    risk: Literal["high", "medium", "low"] | None = Query(default=None),
    faculty: FacultyProfile = Depends(get_current_faculty),
    db: Session = Depends(get_db),
) -> list[dict]:
    ensure_faculty_teaches(db, faculty, course_id)
    latest = latest_predictions_for_course(db, course_id)
    reviews = _reviews_by_prediction(db, [p.id for p in latest.values()])
    rows = db.execute(
        select(StudentProfile.id, StudentProfile.student_code, User.full_name)
        .join(Enrollment, Enrollment.student_id == StudentProfile.id)
        .join(User, User.id == StudentProfile.user_id)
        .where(Enrollment.course_id == course_id)
    ).all()
    out = []
    for sid, code, name in rows:
        p = latest.get(sid)
        if risk and (p is None or p.risk_level != risk):
            continue
        f = p.features if p else {}
        review = reviews.get(p.id) if p else None
        top = next((x for x in (p.explanation if p else []) if x["direction"] == "increases_risk"), None)
        out.append(
            {
                "student_id": sid,
                "student_code": code,
                "full_name": name,
                "prediction_id": p.id if p else None,
                "risk_level": p.risk_level if p else None,
                "risk_probability": p.risk_probability if p else None,
                "top_reason": top["reason"] if top else None,
                "avg_score": f.get("avg_score"),
                "submit_rate": f.get("submit_rate"),
                "active_days": f.get("active_days"),
                "days_since_last_active": f.get("days_since_last_active"),
                "review": {"decision": review.decision, "note": review.note} if review else None,
            }
        )
    out.sort(key=lambda r: -(r["risk_probability"] or 0))
    return out


@router.get("/courses/{course_id}/analytics")
def course_analytics(
    course_id: int, faculty: FacultyProfile = Depends(get_current_faculty), db: Session = Depends(get_db)
) -> dict:
    ensure_faculty_teaches(db, faculty, course_id)
    n = max(1, analytics.cohort_size(db, course_id))
    stats = analytics.assessment_stats(db, course_id)
    assessments = [
        {"id": a.id, "title": a.title, "type": a.assessment_type, "due_day": a.due_day, **stats.get(a.id, {})}
        for a in analytics.course_assessments(db, course_id)
    ]
    weekly = analytics.weekly_clicks(db, course_id)
    latest = latest_predictions_for_course(db, course_id)
    dist = Counter(p.risk_level for p in latest.values())
    drivers = Counter()
    for p in latest.values():
        if p.risk_level == "high":
            for f in p.explanation:
                if f["direction"] == "increases_risk":
                    drivers[f["label"]] += 1
    return {
        "as_of_day": settings.PREDICTION_DAY,
        "students": analytics.cohort_size(db, course_id),
        "risk_distribution": {k: dist.get(k, 0) for k in ("high", "medium", "low")},
        "top_risk_drivers": [{"label": k, "students": v} for k, v in drivers.most_common(5)],
        "assessments": assessments,
        "weekly_activity": [{"week": w, "avg_clicks": round(c / n, 1)} for w, c in sorted(weekly.items())],
    }


@router.get("/courses/{course_id}/students/{student_id}")
def student_detail(
    course_id: int,
    student_id: int,
    faculty: FacultyProfile = Depends(get_current_faculty),
    db: Session = Depends(get_db),
) -> dict:
    ensure_faculty_teaches(db, faculty, course_id)
    enrolled = db.scalar(
        select(Enrollment).where(Enrollment.course_id == course_id, Enrollment.student_id == student_id)
    )
    if enrolled is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Student not found in this course")
    student = db.get(StudentProfile, student_id)
    latest = latest_predictions_for_course(db, course_id).get(student_id)
    reviews = (
        db.scalars(select(RiskReview).where(RiskReview.prediction_id == latest.id).order_by(RiskReview.id)).all()
        if latest
        else []
    )
    return {
        "student": {"id": student.id, "full_name": student.user.full_name, "student_code": student.student_code},
        "prediction": prediction_out(latest),
        "analytics": analytics.student_course_analytics(db, student_id, course_id),
        "mastery": [m.model_dump() for m in mastery_out(topic_mastery(db, student_id, course_id))],
        "reviews": [{"decision": r.decision, "note": r.note, "created_at": r.created_at.isoformat()} for r in reviews],
    }


@router.post("/predictions/{prediction_id}/reviews", status_code=status.HTTP_201_CREATED)
def review_prediction(
    prediction_id: int,
    body: ReviewIn,
    request: Request,
    faculty: FacultyProfile = Depends(get_current_faculty),
    db: Session = Depends(get_db),
) -> dict:
    pred = db.get(Prediction, prediction_id)
    if pred is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Prediction not found")
    ensure_faculty_teaches(db, faculty, pred.course_id)
    review = RiskReview(prediction_id=pred.id, reviewer_id=faculty.user_id, decision=body.decision, note=body.note)
    db.add(review)
    audit.record(
        db,
        "risk_review",
        actor_id=faculty.user_id,
        resource_type="prediction",
        resource_id=pred.id,
        detail={"decision": body.decision},
        ip_address=client_ip(request),
    )
    db.commit()
    return {"id": review.id, "decision": review.decision, "note": review.note}
