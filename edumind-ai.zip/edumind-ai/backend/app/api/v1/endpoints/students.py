"""Student endpoints. Every route is scoped to the logged-in student ("me")."""

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.deps import get_current_student
from app.db.session import get_db
from app.models import Course, Enrollment, Recommendation, StudentProfile
from app.schemas.student import (
    CourseSummary,
    DashboardOut,
    MasteryOut,
    PredictionOut,
    RecommendationOut,
    RecommendationUpdate,
    StudentInfo,
)
from app.services import analytics, recommendations
from app.services.mastery import topic_mastery
from app.services.predictions import latest_prediction
from app.services.views import enrolled_courses, mastery_out, prediction_out, recommendations_out

router = APIRouter(prefix="/students/me", tags=["Student"])


def _my_course(db: Session, student: StudentProfile, course_id: int) -> Course:
    enrolled = db.scalar(
        select(Enrollment).where(Enrollment.student_id == student.id, Enrollment.course_id == course_id)
    )
    if enrolled is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Course not found")
    return db.get(Course, course_id)


@router.get("/dashboard", response_model=DashboardOut)
def dashboard(student: StudentProfile = Depends(get_current_student), db: Session = Depends(get_db)):
    courses = []
    for c in enrolled_courses(db, student.id):
        a = analytics.student_course_analytics(db, student.id, c.id)
        courses.append(
            CourseSummary(
                course_id=c.id,
                code=c.code,
                title=c.title,
                as_of_day=settings.PREDICTION_DAY,
                length_days=c.length_days,
                data_source=c.data_source,
                risk=prediction_out(latest_prediction(db, student.id, c.id)),
                kpis=a["kpis"],
            )
        )
    return DashboardOut(
        student=StudentInfo(
            id=student.id,
            full_name=student.user.full_name,
            student_code=student.student_code,
            department=student.department,
        ),
        courses=courses,
    )


@router.get("/courses/{course_id}/analytics")
def course_analytics(
    course_id: int, student: StudentProfile = Depends(get_current_student), db: Session = Depends(get_db)
) -> dict:
    _my_course(db, student, course_id)
    return analytics.student_course_analytics(db, student.id, course_id)


@router.get("/courses/{course_id}/prediction", response_model=PredictionOut | None)
def course_prediction(
    course_id: int, student: StudentProfile = Depends(get_current_student), db: Session = Depends(get_db)
):
    _my_course(db, student, course_id)
    return prediction_out(latest_prediction(db, student.id, course_id))


@router.get("/courses/{course_id}/mastery", response_model=list[MasteryOut])
def course_mastery(
    course_id: int, student: StudentProfile = Depends(get_current_student), db: Session = Depends(get_db)
):
    _my_course(db, student, course_id)
    return mastery_out(topic_mastery(db, student.id, course_id))


@router.get("/courses/{course_id}/recommendations", response_model=list[RecommendationOut])
def course_recommendations(
    course_id: int, student: StudentProfile = Depends(get_current_student), db: Session = Depends(get_db)
):
    _my_course(db, student, course_id)
    recos = recommendations.current(db, student.id, course_id)
    if not recos:
        recommendations.generate(db, student.id, course_id)
        db.commit()
        recos = recommendations.current(db, student.id, course_id)
    return recommendations_out(db, recos)


@router.post("/courses/{course_id}/recommendations/refresh", response_model=list[RecommendationOut])
def refresh_recommendations(
    course_id: int, student: StudentProfile = Depends(get_current_student), db: Session = Depends(get_db)
):
    _my_course(db, student, course_id)
    recommendations.generate(db, student.id, course_id)
    db.commit()
    return recommendations_out(db, recommendations.current(db, student.id, course_id))


@router.patch("/recommendations/{reco_id}", response_model=RecommendationOut)
def update_recommendation(
    reco_id: int,
    body: RecommendationUpdate,
    student: StudentProfile = Depends(get_current_student),
    db: Session = Depends(get_db),
):
    reco = db.get(Recommendation, reco_id)
    if reco is None or reco.student_id != student.id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Recommendation not found")
    if body.status:
        reco.status = body.status
    if body.rating is not None:
        reco.rating = body.rating
    db.commit()
    db.refresh(reco)
    return recommendations_out(db, [reco])[0]
