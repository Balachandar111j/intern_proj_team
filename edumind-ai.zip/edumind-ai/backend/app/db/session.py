"""Database engine, session factory and the declarative base."""

import tempfile
from collections.abc import Iterator
from pathlib import Path

from sqlalchemy import MetaData, create_engine
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from app.core.config import settings

# Predictable constraint names keep Alembic migrations stable and avoid collisions
# (MySQL requires CHECK constraint names to be unique per database).
NAMING_CONVENTION = {
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}


class Base(DeclarativeBase):
    metadata = MetaData(naming_convention=NAMING_CONVENTION)


def _connect_args() -> dict:
    """TLS settings for managed MySQL providers (Aiven, PlanetScale, TiDB Cloud...)."""
    ca_path = settings.DB_SSL_CA
    if not ca_path and settings.DB_SSL_CA_PEM:
        pem = settings.DB_SSL_CA_PEM.replace("\\n", "\n")
        path = Path(tempfile.gettempdir()) / "edumind-db-ca.pem"
        path.write_text(pem)
        ca_path = str(path)
    if ca_path:
        return {"ssl": {"ca": ca_path}}
    return {}


def build_engine(url: str | None = None):
    return create_engine(
        url or settings.DATABASE_URL,
        pool_pre_ping=True,
        pool_recycle=280,
        pool_size=5,
        max_overflow=5,
        connect_args=_connect_args(),
    )


engine = build_engine()
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)


def get_db() -> Iterator[Session]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
