"""FastAPI application: API under /api/v1, health checks, and the built React app."""

import logging
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import text

from app.api.v1.router import api_router
from app.core.config import settings
from app.db.session import SessionLocal

logging.basicConfig(level=settings.LOG_LEVEL, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("edumind")

CSRF_HEADER = "X-Requested-With"
UNSAFE_METHODS = {"POST", "PUT", "PATCH", "DELETE"}
CSRF_EXEMPT = {"/api/v1/auth/token"}  # form login for API clients; returns a token, sets no cookie


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings.validate_for_production()
    # Rebuild the vector index from MySQL if needed (e.g. after a restart on an ephemeral disk).
    try:
        from app.rag.store import sync_index

        with SessionLocal() as db:
            sync_index(db)
    except Exception:  # the API still serves dashboards if the tutor index can't be built
        log.exception("Vector index sync failed; the AI tutor may be unavailable")
    yield


app = FastAPI(
    title=settings.APP_NAME,
    version="1.0.0",
    description="Adaptive learning intelligence platform: analytics, explainable risk prediction, "
    "topic mastery, recommendations and a grounded AI tutor.",
    lifespan=lifespan,
)


@app.middleware("http")
async def security_middleware(request: Request, call_next):
    # CSRF defence for cookie sessions: browsers can't add custom headers to cross-site
    # requests without a CORS preflight, which this API never allows.
    if (
        request.method in UNSAFE_METHODS
        and request.url.path.startswith("/api/")
        and request.url.path not in CSRF_EXEMPT
        and not request.headers.get("Authorization", "").lower().startswith("bearer ")
        and request.headers.get(CSRF_HEADER) != "EduMind"
    ):
        return JSONResponse({"detail": "Missing CSRF header"}, status_code=403)
    response = await call_next(request)
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    if settings.COOKIE_SECURE:
        response.headers.setdefault("Strict-Transport-Security", "max-age=31536000")
    return response


@app.exception_handler(Exception)
async def unhandled(request: Request, exc: Exception):
    log.exception("Unhandled error on %s %s", request.method, request.url.path)
    return JSONResponse({"detail": "Internal server error"}, status_code=500)


@app.get("/health", tags=["Operations"])
def health() -> dict:
    """The process is up."""
    return {"status": "ok", "service": "edumind-api"}


@app.get("/ready", tags=["Operations"])
def ready() -> JSONResponse:
    """Dependencies are reachable: database and model artifact."""
    checks = {}
    try:
        with SessionLocal() as db:
            db.execute(text("SELECT 1"))
        checks["database"] = "ok"
    except Exception:
        checks["database"] = "unavailable"
    model_path = settings.ARTIFACTS_DIR / "risk_model" / "model.joblib"
    checks["model"] = "ok" if model_path.exists() else "missing"
    checks["llm_provider"] = settings.effective_llm_provider
    ok = checks["database"] == "ok" and checks["model"] == "ok"
    return JSONResponse({"status": "ready" if ok else "not_ready", "checks": checks}, status_code=200 if ok else 503)


app.include_router(api_router, prefix="/api/v1")


# --- Serve the built React app (single origin: no CORS, cookie auth just works) -----------
def _mount_frontend(dist: Path) -> None:
    if not (dist / "index.html").exists():
        return
    app.mount("/assets", StaticFiles(directory=dist / "assets"), name="assets")

    @app.get("/{path:path}", include_in_schema=False)
    def spa(path: str):
        if path.startswith(("api/", "docs", "openapi.json", "redoc")):
            return JSONResponse({"detail": "Not Found"}, status_code=404)
        candidate = (dist / path).resolve()
        if path and candidate.is_file() and dist.resolve() in candidate.parents:
            return FileResponse(candidate)
        return FileResponse(dist / "index.html")


_mount_frontend(settings.FRONTEND_DIST_DIR or (Path(__file__).resolve().parents[2] / "frontend" / "dist"))
