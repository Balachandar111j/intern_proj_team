"""Data pipeline and model tests: leakage, population, feature parity, training outputs."""

import numpy as np
import pandas as pd
import pytest
from sqlalchemy import select

from app.ml import oulad
from app.ml.features import EXCLUDED_FROM_MODEL, FEATURE_COLUMNS, active_enrollments, compute_features


def _tiny():
    enroll = pd.DataFrame(
        {
            "student_key": [1, 2, 3],
            "course_key": ["C-1"] * 3,
            "registered_day": [-10, -5, -20],
            "unregistered_day": [np.nan, np.nan, 40],
            "prev_attempts": [0, 1, 0],
            "studied_credits": [60, 60, 120],
        }
    )
    assess = pd.DataFrame(
        {
            "course_key": ["C-1"] * 3,
            "assessment_id": ["a1", "a2", "ex"],
            "assessment_type": ["TMA", "TMA", "Exam"],
            "due_day": [20, 60, np.nan],
            "weight": [50, 50, 100],
        }
    )
    results = pd.DataFrame(
        {
            "student_key": [1, 1, 2],
            "assessment_id": ["a1", "a2", "a1"],
            "submitted_day": [18, 75, 25],
            "score": [70.0, 40.0, 55.0],
            "is_banked": [False] * 3,
        }
    )
    clicks = pd.DataFrame(
        {"student_key": [1, 1, 2, 2], "course_key": ["C-1"] * 4, "day": [-3, 10, 30, 80], "clicks": [5, 10, 7, 9]}
    )
    return enroll, assess, results, clicks


def test_population_excludes_students_who_already_withdrew():
    enroll, *_ = _tiny()
    active = active_enrollments(enroll, 50)
    assert set(active.student_key) == {1, 2}


def test_features_ignore_everything_after_the_prediction_day():
    enroll, assess, results, clicks = _tiny()
    before = compute_features(enroll, assess, results, clicks, as_of_day=50)
    future_results = pd.concat(
        [
            results,
            pd.DataFrame(
                {
                    "student_key": [2],
                    "assessment_id": ["a2"],
                    "submitted_day": [55],
                    "score": [99.0],
                    "is_banked": [False],
                }
            ),
        ]
    )
    future_clicks = pd.concat(
        [clicks, pd.DataFrame({"student_key": [1], "course_key": ["C-1"], "day": [51], "clicks": [500]})]
    )
    after = compute_features(enroll, assess, future_results, future_clicks, as_of_day=50)
    pd.testing.assert_frame_equal(before, after)


def test_feature_values_are_correct():
    enroll, assess, results, clicks = _tiny()
    f = compute_features(enroll, assess, results, clicks, as_of_day=50).set_index("student_key")
    assert f.loc[1, "n_due"] == 1  # only a1 is due by day 50; the exam is never counted
    assert f.loc[1, "submit_rate"] == 1.0 and f.loc[1, "avg_score"] == 70.0  # a2 (day 75) is in the future
    assert f.loc[2, "late_rate"] == 1.0  # submitted day 25 for a due-20 assessment
    assert f.loc[1, "pre_start_clicks"] == 5 and f.loc[1, "total_clicks"] == 15
    assert f.loc[3, "days_since_last_active"] == 80  # never active -> as_of_day + 30
    assert list(f.columns[1:]) == FEATURE_COLUMNS


def test_demographics_are_never_model_features():
    assert not set(FEATURE_COLUMNS) & set(EXCLUDED_FROM_MODEL)


def test_loader_rejects_bad_files(tmp_path, oulad_dir):
    for f in oulad_dir.iterdir():
        (tmp_path / f.name).write_bytes(f.read_bytes())
    (tmp_path / "studentAssessment.csv").write_text("id_assessment,id_student\n1,2\n")
    with pytest.raises(oulad.DatasetValidationError):
        oulad.load(tmp_path)


def test_training_outputs(trained):
    assert trained["data_source"] == "synthetic"
    assert trained["algorithm"] in {"logistic_regression", "xgboost"}
    assert trained["split"]["test"] not in trained["split"]["train"]
    assert 0 < trained["thresholds"]["medium"] < trained["thresholds"]["high"] < 1
    # The model must beat the no-skill baseline on the held-out presentation.
    assert trained["test"]["roc_auc"] > trained["comparison"]["baseline_prior"]["test"]["roc_auc"] + 0.1


@pytest.mark.parametrize("algorithm", ["logistic_regression", "xgboost"])
def test_explanations_for_both_deployable_models(oulad_dir, algorithm):
    """Explanations must work whichever model wins selection."""
    from app.ml.features import build_labelled_dataset
    from app.ml.model import RiskModel
    from app.ml.train import candidate_models, fit_calibrator

    data = oulad.load(oulad_dir)
    df = build_labelled_dataset(data, 90)
    X, y = df[FEATURE_COLUMNS], df.at_risk.values
    est = candidate_models()[algorithm].fit(X, y)
    model = RiskModel(
        algorithm,
        est,
        fit_calibrator(est.predict_proba(X)[:, 1], y),
        FEATURE_COLUMNS,
        {"high": 0.5, "medium": 0.2},
        X.median().to_dict(),
    )
    p = model.predict_proba(X.head(20))
    assert ((p >= 0) & (p <= 1)).all()
    contrib = model.contributions(X.head(20))
    assert contrib.shape == (20, len(FEATURE_COLUMNS))
    factors = model.explain_row(X.iloc[0], contrib.iloc[0])
    assert factors and all(f["reason"] for f in factors)


def test_db_features_match_dataset_features(seeded, oulad_dir):
    """Training-serving parity: MySQL-built features equal CSV-built features."""
    from app.core.config import settings
    from app.db.session import SessionLocal
    from app.models import StudentProfile
    from app.services.predictions import frames_from_db

    data = oulad.load(oulad_dir)
    sample = pd.read_csv(settings.SEED_DATA_DIR / "enrollments.csv")[["student_key", "course_key"]]
    csv_en = data.enrollments.merge(sample, on=["student_key", "course_key"])
    csv_f = compute_features(active_enrollments(csv_en, 90), data.assessments, data.results, data.clicks, 90)
    with SessionLocal() as db:
        fr = frames_from_db(db)
        db_f = compute_features(
            active_enrollments(fr["enrollments"], 90), fr["assessments"], fr["results"], fr["clicks"], 90
        )
        ext = dict(db.execute(select(StudentProfile.id, StudentProfile.external_ref)).all())
    db_f["student_key"] = db_f.student_key.map(lambda i: int(ext[i]))
    merged = csv_f.merge(db_f, on=["student_key", "course_key"], suffixes=("_csv", "_db"))
    assert len(merged) == len(csv_f) == len(db_f) > 0
    for col in FEATURE_COLUMNS:
        assert np.allclose(merged[f"{col}_csv"], merged[f"{col}_db"], equal_nan=True), col
