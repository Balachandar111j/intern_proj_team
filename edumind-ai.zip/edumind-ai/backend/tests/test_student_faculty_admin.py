from sqlalchemy import select

from app.db.session import SessionLocal
from app.models import AuditLog, Course, Enrollment, FacultyProfile, Recommendation, StudentProfile, User


def _my_course_id(client) -> int:
    return client.get("/api/v1/students/me/dashboard").json()["courses"][0]["course_id"]


def _other_course_id(client) -> int:
    mine = {c["course_id"] for c in client.get("/api/v1/students/me/dashboard").json()["courses"]}
    with SessionLocal() as db:
        return next(cid for cid in db.scalars(select(Course.id)) if cid not in mine)


def test_dashboard_has_explained_prediction(student):
    data = student.get("/api/v1/students/me/dashboard").json()
    course = data["courses"][0]
    risk = course["risk"]
    assert risk["risk_level"] == "high"  # the demo student is chosen from the high-risk group
    assert 0 <= risk["risk_probability"] <= 1
    assert risk["factors"] and all(f["reason"] for f in risk["factors"])
    assert course["data_source"] == "synthetic"


def test_mastery_and_analytics(student):
    cid = _my_course_id(student)
    mastery = student.get(f"/api/v1/students/me/courses/{cid}/mastery").json()
    assert len(mastery) == 6
    assert {m["status"] for m in mastery} <= {"mastered", "developing", "weak", "missed", "upcoming"}
    analytics = student.get(f"/api/v1/students/me/courses/{cid}/analytics").json()
    assert analytics["as_of_day"] == 90
    # The app never shows records from after the current day.
    assert all((a["submitted_day"] or 0) <= 90 for a in analytics["assessments"])
    assert analytics["weekly_activity"][-1]["week"] == 90 // 7


def test_recommendations_target_weak_topics(student):
    cid = _my_course_id(student)
    recos = student.get(f"/api/v1/students/me/courses/{cid}/recommendations").json()
    assert 1 <= len(recos) <= 6
    mastery = {m["title"]: m["status"] for m in student.get(f"/api/v1/students/me/courses/{cid}/mastery").json()}
    assert all(mastery[r["topic"]] != "mastered" for r in recos)
    assert sum(r["resource"]["resource_type"] == "tutor_quiz" for r in recos) <= 2
    first = recos[0]
    done = student.patch(
        f"/api/v1/students/me/recommendations/{first['id']}", json={"status": "completed", "rating": 5}
    )
    assert done.status_code == 200 and done.json()["status"] == "completed"
    refreshed = student.post(f"/api/v1/students/me/courses/{cid}/recommendations/refresh").json()
    assert first["resource"]["id"] not in {r["resource"]["id"] for r in refreshed}  # completed items drop out
    bad = student.patch(f"/api/v1/students/me/recommendations/{first['id']}", json={"rating": 9})
    assert bad.status_code == 422


def test_student_cannot_see_other_students_or_courses(student, student2):
    other = _other_course_id(student)
    assert student.get(f"/api/v1/students/me/courses/{other}/analytics").status_code == 404
    with SessionLocal() as db:
        sid = db.scalar(select(StudentProfile.id).join(User).where(User.email == "student2@edumind.demo"))
        reco = db.scalar(select(Recommendation).where(Recommendation.student_id == sid))
    assert (
        student.patch(f"/api/v1/students/me/recommendations/{reco.id}", json={"status": "dismissed"}).status_code == 404
    )
    assert student.get("/api/v1/faculty/courses").status_code == 403
    assert student.get("/api/v1/admin/overview").status_code == 403


def test_faculty_views_and_review(faculty):
    courses = faculty.get("/api/v1/faculty/courses").json()
    assert len(courses) == 2
    cid = courses[0]["course_id"]
    high = faculty.get(f"/api/v1/faculty/courses/{cid}/students", params={"risk": "high"}).json()
    assert high and all(s["risk_level"] == "high" for s in high)
    assert high == sorted(high, key=lambda s: -s["risk_probability"])
    detail = faculty.get(f"/api/v1/faculty/courses/{cid}/students/{high[0]['student_id']}").json()
    assert detail["prediction"]["risk_level"] == "high" and detail["mastery"]
    resp = faculty.post(
        f"/api/v1/faculty/predictions/{high[0]['prediction_id']}/reviews",
        json={"decision": "follow_up", "note": "Check-in booked"},
    )
    assert resp.status_code == 201
    with SessionLocal() as db:
        assert db.scalar(select(AuditLog).where(AuditLog.action == "risk_review")) is not None
    analytics = faculty.get(f"/api/v1/faculty/courses/{cid}/analytics").json()
    assert sum(analytics["risk_distribution"].values()) == analytics["students"]


def test_faculty_only_sees_courses_they_teach(app, faculty):
    from conftest import PASSWORD, login

    from app.core.security import hash_password

    with SessionLocal() as db:
        if not db.scalar(select(User).where(User.email == "newfaculty@edumind.demo")):
            u = User(
                email="newfaculty@edumind.demo",
                full_name="New Faculty",
                password_hash=hash_password(PASSWORD),
                role="faculty",
            )
            db.add(u)
            db.flush()
            db.add(FacultyProfile(user_id=u.id, employee_code="FAC999"))
            db.commit()
        cid = db.scalar(select(Enrollment.course_id))
    other = login(app, "newfaculty@edumind.demo")
    assert other.get("/api/v1/faculty/courses").json() == []
    assert other.get(f"/api/v1/faculty/courses/{cid}/students").status_code == 404


def test_admin_overview_and_rescore(admin):
    overview = admin.get("/api/v1/admin/overview").json()
    assert overview["model"]["data_source"] == "synthetic"
    assert overview["backtest"]["n"] > 0
    assert admin.post("/api/v1/admin/rescore").json()["predictions"] > 0
