"""Test setup: a throwaway MySQL database seeded from freshly generated synthetic data.

The whole pipeline runs once per test session: synthetic OULAD-format data ->
validation -> training -> seed export -> Alembic migrations -> seeding -> scoring.
Set TEST_DATABASE_URL to point at your test database (it is wiped).
"""

import os
import tempfile
from pathlib import Path

TMP = Path(tempfile.mkdtemp(prefix="edumind-test-"))
os.environ.update(
    {
        "APP_ENV": "test",
        "DATABASE_URL": os.environ.get(
            "TEST_DATABASE_URL", "mysql+pymysql://edumind:edumind_local_pw@127.0.0.1:3306/edumind_test"
        ),
        "ARTIFACTS_DIR": str(TMP / "artifacts"),
        "SEED_DATA_DIR": str(TMP / "seed"),
        "UPLOAD_DIR": str(TMP / "uploads"),
        "CHROMA_DIR": str(TMP / "chroma"),
        "LLM_PROVIDER": "local",
        "OPENAI_API_KEY": "",
        "DEMO_PASSWORD": "Test-Password-123",
        "PREDICTION_DAY": "90",
        "FRONTEND_DIST_DIR": str(TMP / "no-frontend"),
    }
)

import pytest  # noqa: E402
from alembic import command  # noqa: E402
from alembic.config import Config  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.core.config import BACKEND_DIR, settings  # noqa: E402

PASSWORD = "Test-Password-123"
CSRF = {"X-Requested-With": "EduMind"}


def _alembic() -> Config:
    cfg = Config(str(BACKEND_DIR / "alembic.ini"))
    cfg.set_main_option("script_location", str(BACKEND_DIR / "migrations"))
    cfg.attributes["database_url"] = settings.DATABASE_URL
    return cfg


@pytest.fixture(scope="session")
def oulad_dir() -> Path:
    from app.ml.synthetic import generate

    out = TMP / "oulad"
    generate(out, students_per_presentation=90, seed=11)
    return out


@pytest.fixture(scope="session")
def trained(oulad_dir) -> dict:
    from app.ml.train import train

    return train(oulad_dir, 90, settings.ARTIFACTS_DIR / "risk_model")


@pytest.fixture(scope="session")
def seeded(oulad_dir, trained) -> dict:
    from app.db.session import SessionLocal
    from app.ml.export_seed import export
    from app.seed.seed import seed

    export(oulad_dir, ["DDD-2014J", "FFF-2014J"], 40, 90, settings.SEED_DATA_DIR)
    cfg = _alembic()
    command.downgrade(cfg, "base")
    command.upgrade(cfg, "head")
    with SessionLocal() as db:
        return seed(db, settings.SEED_DATA_DIR)


@pytest.fixture(scope="session")
def app(seeded):
    from app.main import app as fastapi_app

    return fastapi_app


@pytest.fixture(autouse=True)
def _reset_rate_limits():
    from app.api.v1.endpoints import auth, tutor

    auth.login_limiter.reset()
    tutor.tutor_limiter.reset()


def login(app, email: str, password: str = PASSWORD) -> TestClient:
    client = TestClient(app)
    resp = client.post("/api/v1/auth/login", json={"email": email, "password": password}, headers=CSRF)
    assert resp.status_code == 200, resp.text
    client.headers.update(CSRF)
    return client


@pytest.fixture
def student(app) -> TestClient:
    return login(app, "student@edumind.demo")


@pytest.fixture
def student2(app) -> TestClient:
    return login(app, "student2@edumind.demo")


@pytest.fixture
def faculty(app) -> TestClient:
    return login(app, "faculty@edumind.demo")


@pytest.fixture
def admin(app) -> TestClient:
    return login(app, "admin@edumind.demo")


@pytest.fixture
def anon(app) -> TestClient:
    return TestClient(app)


def make_pdf(path: Path, pages: list[str]) -> Path:
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas

    c = canvas.Canvas(str(path), pagesize=A4)
    for text in pages:
        y = 800
        for line in text.split("\n"):
            c.drawString(60, y, line)
            y -= 16
        c.showPage()
    c.save()
    return path
