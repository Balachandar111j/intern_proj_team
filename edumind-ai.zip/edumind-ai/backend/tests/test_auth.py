from conftest import CSRF, PASSWORD


def test_health_and_ready(anon):
    assert anon.get("/health").json()["status"] == "ok"
    ready = anon.get("/ready")
    assert ready.status_code == 200 and ready.json()["checks"]["database"] == "ok"


def test_login_sets_httponly_cookie(anon):
    resp = anon.post("/api/v1/auth/login", json={"email": "student@edumind.demo", "password": PASSWORD}, headers=CSRF)
    assert resp.status_code == 200
    assert resp.json()["role"] == "student"
    cookie = resp.headers["set-cookie"].lower()
    assert "httponly" in cookie and "samesite=lax" in cookie
    assert "password" not in resp.text


def test_wrong_password_and_unknown_email_look_the_same(anon):
    a = anon.post("/api/v1/auth/login", json={"email": "student@edumind.demo", "password": "nope-nope"}, headers=CSRF)
    b = anon.post("/api/v1/auth/login", json={"email": "ghost@edumind.demo", "password": "nope-nope"}, headers=CSRF)
    assert a.status_code == b.status_code == 401
    assert a.json() == b.json()


def test_protected_routes_need_auth(anon):
    assert anon.get("/api/v1/auth/me").status_code == 401
    assert anon.get("/api/v1/students/me/dashboard").status_code == 401


def test_invalid_token_rejected(anon):
    resp = anon.get("/api/v1/auth/me", headers={"Authorization": "Bearer not.a.token"})
    assert resp.status_code == 401


def test_csrf_header_required_for_cookie_writes(student):
    student.headers.pop("X-Requested-With")
    resp = student.post("/api/v1/tutor/sessions", json={"course_id": 1})
    assert resp.status_code == 403


def test_bearer_token_flow(anon):
    tok = anon.post("/api/v1/auth/token", data={"username": "faculty@edumind.demo", "password": PASSWORD})
    assert tok.status_code == 200
    me = anon.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {tok.json()['access_token']}"})
    assert me.json()["role"] == "faculty"


def test_register_validation_and_duplicates(anon):
    weak = anon.post(
        "/api/v1/auth/register",
        json={"full_name": "New Student", "email": "new@x.dev", "password": "abcdefghij"},
        headers=CSRF,
    )
    assert weak.status_code == 422
    ok = anon.post(
        "/api/v1/auth/register",
        json={"full_name": "New  Student", "email": "new@x.dev", "password": "abc123-def456"},
        headers=CSRF,
    )
    assert ok.status_code == 201 and ok.json()["role"] == "student" and ok.json()["full_name"] == "New Student"
    dup = anon.post(
        "/api/v1/auth/register",
        json={"full_name": "Again", "email": "NEW@x.dev", "password": "abc123-def456"},
        headers=CSRF,
    )
    assert dup.status_code == 409
    # A new student has no courses yet: the dashboard is empty, not an error.
    assert anon.get("/api/v1/students/me/dashboard").json()["courses"] == []


def test_login_rate_limit(anon):
    codes = [
        anon.post(
            "/api/v1/auth/login", json={"email": "admin@edumind.demo", "password": "bad-guess"}, headers=CSRF
        ).status_code
        for _ in range(12)
    ]
    assert codes[-1] == 429
