import { useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import type { RiskLevel } from '../api/client'
import { ClassActivityChart } from '../components/Charts'
import { Empty, ErrorState, Loading, RISK, RiskPill, SectionTitle, SyntheticNotice } from '../components/ui'
import { num, pct, useApi } from '../lib/useApi'

interface FacultyCourse {
  course_id: number
  code: string
  title: string
  data_source: string
  students: number
  as_of_day: number
  risk_distribution: Record<RiskLevel, number>
}
interface StudentRow {
  student_id: number
  student_code: string
  full_name: string
  prediction_id: number | null
  risk_level: RiskLevel | null
  risk_probability: number | null
  top_reason: string | null
  avg_score: number | null
  submit_rate: number | null
  active_days: number | null
  days_since_last_active: number | null
  review: { decision: string; note: string | null } | null
}
interface ClassAnalytics {
  students: number
  risk_distribution: Record<RiskLevel, number>
  top_risk_drivers: { label: string; students: number }[]
  assessments: { id: number; title: string; type: string; due_day: number | null; class_avg?: number; submission_rate?: number }[]
  weekly_activity: { week: number; avg_clicks: number }[]
}

const REVIEW_LABEL: Record<string, string> = { confirmed: 'Confirmed', dismissed: 'Dismissed', follow_up: 'Follow-up booked' }

export default function FacultyClass() {
  const courses = useApi<FacultyCourse[]>('/faculty/courses')
  const [params, setParams] = useSearchParams()
  const [filter, setFilter] = useState<RiskLevel | 'all'>('high')
  const course = courses.data?.find((c) => c.course_id === Number(params.get('course'))) ?? courses.data?.[0]
  const cid = course?.course_id
  const students = useApi<StudentRow[]>(cid ? `/faculty/courses/${cid}/students` : null)
  const analytics = useApi<ClassAnalytics>(cid ? `/faculty/courses/${cid}/analytics` : null)

  if (courses.loading) return <Loading />
  if (courses.error) return <ErrorState message={courses.error} onRetry={courses.reload} />
  if (!course) return <Empty title="No classes assigned">An administrator assigns the courses you teach.</Empty>

  const rows = (students.data ?? []).filter((s) => filter === 'all' || s.risk_level === filter)
  const dist = course.risk_distribution
  const maxDriver = Math.max(1, ...(analytics.data?.top_risk_drivers.map((d) => d.students) ?? [1]))

  return (
    <>
      {(courses.data?.length ?? 0) > 1 && (
        <div role="tablist" aria-label="Courses" className="mb-6 flex flex-wrap gap-2">
          {courses.data!.map((c) => (
            <button
              key={c.course_id}
              role="tab"
              aria-selected={c.course_id === cid}
              onClick={() => setParams({ course: String(c.course_id) })}
              className={`rounded-full border px-3 py-1 text-sm ${c.course_id === cid ? 'border-ink bg-ink text-white' : 'border-line-strong bg-surface text-ink-2'}`}
            >
              {c.title}
            </button>
          ))}
        </div>
      )}
      <SyntheticNotice source={course.data_source} />
      <p className="text-ink-2">
        {course.title}, day {course.as_of_day}, {course.students} students
      </p>
      <h1 className="mt-2 max-w-[24ch] text-[2rem] font-extrabold sm:text-[2.4rem]">
        {dist.high === 0 ? "No students are at high risk right now." : `${dist.high} students need a check-in this week.`}
      </h1>

      <dl className="mt-8 grid max-w-2xl grid-cols-3 gap-4">
        {(['high', 'medium', 'low'] as RiskLevel[]).map((lvl) => {
          const r = RISK[lvl]
          return (
            <button
              key={lvl}
              onClick={() => setFilter(lvl)}
              aria-pressed={filter === lvl}
              className={`rounded-lg border px-4 py-3 text-left ${filter === lvl ? 'border-ink' : 'border-line'} bg-surface`}
            >
              <dt className={`flex items-center gap-1.5 text-sm font-bold ${r.text}`}>
                <r.Icon size={15} aria-hidden /> {r.label}
              </dt>
              <dd className="font-display text-3xl font-extrabold">{dist[lvl]}</dd>
            </button>
          )
        })}
      </dl>

      <section className="mt-12">
        <SectionTitle
          aside={
            <button onClick={() => setFilter('all')} className="underline-offset-2 hover:underline">
              Show all students
            </button>
          }
        >
          {filter === 'all' ? 'All students' : `${RISK[filter].label} students`}
        </SectionTitle>
        {students.loading && <Loading />}
        {students.error && <ErrorState message={students.error} onRetry={students.reload} />}
        {students.data && (
          <div className="overflow-x-auto rounded-lg border border-line bg-surface">
            <table className="w-full min-w-[820px] text-sm">
              <thead>
                <tr className="border-b border-line text-left text-ink-2">
                  <th className="px-4 py-2 font-normal">Student</th>
                  <th className="px-4 py-2 font-normal">Risk</th>
                  <th className="px-4 py-2 font-normal">Main concern</th>
                  <th className="px-4 py-2 font-normal">Avg score</th>
                  <th className="px-4 py-2 font-normal">Submitted</th>
                  <th className="px-4 py-2 font-normal">Last active</th>
                  <th className="px-4 py-2 font-normal">Review</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((s) => (
                  <tr key={s.student_id} className="border-b border-line last:border-0 hover:bg-paper/60">
                    <td className="px-4 py-2.5">
                      <Link to={`/faculty/courses/${cid}/students/${s.student_id}`} className="font-bold text-you underline-offset-2 hover:underline">
                        {s.full_name}
                      </Link>
                      <span className="block text-xs text-muted">{s.student_code}</span>
                    </td>
                    <td className="px-4 py-2.5">
                      {s.risk_level ? (
                        <>
                          <RiskPill level={s.risk_level} />
                          <span className="ml-2 text-ink-2">{pct(s.risk_probability)}</span>
                        </>
                      ) : (
                        '—'
                      )}
                    </td>
                    <td className="max-w-[260px] px-4 py-2.5 text-ink-2">{s.top_reason ?? '—'}</td>
                    <td className="px-4 py-2.5">{s.avg_score === null ? '—' : `${num(s.avg_score)}%`}</td>
                    <td className="px-4 py-2.5">{pct(s.submit_rate)}</td>
                    <td className="px-4 py-2.5">
                      {s.days_since_last_active === null ? '—' : s.days_since_last_active === 0 ? 'Today' : `${num(s.days_since_last_active)} days ago`}
                    </td>
                    <td className="px-4 py-2.5 text-ink-2">{s.review ? REVIEW_LABEL[s.review.decision] : 'Not reviewed'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            {rows.length === 0 && <p className="px-4 py-6 text-ink-2">No students in this group.</p>}
          </div>
        )}
      </section>

      {analytics.data && (
        <section className="mt-14 grid gap-12 lg:grid-cols-2">
          <div>
            <SectionTitle aside="Among high-risk students">Most common reasons</SectionTitle>
            <ul className="space-y-3">
              {analytics.data.top_risk_drivers.map((d) => (
                <li key={d.label}>
                  <div className="flex justify-between text-sm">
                    <span>{d.label}</span>
                    <span className="font-bold">{d.students}</span>
                  </div>
                  <div className="mt-1 h-2 rounded bg-paper">
                    <div className="h-2 rounded bg-you" style={{ width: `${(d.students / maxDriver) * 100}%` }} />
                  </div>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <SectionTitle aside="Interactions per student">Class activity by week</SectionTitle>
            <ClassActivityChart weeks={analytics.data.weekly_activity} />
          </div>
          <div className="lg:col-span-2">
            <SectionTitle>Assessments so far</SectionTitle>
            <table className="w-full max-w-2xl text-sm">
              <thead>
                <tr className="text-left text-ink-2">
                  <th className="py-1 font-normal">Assessment</th>
                  <th className="py-1 font-normal">Due day</th>
                  <th className="py-1 font-normal">Class average</th>
                  <th className="py-1 font-normal">Submitted</th>
                </tr>
              </thead>
              <tbody>
                {analytics.data.assessments
                  .filter((a) => a.class_avg !== undefined)
                  .map((a) => (
                    <tr key={a.id} className="border-t border-line">
                      <td className="py-1.5 font-bold">{a.title}</td>
                      <td className="py-1.5">{a.due_day}</td>
                      <td className="py-1.5">{a.class_avg}%</td>
                      <td className="py-1.5">{pct(a.submission_rate)}</td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </section>
      )}
    </>
  )
}
