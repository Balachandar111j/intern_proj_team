import { useState, type FormEvent } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../auth/AuthContext'
import { Brand } from '../components/Shell'
import { Button } from '../components/ui'

export default function Register() {
  const { register } = useAuth()
  const navigate = useNavigate()
  const [form, setForm] = useState({ name: '', email: '', password: '' })
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  const submit = async (e: FormEvent) => {
    e.preventDefault()
    setBusy(true)
    setError(null)
    try {
      await register(form.name, form.email, form.password)
      navigate('/app')
    } catch (err) {
      setError((err as Error).message)
    } finally {
      setBusy(false)
    }
  }

  const field = (key: keyof typeof form, label: string, type: string, auto: string, hint?: string) => (
    <label className="block">
      <span className="text-sm font-bold">{label}</span>
      <input
        type={type}
        required
        autoComplete={auto}
        minLength={key === 'password' ? 10 : 2}
        value={form[key]}
        onChange={(e) => setForm({ ...form, [key]: e.target.value })}
        className="mt-1 w-full rounded-md border border-line-strong bg-surface px-3 py-2"
      />
      {hint && <span className="mt-1 block text-xs text-muted">{hint}</span>}
    </label>
  )

  return (
    <div className="mx-auto max-w-sm px-6 py-10">
      <Brand />
      <h1 className="mt-10 text-2xl font-bold">Create a student account</h1>
      <p className="mt-2 text-sm text-ink-2">Your dashboard fills in once your college adds your course records.</p>
      <form onSubmit={submit} className="mt-6 space-y-4">
        {field('name', 'Full name', 'text', 'name')}
        {field('email', 'Email', 'email', 'email')}
        {field('password', 'Password', 'password', 'new-password', 'At least 10 characters, mixing letters with numbers or symbols.')}
        {error && (
          <p className="text-sm text-high" role="alert">
            {error}
          </p>
        )}
        <Button type="submit" disabled={busy} className="w-full">
          {busy ? 'Creating account…' : 'Create account'}
        </Button>
      </form>
      <p className="mt-4 text-sm text-ink-2">
        Already registered?{' '}
        <Link to="/login" className="font-bold text-you underline-offset-2 hover:underline">
          Sign in
        </Link>
      </p>
    </div>
  )
}
