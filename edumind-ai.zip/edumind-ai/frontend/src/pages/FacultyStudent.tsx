import { useState, type FormEvent } from 'react'
import { Link, useParams } from 'react-router-dom'
import { api, type CourseAnalytics, type Mastery, type Prediction } from '../api/client'
import { ActivityChart, ScoreChart } from '../components/Charts'
import RiskSummary from '../components/RiskSummary'
import TopicRoute from '../components/TopicRoute'
import { Button, ErrorState, Loading, SectionTitle } from '../components/ui'
import { useApi } from '../lib/useApi'

interface Detail {
  student: { id: number; full_name: string; student_code: string }
  prediction: Prediction | null
  analytics: CourseAnalytics
  mastery: Mastery[]
  reviews: { decision: string; note: string | null; created_at: string }[]
}

const DECISIONS = [
  { value: 'follow_up', label: 'Book a check-in' },
  { value: 'confirmed', label: 'Agree, keep monitoring' },
  { value: 'dismissed', label: 'Dismiss the flag' },
] as const

export default function FacultyStudent() {
  const { courseId, studentId } = useParams()
  const detail = useApi<Detail>(`/faculty/courses/${courseId}/students/${studentId}`)
  const [decision, setDecision] = useState<(typeof DECISIONS)[number]['value']>('follow_up')
  const [note, setNote] = useState('')
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)

  if (detail.loading) return <Loading />
  if (detail.error || !detail.data) return <ErrorState message={detail.error ?? 'Not found'} onRetry={detail.reload} />
  const d = detail.data

  const save = async (e: FormEvent) => {
    e.preventDefault()
    if (!d.prediction) return
    setSaving(true)
    setError(null)
    try {
      await api.post(`/faculty/predictions/${d.prediction.id}/reviews`, { decision, note: note || null })
      setNote('')
      detail.reload()
    } catch (err) {
      setError((err as Error).message)
    } finally {
      setSaving(false)
    }
  }

  return (
    <>
      <Link to={`/faculty?course=${courseId}`} className="text-sm text-you underline-offset-2 hover:underline">
        Back to the class list
      </Link>
      <p className="mt-4 text-ink-2">
        <span className="font-bold text-ink">{d.student.full_name}</span>, {d.student.student_code}
      </p>
      <div className="mt-3">{d.prediction ? <RiskSummary prediction={d.prediction} audience="faculty" /> : <p>No prediction yet.</p>}</div>

      {d.prediction && (
        <section className="mt-10 max-w-xl rounded-xl border border-line bg-surface p-5">
          <h2 className="text-lg font-bold">Your review</h2>
          <p className="mt-1 text-sm text-ink-2">The model only flags. You decide what happens next, and the decision is logged.</p>
          <form onSubmit={save} className="mt-4 space-y-3">
            <fieldset className="flex flex-wrap gap-2">
              <legend className="sr-only">Decision</legend>
              {DECISIONS.map((o) => (
                <label key={o.value} className={`cursor-pointer rounded-full border px-3 py-1 text-sm ${decision === o.value ? 'border-ink bg-ink text-white' : 'border-line-strong'}`}>
                  <input type="radio" name="decision" value={o.value} checked={decision === o.value} onChange={() => setDecision(o.value)} className="sr-only" />
                  {o.label}
                </label>
              ))}
            </fieldset>
            <textarea
              value={note}
              onChange={(e) => setNote(e.target.value)}
              rows={2}
              maxLength={2000}
              placeholder="Note (optional), e.g. agreed a revision plan for Pandas"
              aria-label="Note"
              className="w-full rounded-md border border-line-strong px-3 py-2 text-sm"
            />
            {error && <p className="text-sm text-high">{error}</p>}
            <Button type="submit" disabled={saving}>
              {saving ? 'Saving…' : 'Save review'}
            </Button>
          </form>
          {d.reviews.length > 0 && (
            <ul className="mt-5 space-y-2 border-t border-line pt-4 text-sm">
              {d.reviews.map((r, i) => (
                <li key={i}>
                  <span className="font-bold">{DECISIONS.find((x) => x.value === r.decision)?.label}</span>
                  <span className="text-muted"> on {new Date(r.created_at).toLocaleDateString()}</span>
                  {r.note && <span className="block text-ink-2">{r.note}</span>}
                </li>
              ))}
            </ul>
          )}
        </section>
      )}

      <section className="mt-14">
        <SectionTitle>Path through the course</SectionTitle>
        <TopicRoute topics={d.mastery} />
      </section>
      <section className="mt-14 grid gap-12 lg:grid-cols-2">
        <div>
          <SectionTitle aside="Student vs class average">Assessment scores</SectionTitle>
          <ScoreChart rows={d.analytics.assessments} />
        </div>
        <div>
          <SectionTitle aside="Interactions per week">Learning activity</SectionTitle>
          <ActivityChart weeks={d.analytics.weekly_activity} />
        </div>
      </section>
    </>
  )
}
