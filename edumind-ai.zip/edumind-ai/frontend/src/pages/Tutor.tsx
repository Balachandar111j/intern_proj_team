import { FileUp, Loader2, Plus, Send, Trash2 } from 'lucide-react'
import { useEffect, useRef, useState, type FormEvent } from 'react'
import { useSearchParams } from 'react-router-dom'
import { api, type ChatMessage, type TutorDocument } from '../api/client'
import { useAuth } from '../auth/AuthContext'
import Answer from '../components/Answer'
import { Button, Empty, ErrorState, Loading } from '../components/ui'
import { useApi } from '../lib/useApi'

interface Course {
  course_id: number
  code: string
  title: string
}
interface Session {
  id: number
  title: string
  created_at: string
}

function Documents({ courseId, canShare }: { courseId: number; canShare: boolean }) {
  const docs = useApi<TutorDocument[]>(`/tutor/documents?course_id=${courseId}`)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [visibility, setVisibility] = useState<'private' | 'course'>(canShare ? 'course' : 'private')
  const fileRef = useRef<HTMLInputElement>(null)

  const upload = async (file: File) => {
    setBusy(true)
    setError(null)
    const form = new FormData()
    form.append('course_id', String(courseId))
    form.append('visibility', visibility)
    form.append('file', file)
    try {
      await api.post('/tutor/documents', form)
      docs.reload()
    } catch (e) {
      setError((e as Error).message)
    } finally {
      setBusy(false)
      if (fileRef.current) fileRef.current.value = ''
    }
  }

  return (
    <section aria-labelledby="docs-h" className="mt-8">
      <h2 id="docs-h" className="text-base font-bold">
        Notes the tutor can read
      </h2>
      <ul className="mt-2 space-y-2 text-sm">
        {docs.data?.map((d) => (
          <li key={d.id} className="flex items-start justify-between gap-2">
            <span>
              <span className="font-bold">{d.title}</span>
              <span className="block text-xs text-muted">
                {d.status === 'ready' ? `${d.page_count} pages` : d.status === 'failed' ? d.error : 'Processing'}
                {d.visibility === 'private' ? ', only you' : ', whole course'}
              </span>
            </span>
            {d.is_mine && (
              <button
                onClick={async () => {
                  await api.del(`/tutor/documents/${d.id}`)
                  docs.reload()
                }}
                className="text-muted hover:text-high"
                aria-label={`Delete ${d.title}`}
              >
                <Trash2 size={15} />
              </button>
            )}
          </li>
        ))}
      </ul>
      <div className="mt-3 space-y-2">
        {canShare && (
          <select
            value={visibility}
            onChange={(e) => setVisibility(e.target.value as 'private' | 'course')}
            className="w-full rounded-md border border-line-strong bg-surface px-2 py-1.5 text-sm"
            aria-label="Who can use this document"
          >
            <option value="course">Share with the whole course</option>
            <option value="private">Only me</option>
          </select>
        )}
        <input
          ref={fileRef}
          type="file"
          accept="application/pdf,.pdf"
          className="sr-only"
          id="pdf-upload"
          onChange={(e) => e.target.files?.[0] && upload(e.target.files[0])}
        />
        <label
          htmlFor="pdf-upload"
          className="flex cursor-pointer items-center justify-center gap-2 rounded-md border border-dashed border-line-strong px-3 py-2 text-sm text-ink-2 hover:border-ink-2"
        >
          {busy ? <Loader2 size={15} className="animate-spin" /> : <FileUp size={15} />}
          {busy ? 'Reading your PDF…' : 'Add a PDF (up to 10 MB)'}
        </label>
        {!canShare && <p className="text-xs text-muted">Your uploads stay private to you.</p>}
        {error && <p className="text-xs text-high">{error}</p>}
      </div>
    </section>
  )
}

export default function Tutor() {
  const { user } = useAuth()
  const [params, setParams] = useSearchParams()
  const courses = useApi<Course[]>('/tutor/courses')
  const courseId = Number(params.get('course')) || courses.data?.[0]?.course_id
  const course = courses.data?.find((c) => c.course_id === courseId)
  const sessions = useApi<Session[]>(courseId ? `/tutor/sessions?course_id=${courseId}` : null)
  const [sessionId, setSessionId] = useState<number | null>(null)
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [text, setText] = useState('')
  const [mode, setMode] = useState<'explain' | 'quiz'>('explain')
  const [level, setLevel] = useState<'beginner' | 'intermediate' | 'advanced'>('intermediate')
  const [sending, setSending] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const endRef = useRef<HTMLDivElement>(null)

  // Arriving from "Quiz me on <topic>": prefill a quiz request.
  useEffect(() => {
    const quiz = params.get('quiz')
    if (quiz) {
      setMode('quiz')
      setText(`Quiz me on ${quiz}`)
    }
  }, [params])

  useEffect(() => {
    setSessionId(null)
    setMessages([])
  }, [courseId])

  useEffect(() => {
    if (!sessionId) return
    api.get<ChatMessage[]>(`/tutor/sessions/${sessionId}/messages`).then(setMessages)
  }, [sessionId])

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' })
  }, [messages, sending])

  if (courses.loading) return <Loading />
  if (courses.error) return <ErrorState message={courses.error} onRetry={courses.reload} />
  if (!courseId || !course) return <Empty title="No courses yet">The tutor works inside a course you’re enrolled in or teaching.</Empty>

  const send = async (e: FormEvent) => {
    e.preventDefault()
    const content = text.trim()
    if (content.length < 2) return
    setSending(true)
    setError(null)
    try {
      let sid = sessionId
      if (!sid) {
        const s = await api.post<Session>('/tutor/sessions', { course_id: courseId })
        sid = s.id
        setSessionId(s.id)
        sessions.reload()
      }
      const pending: ChatMessage = { id: -Date.now(), role: 'user', content, citations: [], meta: {}, created_at: '' }
      setMessages((m) => [...m, pending])
      setText('')
      const reply = await api.post<ChatMessage>(`/tutor/sessions/${sid}/messages`, { content, mode, level })
      setMessages((m) => [...m, reply])
    } catch (err) {
      setError((err as Error).message)
    } finally {
      setSending(false)
    }
  }

  return (
    <div className="grid gap-8 lg:grid-cols-[260px_1fr]">
      <aside>
        <h1 className="text-2xl font-extrabold">AI tutor</h1>
        <p className="mt-1 text-sm text-ink-2">Answers come only from the course notes below, with page references.</p>
        {(courses.data?.length ?? 0) > 1 && (
          <select
            value={courseId}
            onChange={(e) => setParams({ course: e.target.value })}
            className="mt-4 w-full rounded-md border border-line-strong bg-surface px-2 py-1.5 text-sm"
            aria-label="Course"
          >
            {courses.data!.map((c) => (
              <option key={c.course_id} value={c.course_id}>
                {c.title}
              </option>
            ))}
          </select>
        )}
        <div className="mt-6">
          <Button variant="quiet" className="w-full" onClick={() => { setSessionId(null); setMessages([]) }}>
            <Plus size={15} /> New chat
          </Button>
          <ul className="mt-3 space-y-1 text-sm">
            {sessions.data?.slice(0, 12).map((s) => (
              <li key={s.id}>
                <button
                  onClick={() => setSessionId(s.id)}
                  className={`w-full truncate rounded px-2 py-1 text-left ${s.id === sessionId ? 'bg-surface font-bold' : 'text-ink-2 hover:bg-surface'}`}
                >
                  {s.title}
                </button>
              </li>
            ))}
          </ul>
        </div>
        <Documents courseId={courseId} canShare={user?.role !== 'student'} />
      </aside>

      <section className="flex min-h-[70vh] flex-col rounded-xl border border-line bg-surface" aria-label={`Chat about ${course.title}`}>
        <div className="border-b border-line px-5 py-3 text-sm text-ink-2">{course.title}</div>
        <div className="flex-1 space-y-6 overflow-y-auto px-5 py-6" aria-live="polite">
          {messages.length === 0 && !sending && (
            <div className="max-w-md text-ink-2">
              <p className="font-bold text-ink">Ask about anything in this course.</p>
              <p className="mt-1 text-sm">
                Try “What’s the difference between precision and recall?” or switch to Quiz me for practice questions.
              </p>
            </div>
          )}
          {messages.map((m) =>
            m.role === 'user' ? (
              <div key={m.id} className="ml-auto max-w-[80%] rounded-2xl rounded-br-sm bg-ink px-4 py-2.5 text-white">
                {m.content}
              </div>
            ) : (
              <div key={m.id} className="max-w-[88%]">
                <Answer id={m.id} content={m.content} citations={m.citations} />
              </div>
            ),
          )}
          {sending && (
            <p className="flex items-center gap-2 text-sm text-muted" role="status">
              <Loader2 size={15} className="animate-spin" /> Reading your course notes…
            </p>
          )}
          <div ref={endRef} />
        </div>
        <form onSubmit={send} className="border-t border-line p-4">
          {error && <p className="mb-2 text-sm text-high">{error}</p>}
          <div className="mb-3 flex flex-wrap items-center gap-3 text-sm">
            <div role="radiogroup" aria-label="Mode" className="inline-flex rounded-md border border-line-strong p-0.5">
              {(['explain', 'quiz'] as const).map((m) => (
                <button
                  key={m}
                  type="button"
                  role="radio"
                  aria-checked={mode === m}
                  onClick={() => setMode(m)}
                  className={`rounded px-3 py-1 ${mode === m ? 'bg-ink text-white' : 'text-ink-2'}`}
                >
                  {m === 'explain' ? 'Explain' : 'Quiz me'}
                </button>
              ))}
            </div>
            <label className="flex items-center gap-2 text-ink-2">
              Level
              <select
                value={level}
                onChange={(e) => setLevel(e.target.value as typeof level)}
                className="rounded-md border border-line-strong bg-surface px-2 py-1"
              >
                <option value="beginner">Beginner</option>
                <option value="intermediate">Intermediate</option>
                <option value="advanced">Advanced</option>
              </select>
            </label>
          </div>
          <div className="flex gap-2">
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault()
                  ;(e.currentTarget.form as HTMLFormElement).requestSubmit()
                }
              }}
              rows={2}
              maxLength={2000}
              placeholder="Ask a question about the course"
              aria-label="Your question"
              className="flex-1 resize-none rounded-md border border-line-strong px-3 py-2"
            />
            <Button type="submit" disabled={sending || text.trim().length < 2} aria-label="Send">
              <Send size={16} />
            </Button>
          </div>
        </form>
      </section>
    </div>
  )
}
