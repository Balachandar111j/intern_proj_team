import { RefreshCw } from 'lucide-react'
import { useState } from 'react'
import { api } from '../api/client'
import { Button, ErrorState, Loading, SectionTitle, SyntheticNotice } from '../components/ui'
import { pct, useApi } from '../lib/useApi'

interface Ranking {
  roc_auc: number | null
  pr_auc: number | null
  brier: number
  n: number
}
interface Overview {
  as_of_day: number
  users: Record<string, number>
  courses: number
  documents: number
  chunks: number
  llm_provider: string
  model: null | {
    version: string
    algorithm: string
    data_source: string
    prediction_day: number
    thresholds: { high: number; medium: number; objective: string }
    test_metrics: Ranking & {
      baseline_roc_auc: number
      at_high: { precision: number; recall: number; flagged_rate: number }
      at_medium_or_high: { precision: number; recall: number; flagged_rate: number }
    }
    comparison: Record<string, { validation: Ranking; test: Ranking }>
  }
  backtest: {
    n: number
    actual_at_risk_rate?: number
    high?: { flagged: number; precision: number | null; recall: number | null }
    medium_or_high?: { flagged: number; precision: number | null; recall: number | null }
  }
  recent_activity: { action: string; actor: string | null; resource: string | null; at: string }[]
}

const f3 = (v: number | null | undefined) => (v === null || v === undefined ? '—' : v.toFixed(3))

export default function Admin() {
  const data = useApi<Overview>('/admin/overview')
  const [busy, setBusy] = useState(false)
  const [message, setMessage] = useState<string | null>(null)

  if (data.loading) return <Loading />
  if (data.error || !data.data) return <ErrorState message={data.error ?? 'Unavailable'} onRetry={data.reload} />
  const o = data.data
  const m = o.model

  const rescore = async () => {
    setBusy(true)
    try {
      const r = await api.post<{ predictions: number }>('/admin/rescore')
      setMessage(`Rescored ${r.predictions} students with the active model.`)
      data.reload()
    } catch (e) {
      setMessage((e as Error).message)
    } finally {
      setBusy(false)
    }
  }

  return (
    <>
      <SyntheticNotice source={m?.data_source} />
      <h1 className="text-[2rem] font-extrabold">Platform and model health</h1>
      <p className="mt-2 text-ink-2">
        {o.users.student ?? 0} students, {o.users.faculty ?? 0} faculty, {o.courses} courses. Tutor provider:{' '}
        {o.llm_provider === 'openai' ? 'OpenAI' : 'offline fallback (add an OpenAI key for generated answers)'}. {o.documents} documents,{' '}
        {o.chunks} indexed passages.
      </p>

      {m && (
        <>
          <section className="mt-10">
            <SectionTitle aside={m.version}>Active risk model</SectionTitle>
            <dl className="grid max-w-3xl grid-cols-2 gap-6 sm:grid-cols-4">
              <div>
                <dt className="text-sm text-ink-2">Test ROC-AUC</dt>
                <dd className="font-display text-3xl font-extrabold">{f3(m.test_metrics.roc_auc)}</dd>
                <dd className="text-xs text-muted">Baseline {f3(m.test_metrics.baseline_roc_auc)}</dd>
              </div>
              <div>
                <dt className="text-sm text-ink-2">PR-AUC</dt>
                <dd className="font-display text-3xl font-extrabold">{f3(m.test_metrics.pr_auc)}</dd>
              </div>
              <div>
                <dt className="text-sm text-ink-2">High-risk precision</dt>
                <dd className="font-display text-3xl font-extrabold">{pct(m.test_metrics.at_high.precision)}</dd>
                <dd className="text-xs text-muted">Recall {pct(m.test_metrics.at_high.recall)}</dd>
              </div>
              <div>
                <dt className="text-sm text-ink-2">Brier score</dt>
                <dd className="font-display text-3xl font-extrabold">{f3(m.test_metrics.brier)}</dd>
                <dd className="text-xs text-muted">Lower is better</dd>
              </div>
            </dl>
            <p className="mt-4 max-w-3xl text-sm text-ink-2">
              {m.algorithm.replace('_', ' ')} predicting on day {m.prediction_day}. High risk from {pct(m.thresholds.high)}, medium from{' '}
              {pct(m.thresholds.medium)}. {m.thresholds.objective}.
            </p>
          </section>

          <section className="mt-10">
            <SectionTitle aside="Validation picks the model; test is touched once">Model comparison</SectionTitle>
            <div className="overflow-x-auto">
              <table className="w-full max-w-3xl min-w-[560px] text-sm">
                <thead>
                  <tr className="text-left text-ink-2">
                    <th className="py-1 font-normal">Model</th>
                    <th className="py-1 font-normal">Validation ROC-AUC</th>
                    <th className="py-1 font-normal">Test ROC-AUC</th>
                    <th className="py-1 font-normal">Test PR-AUC</th>
                    <th className="py-1 font-normal">Test Brier</th>
                  </tr>
                </thead>
                <tbody>
                  {Object.entries(m.comparison).map(([name, r]) => (
                    <tr key={name} className={`border-t border-line ${name === m.algorithm ? 'font-bold' : ''}`}>
                      <td className="py-1.5">
                        {name.replace(/_/g, ' ')}
                        {name === m.algorithm && <span className="ml-2 text-xs font-normal text-low">active</span>}
                      </td>
                      <td className="py-1.5">{f3(r.validation.roc_auc)}</td>
                      <td className="py-1.5">{f3(r.test.roc_auc)}</td>
                      <td className="py-1.5">{f3(r.test.pr_auc)}</td>
                      <td className="py-1.5">{f3(r.test.brier)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        </>
      )}

      {o.backtest.n > 0 && (
        <section className="mt-10 max-w-3xl">
          <SectionTitle aside={`${o.backtest.n} students with known final results`}>How live flags turned out</SectionTitle>
          <p className="text-sm text-ink-2">
            The platform’s students come from a course run the model never trained on, and their final results are known.
            Of them, {pct(o.backtest.actual_at_risk_rate)} actually failed or withdrew.
          </p>
          <ul className="mt-3 space-y-1 text-sm">
            <li>
              High-risk flags: {o.backtest.high?.flagged} students, {pct(o.backtest.high?.precision)} of them did fail or withdraw, catching{' '}
              {pct(o.backtest.high?.recall)} of all who did.
            </li>
            <li>
              Medium or high: {o.backtest.medium_or_high?.flagged} students, precision {pct(o.backtest.medium_or_high?.precision)}, catching{' '}
              {pct(o.backtest.medium_or_high?.recall)}.
            </li>
          </ul>
        </section>
      )}

      <section className="mt-10 max-w-3xl">
        <SectionTitle>Rescore students</SectionTitle>
        <p className="text-sm text-ink-2">Runs the active model over every enrolment and stores new predictions with their explanations.</p>
        <Button className="mt-3" onClick={rescore} disabled={busy}>
          <RefreshCw size={15} className={busy ? 'animate-spin' : ''} /> {busy ? 'Rescoring…' : 'Rescore now'}
        </Button>
        {message && <p className="mt-2 text-sm text-ink-2">{message}</p>}
      </section>

      <section className="mt-10 max-w-3xl">
        <SectionTitle>Recent activity</SectionTitle>
        <ul className="divide-y divide-line text-sm">
          {o.recent_activity.map((a, i) => (
            <li key={i} className="flex justify-between py-1.5">
              <span>
                {a.action.replace(/_/g, ' ')}
                {a.actor ? <span className="text-muted"> by {a.actor}</span> : null}
              </span>
              <span className="text-muted">{new Date(a.at + 'Z').toLocaleString()}</span>
            </li>
          ))}
        </ul>
      </section>
    </>
  )
}
