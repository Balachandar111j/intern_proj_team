import { useState, type FormEvent } from 'react'
import { Link, Navigate, useNavigate } from 'react-router-dom'
import { homeFor, useAuth } from '../auth/AuthContext'
import { Brand } from '../components/Shell'
import { Button } from '../components/ui'

const DEMO_PASSWORD = import.meta.env.VITE_DEMO_PASSWORD as string | undefined
const DEMO_ACCOUNTS = [
  { email: 'student@edumind.demo', label: 'Student who is struggling' },
  { email: 'student2@edumind.demo', label: 'Student who is on track' },
  { email: 'faculty@edumind.demo', label: 'Faculty member' },
  { email: 'admin@edumind.demo', label: 'Administrator' },
]

function MiniRoute() {
  const stops = [
    { c: 'var(--color-low)', l: 'Python' },
    { c: 'var(--color-high)', l: 'Pandas' },
    { c: 'var(--color-medium)', l: 'Statistics' },
    { c: null, l: 'Visualisation' },
    { c: null, l: 'ML basics' },
  ]
  return (
    <div className="relative mt-10 max-w-md" aria-hidden>
      <div className="absolute left-[10%] right-[10%] top-[13px] h-[3px] rounded bg-line" />
      <div className="route-enter absolute left-[10%] top-[13px] h-[3px] w-[40%] rounded bg-ink" />
      <div className="relative grid grid-cols-5">
        {stops.map((s, i) => (
          <div key={s.l} className="flex flex-col items-center text-center">
            <span
              className="flex h-7 w-7 items-center justify-center rounded-full text-xs font-extrabold"
              style={{
                background: s.c ?? 'var(--color-paper)',
                color: s.c ? '#fff' : 'var(--color-muted)',
                border: s.c ? 'none' : '2px dashed var(--color-upcoming)',
                boxShadow: '0 0 0 4px var(--color-paper)',
              }}
            >
              {i + 1}
            </span>
            <span className="mt-2 text-xs text-ink-2">{s.l}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

export default function Login() {
  const { user, login } = useAuth()
  const navigate = useNavigate()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  if (user) return <Navigate to={homeFor(user.role)} replace />

  const submit = async (e: FormEvent) => {
    e.preventDefault()
    setBusy(true)
    setError(null)
    try {
      const u = await login(email, password)
      navigate(homeFor(u.role))
    } catch (err) {
      setError((err as Error).message)
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="min-h-screen md:grid md:grid-cols-[1.15fr_1fr]">
      <section className="px-6 pt-8 pb-10 sm:px-12 md:py-14">
        <Brand />
        <h1 className="mt-14 max-w-[16ch] text-[2.4rem] font-extrabold sm:text-[3.2rem]">
          Know where you stand. Know what to study next.
        </h1>
        <p className="mt-5 max-w-[52ch] text-lg text-ink-2">
          EduMind reads your assessments and course activity, flags trouble early, and points you to the topics
          that need work. Its tutor answers from your course notes and shows the page it used.
        </p>
        <MiniRoute />
      </section>

      <section className="flex items-start bg-surface px-6 py-10 sm:px-12 md:items-center md:border-l md:border-line">
        <div className="w-full max-w-sm">
          <h2 className="text-2xl font-bold">Sign in</h2>
          <form onSubmit={submit} className="mt-6 space-y-4">
            <label className="block">
              <span className="text-sm font-bold">Email</span>
              <input
                type="email"
                required
                autoComplete="username"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="mt-1 w-full rounded-md border border-line-strong bg-surface px-3 py-2"
              />
            </label>
            <label className="block">
              <span className="text-sm font-bold">Password</span>
              <input
                type="password"
                required
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="mt-1 w-full rounded-md border border-line-strong bg-surface px-3 py-2"
              />
            </label>
            {error && (
              <p className="text-sm text-high" role="alert">
                {error}
              </p>
            )}
            <Button type="submit" disabled={busy} className="w-full">
              {busy ? 'Signing in…' : 'Sign in'}
            </Button>
          </form>
          <p className="mt-4 text-sm text-ink-2">
            New student?{' '}
            <Link to="/register" className="font-bold text-you underline-offset-2 hover:underline">
              Create an account
            </Link>
          </p>

          <div className="mt-10 border-t border-line pt-6">
            <h3 className="text-base font-bold">Try a demo account</h3>
            <p className="mt-1 text-sm text-muted">
              {DEMO_PASSWORD ? 'Pick one to fill in the form.' : 'Pick one to fill in the email; ask the presenter for the password.'}
            </p>
            <ul className="mt-3 space-y-1">
              {DEMO_ACCOUNTS.map((a) => (
                <li key={a.email}>
                  <button
                    type="button"
                    onClick={() => {
                      setEmail(a.email)
                      if (DEMO_PASSWORD) setPassword(DEMO_PASSWORD)
                    }}
                    className="w-full rounded-md px-2 py-1.5 text-left hover:bg-paper"
                  >
                    <span className="block text-sm font-bold">{a.label}</span>
                    <span className="block text-xs text-muted">{a.email}</span>
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>
    </div>
  )
}
