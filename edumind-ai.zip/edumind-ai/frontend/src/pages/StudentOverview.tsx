import { useSearchParams } from 'react-router-dom'
import type { CourseAnalytics, CourseSummary, Dashboard, Mastery, Recommendation } from '../api/client'
import { ActivityChart, ScoreChart } from '../components/Charts'
import Recommendations from '../components/Recommendations'
import RiskSummary from '../components/RiskSummary'
import TopicRoute from '../components/TopicRoute'
import { Empty, ErrorState, Loading, SectionTitle, SyntheticNotice } from '../components/ui'
import { num, useApi } from '../lib/useApi'

export function useSelectedCourse() {
  const dash = useApi<Dashboard>('/students/me/dashboard')
  const [params, setParams] = useSearchParams()
  const courses = dash.data?.courses ?? []
  const wanted = Number(params.get('course'))
  const course = courses.find((c) => c.course_id === wanted) ?? courses[0] ?? null
  const select = (id: number) => setParams({ course: String(id) })
  return { dash, courses, course, select }
}

export function CourseTabs({ courses, course, select }: { courses: CourseSummary[]; course: CourseSummary; select: (id: number) => void }) {
  if (courses.length < 2) return null
  return (
    <div role="tablist" aria-label="Courses" className="mb-6 flex flex-wrap gap-2">
      {courses.map((c) => (
        <button
          key={c.course_id}
          role="tab"
          aria-selected={c.course_id === course.course_id}
          onClick={() => select(c.course_id)}
          className={`rounded-full border px-3 py-1 text-sm ${
            c.course_id === course.course_id ? 'border-ink bg-ink text-white' : 'border-line-strong bg-surface text-ink-2'
          }`}
        >
          {c.title}
        </button>
      ))}
    </div>
  )
}

function Stat({ label, value, compare }: { label: string; value: string; compare?: string }) {
  return (
    <div>
      <dt className="text-sm text-ink-2">{label}</dt>
      <dd className="font-display text-2xl font-bold">{value}</dd>
      {compare && <dd className="text-xs text-muted">{compare}</dd>}
    </div>
  )
}

export default function StudentOverview() {
  const { dash, courses, course, select } = useSelectedCourse()
  const cid = course?.course_id
  const analytics = useApi<CourseAnalytics>(cid ? `/students/me/courses/${cid}/analytics` : null)
  const mastery = useApi<Mastery[]>(cid ? `/students/me/courses/${cid}/mastery` : null)
  const recos = useApi<Recommendation[]>(cid ? `/students/me/courses/${cid}/recommendations` : null)

  if (dash.loading) return <Loading label="Loading your courses" />
  if (dash.error) return <ErrorState message={dash.error} onRetry={dash.reload} />
  if (!course)
    return (
      <Empty title="No courses yet">
        Your dashboard fills in once your college adds your enrolments and assessment records.
      </Empty>
    )

  const k = course.kpis
  return (
    <>
      <CourseTabs courses={courses} course={course} select={select} />
      <SyntheticNotice source={course.data_source} />
      <p className="text-ink-2">
        <span className="font-bold text-ink">{course.title}</span>, day {course.as_of_day} of {course.length_days}
      </p>

      <div className="mt-4">
        {course.risk ? (
          <RiskSummary prediction={course.risk} />
        ) : (
          <Empty title="No risk estimate yet">Estimates start once the first assessments are due.</Empty>
        )}
      </div>

      <dl className="mt-10 grid grid-cols-2 gap-6 border-y border-line py-5 sm:grid-cols-4">
        <Stat label="Average score" value={k.avg_score === null ? '—' : `${num(k.avg_score)}%`} compare={k.class_avg_score ? `Class ${num(k.class_avg_score)}%` : undefined} />
        <Stat label="Submitted" value={`${k.submitted} of ${k.due}`} compare="assessments due so far" />
        <Stat label="Active days" value={num(k.active_days)} compare={k.class_median_active_days ? `Class median ${num(k.class_median_active_days)}` : undefined} />
        <Stat label="Platform interactions" value={num(k.total_clicks)} compare="since registration" />
      </dl>

      <section className="mt-12 grid gap-12 lg:grid-cols-[1.1fr_1fr]">
        <div>
          <SectionTitle aside="Ranked for you">Do this next</SectionTitle>
          {recos.loading && <Loading />}
          {recos.error && <ErrorState message={recos.error} onRetry={recos.reload} />}
          {recos.data && <Recommendations items={recos.data} courseId={course.course_id} onChange={recos.setData} />}
        </div>
        <div>
          <SectionTitle aside="You vs class average">Assessment scores</SectionTitle>
          {analytics.data ? <ScoreChart rows={analytics.data.assessments} /> : <Loading />}
        </div>
      </section>

      <section className="mt-14">
        <SectionTitle aside="Mastery from your assessed work">Your path through the course</SectionTitle>
        {mastery.error && <ErrorState message={mastery.error} onRetry={mastery.reload} />}
        {mastery.data ? <TopicRoute topics={mastery.data} linkTo={`/app/topics?course=${course.course_id}`} /> : <Loading />}
      </section>

      <section className="mt-14">
        <SectionTitle aside="Interactions per week">Learning activity</SectionTitle>
        {analytics.data ? <ActivityChart weeks={analytics.data.weekly_activity} /> : <Loading />}
      </section>
    </>
  )
}
