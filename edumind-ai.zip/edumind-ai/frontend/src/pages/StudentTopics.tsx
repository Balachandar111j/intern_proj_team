import { Link } from 'react-router-dom'
import type { CourseAnalytics, Mastery } from '../api/client'
import TopicRoute from '../components/TopicRoute'
import { ErrorState, Loading, MasteryPill, SectionTitle, SyntheticNotice } from '../components/ui'
import { pct, useApi } from '../lib/useApi'
import { CourseTabs, useSelectedCourse } from './StudentOverview'

export default function StudentTopics() {
  const { dash, courses, course, select } = useSelectedCourse()
  const cid = course?.course_id
  const mastery = useApi<Mastery[]>(cid ? `/students/me/courses/${cid}/mastery` : null)
  const analytics = useApi<CourseAnalytics>(cid ? `/students/me/courses/${cid}/analytics` : null)

  if (dash.loading) return <Loading />
  if (dash.error) return <ErrorState message={dash.error} onRetry={dash.reload} />
  if (!course) return <p>No courses yet.</p>

  return (
    <>
      <CourseTabs courses={courses} course={course} select={select} />
      <SyntheticNotice source={course.data_source} />
      <h1 className="text-3xl font-extrabold">{course.title}: topics</h1>
      <p className="mt-2 max-w-2xl text-ink-2">
        Mastery is the recency-weighted average of your scores on the assessments that test each topic. Later work
        counts a little more than earlier work.
      </p>

      <div className="mt-8">{mastery.data ? <TopicRoute topics={mastery.data} /> : <Loading />}</div>

      <div className="mt-12 space-y-10">
        {mastery.data?.map((t) => (
          <section key={t.topic_id} id={`topic-${t.topic_id}`} className="scroll-mt-6 border-t border-line pt-6">
            <div className="flex flex-wrap items-baseline justify-between gap-3">
              <h2 className="text-xl font-bold">
                <span className="mr-2 text-ink-2">{t.sequence}.</span>
                {t.title}
              </h2>
              <MasteryPill status={t.status} />
            </div>
            <p className="mt-1 text-sm text-ink-2">
              {t.mastery !== null ? `Your mastery ${pct(t.mastery)}` : 'Not assessed yet'}
              {t.class_mastery !== null && `, class ${pct(t.class_mastery)}`}
              {t.weak_prerequisites.length > 0 && `. Builds on ${t.weak_prerequisites.join(', ')}, which needs work first.`}
            </p>
            {t.evidence.length > 0 && (
              <table className="mt-3 w-full max-w-xl text-sm">
                <caption className="sr-only">Evidence for {t.title}</caption>
                <thead>
                  <tr className="text-left text-ink-2">
                    <th className="py-1 font-normal">Assessment</th>
                    <th className="py-1 font-normal">Due day</th>
                    <th className="py-1 font-normal">Your score</th>
                  </tr>
                </thead>
                <tbody>
                  {t.evidence.map((e) => (
                    <tr key={e.assessment} className="border-t border-line">
                      <td className="py-1.5">{e.assessment}</td>
                      <td className="py-1.5">{e.due_day ?? '—'}</td>
                      <td className="py-1.5 font-bold">{e.score === null ? <span className="text-high">Not submitted</span> : `${e.score}%`}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
            <p className="mt-3 text-sm">
              <Link
                to={`/app/tutor?course=${course.course_id}&quiz=${encodeURIComponent(t.title)}`}
                className="font-bold text-you underline-offset-2 hover:underline"
              >
                Quiz me on {t.title}
              </Link>
            </p>
          </section>
        ))}
      </div>

      {analytics.data && (
        <section className="mt-14">
          <SectionTitle>All assessments</SectionTitle>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[560px] text-sm">
              <thead>
                <tr className="text-left text-ink-2">
                  <th className="py-1 font-normal">Assessment</th>
                  <th className="py-1 font-normal">Due day</th>
                  <th className="py-1 font-normal">Weight</th>
                  <th className="py-1 font-normal">Your score</th>
                  <th className="py-1 font-normal">Class average</th>
                  <th className="py-1 font-normal">Class submitted</th>
                </tr>
              </thead>
              <tbody>
                {analytics.data.assessments.map((a) => (
                  <tr key={a.id} className="border-t border-line">
                    <td className="py-1.5 font-bold">{a.title}</td>
                    <td className="py-1.5">{a.due_day ?? 'End of course'}</td>
                    <td className="py-1.5">{a.weight}%</td>
                    <td className="py-1.5">
                      {a.status === 'submitted' ? `${a.score}%${a.late ? ' (late)' : ''}` : a.status === 'missed' ? <span className="text-high">Not submitted</span> : 'Upcoming'}
                    </td>
                    <td className="py-1.5">{a.class_avg === null ? '—' : `${a.class_avg}%`}</td>
                    <td className="py-1.5">{pct(a.class_submission_rate)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}
    </>
  )
}
