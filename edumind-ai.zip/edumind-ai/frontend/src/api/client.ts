// Thin fetch wrapper. The session lives in an HttpOnly cookie, so the frontend never
// touches the token; every write sends the CSRF header the backend expects.

export class ApiError extends Error {
  status: number
  constructor(status: number, message: string) {
    super(message)
    this.status = status
  }
}

const BASE = '/api/v1'

async function request<T>(method: string, path: string, body?: unknown): Promise<T> {
  const headers: Record<string, string> = { 'X-Requested-With': 'EduMind' }
  let payload: BodyInit | undefined
  if (body instanceof FormData) {
    payload = body
  } else if (body !== undefined) {
    headers['Content-Type'] = 'application/json'
    payload = JSON.stringify(body)
  }
  const resp = await fetch(BASE + path, { method, headers, body: payload, credentials: 'same-origin' })
  if (resp.status === 204) return undefined as T
  const data = await resp.json().catch(() => ({}))
  if (!resp.ok) {
    const detail = Array.isArray(data?.detail)
      ? data.detail.map((d: { msg: string }) => d.msg.replace(/^Value error, /, '')).join('. ')
      : data?.detail
    throw new ApiError(resp.status, detail || `Request failed (${resp.status})`)
  }
  return data as T
}

export const api = {
  get: <T>(path: string) => request<T>('GET', path),
  post: <T>(path: string, body?: unknown) => request<T>('POST', path, body ?? {}),
  patch: <T>(path: string, body: unknown) => request<T>('PATCH', path, body),
  del: (path: string) => request<void>('DELETE', path),
}

// --- Types mirroring the API -----------------------------------------------------------
export type Role = 'student' | 'faculty' | 'admin'
export type RiskLevel = 'low' | 'medium' | 'high'
export type MasteryStatus = 'mastered' | 'developing' | 'weak' | 'missed' | 'upcoming'

export interface User {
  id: number
  email: string
  full_name: string
  role: Role
}

export interface Factor {
  feature: string
  label: string
  value: number | null
  typical: number | null
  contribution: number
  direction: 'increases_risk' | 'decreases_risk'
  reason: string
}

export interface Prediction {
  id: number
  risk_level: RiskLevel
  risk_probability: number
  as_of_day: number
  model_version: string
  algorithm: string
  data_source: string
  thresholds: { high: number; medium: number }
  factors: Factor[]
  created_at: string
}

export interface Kpis {
  avg_score: number | null
  class_avg_score: number | null
  submitted: number
  due: number
  active_days: number
  class_median_active_days: number | null
  total_clicks: number
}

export interface CourseSummary {
  course_id: number
  code: string
  title: string
  as_of_day: number
  length_days: number
  data_source: string
  risk: Prediction | null
  kpis: Kpis
}

export interface Dashboard {
  student: { id: number; full_name: string; student_code: string; department: string | null }
  courses: CourseSummary[]
}

export interface AssessmentRow {
  id: number
  title: string
  type: string
  due_day: number | null
  weight: number
  status: 'submitted' | 'missed' | 'upcoming'
  score: number | null
  submitted_day: number | null
  late: boolean
  class_avg: number | null
  class_submission_rate: number | null
}

export interface CourseAnalytics {
  as_of_day: number
  kpis: Kpis
  assessments: AssessmentRow[]
  weekly_activity: { week: number; you: number; class_avg: number }[]
}

export interface Mastery {
  topic_id: number
  title: string
  sequence: number
  status: MasteryStatus
  mastery: number | null
  class_mastery: number | null
  evidence: { assessment: string; score: number | null; submitted_day: number | null; due_day: number | null }[]
  weak_prerequisites: string[]
  next_due_day: number | null
}

export interface Recommendation {
  id: number
  rank: number
  score: number
  reason: string
  status: 'new' | 'opened' | 'completed' | 'dismissed'
  rating: number | null
  topic: string
  resource: {
    id: number
    title: string
    resource_type: 'video' | 'article' | 'course' | 'practice' | 'tutor_quiz'
    url: string | null
    provider: string
    difficulty: string
    est_minutes: number
  }
}

export interface Citation {
  ref: number
  document_id: number
  title: string
  page: number
  snippet: string
  similarity: number
}

export interface ChatMessage {
  id: number
  role: 'user' | 'assistant'
  content: string
  citations: Citation[]
  meta: Record<string, unknown>
  created_at: string
}

export interface TutorDocument {
  id: number
  title: string
  course_id: number
  visibility: 'private' | 'course'
  status: 'processing' | 'ready' | 'failed'
  page_count: number
  chunk_count: number
  error: string | null
  is_mine: boolean
  created_at: string
}
