import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'
import type { AssessmentRow } from '../api/client'

const YOU = 'var(--color-you)'
const CLASS = 'var(--color-class)'
const AXIS = { fontSize: 12, fill: 'var(--color-muted)' }
const GRID = 'var(--color-line)'

const tooltipStyle = {
  contentStyle: {
    borderRadius: 8,
    border: '1px solid var(--color-line)',
    boxShadow: '0 4px 16px rgba(28,37,65,0.08)',
    fontSize: 13,
  },
  labelStyle: { fontWeight: 700, color: 'var(--color-ink)' },
}

/** You vs class average for each assessment due so far (two series, one axis). */
export function ScoreChart({ rows }: { rows: AssessmentRow[] }) {
  const data = rows
    .filter((r) => r.status !== 'upcoming')
    .map((r) => ({ name: r.title, you: r.score, class: r.class_avg }))
  if (!data.length) return <p className="text-sm text-muted">No assessments are due yet.</p>
  const summary = data.map((d) => `${d.name}: you ${d.you ?? 'not submitted'}, class ${d.class ?? 'n/a'}`).join('; ')
  return (
    <figure aria-label={`Assessment scores. ${summary}`} className="h-64">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} barGap={2} barCategoryGap="28%" margin={{ top: 8, right: 8, bottom: 0, left: -18 }}>
          <CartesianGrid vertical={false} stroke={GRID} />
          <XAxis dataKey="name" tick={AXIS} tickLine={false} axisLine={{ stroke: GRID }} />
          <YAxis domain={[0, 100]} ticks={[0, 25, 50, 75, 100]} tick={AXIS} tickLine={false} axisLine={false} />
          <Tooltip {...tooltipStyle} cursor={{ fill: 'rgba(28,37,65,0.04)' }} formatter={(v) => (v == null ? 'Not submitted' : `${v}%`)} />
          <Legend iconType="circle" iconSize={9} wrapperStyle={{ fontSize: 13, color: 'var(--color-ink-2)' }} />
          <Bar dataKey="you" name="You" fill={YOU} radius={[4, 4, 0, 0]} maxBarSize={22} isAnimationActive={false} />
          <Bar dataKey="class" name="Class average" fill={CLASS} radius={[4, 4, 0, 0]} maxBarSize={22} isAnimationActive={false} />
        </BarChart>
      </ResponsiveContainer>
    </figure>
  )
}

/** Weekly learning-platform activity, you vs class average. */
export function ActivityChart({ weeks }: { weeks: { week: number; you: number; class_avg: number }[] }) {
  const data = weeks.map((w) => ({ name: w.week < 0 ? `Pre ${-w.week}` : `Wk ${w.week + 1}`, you: w.you, class: w.class_avg }))
  return (
    <figure aria-label="Weekly learning-platform activity compared with the class average" className="h-64">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ top: 8, right: 12, bottom: 0, left: -18 }}>
          <CartesianGrid vertical={false} stroke={GRID} />
          <XAxis dataKey="name" tick={AXIS} tickLine={false} axisLine={{ stroke: GRID }} interval="preserveStartEnd" minTickGap={16} />
          <YAxis tick={AXIS} tickLine={false} axisLine={false} allowDecimals={false} />
          <Tooltip {...tooltipStyle} formatter={(v) => `${v} interactions`} />
          <Legend iconType="circle" iconSize={9} wrapperStyle={{ fontSize: 13, color: 'var(--color-ink-2)' }} />
          <Line type="monotone" dataKey="you" name="You" stroke={YOU} strokeWidth={2} dot={false} activeDot={{ r: 5, strokeWidth: 2, stroke: '#fff' }} isAnimationActive={false} />
          <Line type="monotone" dataKey="class" name="Class average" stroke={CLASS} strokeWidth={2} dot={false} activeDot={{ r: 5, strokeWidth: 2, stroke: '#fff' }} isAnimationActive={false} />
        </LineChart>
      </ResponsiveContainer>
    </figure>
  )
}

/** Single-series weekly activity for a whole class. */
export function ClassActivityChart({ weeks }: { weeks: { week: number; avg_clicks: number }[] }) {
  const data = weeks.map((w) => ({ name: w.week < 0 ? `Pre ${-w.week}` : `Wk ${w.week + 1}`, avg: w.avg_clicks }))
  return (
    <figure aria-label="Average weekly learning-platform activity per student" className="h-56">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ top: 8, right: 12, bottom: 0, left: -18 }}>
          <CartesianGrid vertical={false} stroke={GRID} />
          <XAxis dataKey="name" tick={AXIS} tickLine={false} axisLine={{ stroke: GRID }} interval="preserveStartEnd" minTickGap={16} />
          <YAxis tick={AXIS} tickLine={false} axisLine={false} />
          <Tooltip {...tooltipStyle} formatter={(v) => `${v} interactions per student`} />
          <Line type="monotone" dataKey="avg" name="Average per student" stroke={YOU} strokeWidth={2} dot={false} activeDot={{ r: 5, strokeWidth: 2, stroke: '#fff' }} isAnimationActive={false} />
        </LineChart>
      </ResponsiveContainer>
    </figure>
  )
}
