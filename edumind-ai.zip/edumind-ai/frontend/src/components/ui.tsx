import { AlertTriangle, CheckCircle2, Circle, CircleAlert, CircleDashed, CircleDot, Loader2, XCircle } from 'lucide-react'
import type { ReactNode } from 'react'
import type { MasteryStatus, RiskLevel } from '../api/client'

export const RISK: Record<RiskLevel, { label: string; text: string; bg: string; Icon: typeof Circle }> = {
  high: { label: 'High risk', text: 'text-high', bg: 'bg-high-bg', Icon: AlertTriangle },
  medium: { label: 'Medium risk', text: 'text-medium', bg: 'bg-medium-bg', Icon: CircleAlert },
  low: { label: 'On track', text: 'text-low', bg: 'bg-low-bg', Icon: CheckCircle2 },
}

export const MASTERY: Record<MasteryStatus, { label: string; color: string; text: string; Icon: typeof Circle }> = {
  mastered: { label: 'Mastered', color: 'var(--color-low)', text: 'text-low', Icon: CheckCircle2 },
  developing: { label: 'Developing', color: 'var(--color-medium)', text: 'text-medium', Icon: CircleDot },
  weak: { label: 'Needs work', color: 'var(--color-high)', text: 'text-high', Icon: CircleAlert },
  missed: { label: 'Not submitted', color: 'var(--color-high)', text: 'text-high', Icon: XCircle },
  upcoming: { label: 'Coming up', color: 'var(--color-upcoming)', text: 'text-muted', Icon: CircleDashed },
}

export function RiskPill({ level, className = '' }: { level: RiskLevel; className?: string }) {
  const r = RISK[level]
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-sm font-bold ${r.text} ${r.bg} ${className}`}>
      <r.Icon size={15} aria-hidden /> {r.label}
    </span>
  )
}

export function MasteryPill({ status }: { status: MasteryStatus }) {
  const m = MASTERY[status]
  return (
    <span className={`inline-flex items-center gap-1 text-sm font-bold ${m.text}`}>
      <m.Icon size={15} aria-hidden /> {m.label}
    </span>
  )
}

export function Loading({ label = 'Loading' }: { label?: string }) {
  return (
    <div className="flex items-center gap-2 py-16 text-muted" role="status">
      <Loader2 className="animate-spin" size={18} aria-hidden /> {label}…
    </div>
  )
}

export function ErrorState({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="my-6 rounded-lg border border-high/30 bg-high-bg px-4 py-3 text-high" role="alert">
      <p className="font-bold">Couldn't load this.</p>
      <p className="text-sm">{message}</p>
      {onRetry && (
        <button onClick={onRetry} className="mt-2 text-sm font-bold underline underline-offset-2">
          Try again
        </button>
      )}
    </div>
  )
}

export function Empty({ title, children }: { title: string; children?: ReactNode }) {
  return (
    <div className="rounded-lg border border-dashed border-line-strong px-5 py-8 text-ink-2">
      <p className="font-bold text-ink">{title}</p>
      {children && <div className="mt-1 text-sm">{children}</div>}
    </div>
  )
}

export function SyntheticNotice({ source }: { source?: string }) {
  if (source !== 'synthetic') return null
  return (
    <p className="mb-6 rounded-md border border-line bg-surface px-3 py-2 text-sm text-ink-2">
      Demo data: these students were generated in the OULAD format so the platform can be tried out.
      Predictions are illustrative until the model is retrained on the real dataset.
    </p>
  )
}

export function SectionTitle({ children, aside }: { children: ReactNode; aside?: ReactNode }) {
  return (
    <div className="mb-3 flex flex-wrap items-baseline justify-between gap-2">
      <h2 className="text-xl font-bold">{children}</h2>
      {aside && <div className="text-sm text-muted">{aside}</div>}
    </div>
  )
}

export function Button({
  children,
  variant = 'primary',
  ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'quiet' }) {
  const styles =
    variant === 'primary'
      ? 'bg-ink text-white hover:bg-[#2b3760] disabled:opacity-50'
      : 'border border-line-strong bg-surface text-ink hover:border-ink-2 disabled:opacity-50'
  return (
    <button {...props} className={`inline-flex items-center justify-center gap-2 rounded-md px-4 py-2 text-sm font-bold transition-colors ${styles} ${props.className ?? ''}`}>
      {children}
    </button>
  )
}
