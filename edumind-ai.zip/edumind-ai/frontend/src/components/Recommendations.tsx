import { BookOpen, Check, ExternalLink, GraduationCap, MessageSquareText, PlayCircle, X } from 'lucide-react'
import { Link } from 'react-router-dom'
import { api, type Recommendation } from '../api/client'

const TYPE = {
  video: { label: 'Video', Icon: PlayCircle },
  article: { label: 'Reading', Icon: BookOpen },
  course: { label: 'Course', Icon: GraduationCap },
  practice: { label: 'Practice', Icon: BookOpen },
  tutor_quiz: { label: 'Quiz with the AI tutor', Icon: MessageSquareText },
}

function minutes(m: number) {
  return m >= 120 ? `${Math.round(m / 60)} h` : `${m} min`
}

export default function Recommendations({
  items,
  courseId,
  onChange,
}: {
  items: Recommendation[]
  courseId: number
  onChange: (next: Recommendation[]) => void
}) {
  const update = async (r: Recommendation, status: 'opened' | 'completed' | 'dismissed') => {
    const saved = await api.patch<Recommendation>(`/students/me/recommendations/${r.id}`, { status })
    onChange(status === 'opened' ? items.map((x) => (x.id === r.id ? saved : x)) : items.filter((x) => x.id !== r.id))
  }

  if (!items.length)
    return <p className="text-ink-2">Nothing to catch up on right now. Keep going with the next topic.</p>

  return (
    <ol className="space-y-5">
      {items.map((r, i) => {
        const t = TYPE[r.resource.resource_type]
        const first = i === 0
        const open = r.resource.url ? (
          <a
            href={r.resource.url}
            target="_blank"
            rel="noreferrer noopener"
            onClick={() => update(r, 'opened')}
            className="inline-flex items-center gap-1 font-bold text-you underline-offset-2 hover:underline"
          >
            Open <ExternalLink size={14} aria-hidden />
            <span className="sr-only">(opens in a new tab)</span>
          </a>
        ) : (
          <Link
            to={`/app/tutor?course=${courseId}&quiz=${encodeURIComponent(r.topic)}`}
            onClick={() => update(r, 'opened')}
            className="font-bold text-you underline-offset-2 hover:underline"
          >
            Start quiz
          </Link>
        )
        return (
          <li key={r.id} className="grid grid-cols-[2rem_1fr] gap-x-3">
            <span className="pt-0.5 font-display text-xl font-extrabold text-ink-2" aria-hidden>
              {i + 1}
            </span>
            <div>
              <p className="text-[17px] font-bold leading-snug">
                <span className={first ? 'highlight' : ''}>{r.resource.title}</span>
              </p>
              <p className="mt-0.5 flex flex-wrap items-center gap-x-2 text-sm text-muted">
                <t.Icon size={14} aria-hidden /> {t.label}, {minutes(r.resource.est_minutes)}, {r.resource.provider}
              </p>
              <p className="mt-1.5 text-[15px] text-ink-2">{r.reason}</p>
              <div className="mt-2 flex flex-wrap items-center gap-4 text-sm">
                {open}
                <button onClick={() => update(r, 'completed')} className="inline-flex items-center gap-1 text-ink-2 hover:text-ink">
                  <Check size={15} aria-hidden /> Mark as done
                </button>
                <button onClick={() => update(r, 'dismissed')} className="inline-flex items-center gap-1 text-ink-2 hover:text-ink">
                  <X size={15} aria-hidden /> Not useful
                </button>
                {r.status === 'opened' && <span className="text-xs text-muted">Opened</span>}
              </div>
            </div>
          </li>
        )
      })}
    </ol>
  )
}
