import { Link } from 'react-router-dom'
import type { Mastery } from '../api/client'
import { pct } from '../lib/useApi'
import { MASTERY } from './ui'

/** The course as a route: one station per topic, in teaching order. */
export default function TopicRoute({ topics, linkTo }: { topics: Mastery[]; linkTo?: string }) {
  if (!topics.length) return null
  const n = topics.length
  const lastAssessed = topics.reduce((acc, t, i) => (t.status !== 'upcoming' ? i : acc), -1)
  const edge = `calc(100% / ${2 * n})`

  return (
    <div className="relative">
      {/* Track (desktop): grey for the whole course, ink up to the topics assessed so far. */}
      <div className="absolute top-[19px] hidden h-[3px] rounded bg-line md:block" style={{ left: edge, right: edge }} aria-hidden />
      {lastAssessed > 0 && (
        <div
          className="route-enter absolute top-[19px] hidden h-[3px] rounded bg-ink md:block"
          style={{ left: edge, width: `calc((100% - 100% / ${n}) * ${lastAssessed / (n - 1)})` }}
          aria-hidden
        />
      )}
      <ol className="route-grid relative grid gap-4 md:gap-3" style={{ '--n': n } as React.CSSProperties}>
        {topics.map((t) => {
          const m = MASTERY[t.status]
          const filled = t.status !== 'upcoming'
          const body = (
            <>
              <span
                className="relative z-10 flex h-10 w-10 shrink-0 items-center justify-center rounded-full font-display text-[15px] font-extrabold"
                style={{
                  background: filled ? m.color : 'var(--color-surface)',
                  color: filled ? '#fff' : 'var(--color-muted)',
                  border: filled ? 'none' : '2px dashed var(--color-upcoming)',
                  boxShadow: '0 0 0 4px var(--color-paper)',
                }}
                aria-hidden
              >
                {t.sequence}
              </span>
              <span className="min-w-0 md:mt-3 md:block">
                <span className="block font-bold leading-snug">{t.title}</span>
                <span className={`mt-0.5 flex items-center gap-1 text-sm font-bold ${m.text}`}>
                  <m.Icon size={14} aria-hidden />
                  {m.label}
                  {t.mastery !== null && <span className="font-normal text-ink-2"> {pct(t.mastery)}</span>}
                </span>
                {t.class_mastery !== null && <span className="block text-xs text-muted">Class {pct(t.class_mastery)}</span>}
                {t.status === 'upcoming' && t.next_due_day !== null && (
                  <span className="block text-xs text-muted">Assessed around day {t.next_due_day}</span>
                )}
                {t.weak_prerequisites.length > 0 && (
                  <span className="mt-1 block text-xs text-high">Builds on {t.weak_prerequisites.join(', ')}</span>
                )}
              </span>
            </>
          )
          const cls = 'flex items-start gap-3 md:flex-col md:items-center md:text-center'
          return (
            <li key={t.topic_id}>
              {linkTo ? (
                <Link to={`${linkTo}#topic-${t.topic_id}`} className={`${cls} rounded-md hover:bg-surface/60`}>
                  {body}
                </Link>
              ) : (
                <div className={cls}>{body}</div>
              )}
            </li>
          )
        })}
      </ol>
    </div>
  )
}
