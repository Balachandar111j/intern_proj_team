import { TrendingDown, TrendingUp } from 'lucide-react'
import type { Prediction } from '../api/client'
import { pct } from '../lib/useApi'
import { RISK, RiskPill } from './ui'

const HEADLINE = {
  student: {
    high: 'You’re at high risk of not completing this course.',
    medium: 'This course needs some attention.',
    low: 'You’re on track in this course.',
  },
  faculty: {
    high: 'High risk of failing or withdrawing.',
    medium: 'Some warning signs.',
    low: 'On track.',
  },
}

/** Risk meter: the three zones come from the model's validated thresholds. */
function RiskMeter({ p, thresholds }: { p: number; thresholds: Prediction['thresholds'] }) {
  const zones = [
    { from: 0, to: thresholds.medium, cls: 'bg-low/25', label: 'On track' },
    { from: thresholds.medium, to: thresholds.high, cls: 'bg-medium/30', label: 'Medium' },
    { from: thresholds.high, to: 1, cls: 'bg-high/25', label: 'High' },
  ]
  return (
    <div className="max-w-md">
      <div className="relative h-3 overflow-hidden rounded-full" aria-hidden>
        {zones.map((z) => (
          <div key={z.label} className={`absolute inset-y-0 ${z.cls}`} style={{ left: `${z.from * 100}%`, width: `${(z.to - z.from) * 100}%` }} />
        ))}
      </div>
      <div className="relative h-0" aria-hidden>
        <div className="absolute -top-[18px] h-[24px] w-[4px] -translate-x-1/2 rounded bg-ink ring-2 ring-surface" style={{ left: `${p * 100}%` }} />
      </div>
      <div className="mt-2 flex justify-between text-xs text-muted">
        <span>0%</span>
        <span>
          Medium from {pct(thresholds.medium)}, high from {pct(thresholds.high)}
        </span>
        <span>100%</span>
      </div>
    </div>
  )
}

export default function RiskSummary({ prediction, audience = 'student' }: { prediction: Prediction; audience?: 'student' | 'faculty' }) {
  const r = RISK[prediction.risk_level]
  const raising = prediction.factors.filter((f) => f.direction === 'increases_risk')
  const lowering = prediction.factors.filter((f) => f.direction === 'decreases_risk')
  return (
    <section aria-labelledby="risk-heading">
      <div className="flex flex-wrap items-center gap-3">
        <RiskPill level={prediction.risk_level} />
        <span className="text-sm text-ink-2">Estimated on day {prediction.as_of_day}</span>
      </div>
      <h1
        id="risk-heading"
        className={`mt-3 max-w-[22ch] font-extrabold ${audience === 'student' ? 'text-[2rem] sm:text-[2.6rem]' : 'text-2xl sm:text-3xl'}`}
      >
        {HEADLINE[audience][prediction.risk_level]}
      </h1>
      <div className="mt-5 flex flex-wrap items-end gap-x-8 gap-y-4">
        <p className="leading-none">
          <span className={`font-display text-5xl font-extrabold ${r.text}`}>{pct(prediction.risk_probability)}</span>
          <span className="ml-2 text-ink-2">chance of failing or withdrawing</span>
        </p>
      </div>
      <div className="mt-4">
        <RiskMeter p={prediction.risk_probability} thresholds={prediction.thresholds} />
      </div>

      <div className="mt-8 grid gap-6 sm:grid-cols-2">
        <div>
          <h2 className="text-base font-bold">What raises the risk</h2>
          <ul className="mt-2 space-y-2">
            {raising.length === 0 && <li className="text-sm text-muted">Nothing stands out.</li>}
            {raising.map((f) => (
              <li key={f.feature} className="flex gap-2">
                <TrendingUp size={18} className="mt-0.5 shrink-0 text-high" aria-label="raises risk" />
                <span>{f.reason}</span>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <h2 className="text-base font-bold">What’s working</h2>
          <ul className="mt-2 space-y-2">
            {lowering.length === 0 && <li className="text-sm text-muted">Nothing stands out yet.</li>}
            {lowering.map((f) => (
              <li key={f.feature} className="flex gap-2">
                <TrendingDown size={18} className="mt-0.5 shrink-0 text-low" aria-label="lowers risk" />
                <span>{f.reason}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
      <p className="mt-6 max-w-2xl text-sm text-muted">
        This is an estimate from the {prediction.algorithm.replace('_', ' ')} model, using only your records up to day{' '}
        {prediction.as_of_day}. It isn’t a grade, and a teacher reviews every high-risk flag before anything happens.
      </p>
    </section>
  )
}
