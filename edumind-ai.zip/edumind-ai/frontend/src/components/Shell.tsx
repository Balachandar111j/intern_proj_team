import { BookOpenCheck, Gauge, GraduationCap, LogOut, MessageSquareText, Route, Users } from 'lucide-react'
import type { ReactNode } from 'react'
import { NavLink, useNavigate } from 'react-router-dom'
import { useAuth } from '../auth/AuthContext'

const NAV = {
  student: [
    { to: '/app', label: 'Overview', Icon: Gauge, end: true },
    { to: '/app/topics', label: 'Topics', Icon: Route },
    { to: '/app/tutor', label: 'AI tutor', Icon: MessageSquareText },
  ],
  faculty: [
    { to: '/faculty', label: 'My classes', Icon: Users, end: true },
    { to: '/faculty/tutor', label: 'Course notes & tutor', Icon: BookOpenCheck },
  ],
  admin: [
    { to: '/admin', label: 'Platform & model', Icon: Gauge, end: true },
    { to: '/admin/tutor', label: 'AI tutor', Icon: MessageSquareText },
  ],
}

export function Brand() {
  return (
    <span className="flex items-center gap-2 font-display text-lg font-extrabold tracking-tight text-ink">
      <GraduationCap size={22} aria-hidden /> EduMind
    </span>
  )
}

export default function Shell({ children }: { children: ReactNode }) {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  if (!user) return null
  const items = NAV[user.role]

  const signOut = async () => {
    await logout()
    navigate('/login')
  }

  return (
    <div className="min-h-screen md:grid md:grid-cols-[232px_1fr]">
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-2 focus:top-2 focus:bg-surface focus:p-2">
        Skip to content
      </a>
      <aside className="border-b border-line bg-surface md:sticky md:top-0 md:flex md:h-screen md:flex-col md:border-b-0 md:border-r">
        <div className="flex items-center justify-between px-5 py-4 md:py-6">
          <Brand />
          <button onClick={signOut} className="text-sm text-ink-2 md:hidden">
            Sign out
          </button>
        </div>
        <nav aria-label="Main" className="flex gap-1 overflow-x-auto px-3 pb-3 md:flex-col md:pb-0">
          {items.map(({ to, label, Icon, end }) => (
            <NavLink
              key={to}
              to={to}
              end={end}
              className={({ isActive }) =>
                `flex shrink-0 items-center gap-2.5 rounded-md px-3 py-2 text-[15px] ${
                  isActive ? 'bg-paper font-bold text-ink' : 'text-ink-2 hover:bg-paper hover:text-ink'
                }`
              }
            >
              <Icon size={18} aria-hidden /> {label}
            </NavLink>
          ))}
        </nav>
        <div className="mt-auto hidden border-t border-line px-5 py-4 md:block">
          <p className="text-sm font-bold">{user.full_name}</p>
          <p className="truncate text-xs text-muted">{user.email}</p>
          <button onClick={signOut} className="mt-3 flex items-center gap-1.5 text-sm text-ink-2 hover:text-ink">
            <LogOut size={15} aria-hidden /> Sign out
          </button>
        </div>
      </aside>
      <main id="main" className="mx-auto w-full max-w-[1120px] px-4 py-6 sm:px-8 md:py-10">
        {children}
      </main>
    </div>
  )
}
