import { FileText } from 'lucide-react'
import { Fragment, type ReactNode } from 'react'
import type { Citation } from '../api/client'

/** Minimal, safe markdown: bold, italics, bullet and numbered lists, and [n] citations.
 *  Everything is rendered as React text nodes, never as raw HTML. */
function inline(text: string, cites: Map<number, Citation>, key: string): ReactNode[] {
  const parts = text.split(/(\*\*[^*]+\*\*|\[\d+\]|(?<![\w*])_[^_]+_(?!\w))/g)
  return parts.map((part, i) => {
    const k = `${key}-${i}`
    if (/^\*\*[^*]+\*\*$/.test(part)) return <strong key={k}>{part.slice(2, -2)}</strong>
    if (/^_[^_]+_$/.test(part)) return <em key={k}>{part.slice(1, -1)}</em>
    const m = part.match(/^\[(\d+)\]$/)
    if (m) {
      const c = cites.get(Number(m[1]))
      if (!c) return null
      return (
        <a
          key={k}
          href={`#cite-${key.split('-')[0]}-${c.ref}`}
          title={`${c.title}, page ${c.page}`}
          className="mx-0.5 inline-flex h-[18px] min-w-[18px] items-center justify-center rounded bg-paper px-1 align-[2px] text-[11px] font-bold text-you ring-1 ring-line"
        >
          {c.ref}
        </a>
      )
    }
    return <Fragment key={k}>{part}</Fragment>
  })
}

export default function Answer({ id, content, citations }: { id: number; content: string; citations: Citation[] }) {
  const cites = new Map(citations.map((c) => [c.ref, c]))
  const blocks: ReactNode[] = []
  let list: { type: 'ul' | 'ol'; items: string[] } | null = null
  const flush = () => {
    if (!list) return
    const Tag = list.type
    blocks.push(
      <Tag key={`l${blocks.length}`}>
        {list.items.map((it, i) => (
          <li key={i}>{inline(it, cites, `${id}-l${blocks.length}-${i}`)}</li>
        ))}
      </Tag>,
    )
    list = null
  }
  content.split('\n').forEach((raw, i) => {
    const line = raw.trimEnd()
    const bullet = line.match(/^\s*[-*•]\s+(.*)$/)
    const numbered = line.match(/^\s*\d+[.)]\s+(.*)$/)
    if (bullet || numbered) {
      const type = bullet ? 'ul' : 'ol'
      if (list && list.type !== type) flush()
      if (!list) list = { type, items: [] }
      list.items.push((bullet ?? numbered)![1])
      return
    }
    flush()
    if (line.trim()) blocks.push(<p key={`p${i}`}>{inline(line, cites, `${id}-p${i}`)}</p>)
  })
  flush()

  return (
    <div>
      <div className="prose-answer">{blocks}</div>
      {citations.length > 0 && (
        <ol className="mt-3 space-y-1.5 border-t border-line pt-3 text-sm">
          {citations.map((c) => (
            <li key={c.ref} id={`cite-${id}-${c.ref}`} className="flex gap-2 text-ink-2">
              <span className="font-bold text-you">{c.ref}</span>
              <FileText size={15} className="mt-0.5 shrink-0" aria-hidden />
              <span>
                <span className="font-bold text-ink">{c.title}</span>, page {c.page}
                <span className="block text-xs text-muted">“{c.snippet.slice(0, 160)}…”</span>
              </span>
            </li>
          ))}
        </ol>
      )}
    </div>
  )
}
