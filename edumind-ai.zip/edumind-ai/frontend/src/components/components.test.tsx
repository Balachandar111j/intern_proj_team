import { render, screen } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'
import { describe, expect, it } from 'vitest'
import type { Mastery, Prediction } from '../api/client'
import Answer from './Answer'
import RiskSummary from './RiskSummary'
import TopicRoute from './TopicRoute'

const prediction: Prediction = {
  id: 1,
  risk_level: 'high',
  risk_probability: 0.74,
  as_of_day: 90,
  model_version: 'xgboost-test',
  algorithm: 'xgboost',
  data_source: 'synthetic',
  thresholds: { high: 0.4, medium: 0.16 },
  created_at: '2026-10-20T10:00:00',
  factors: [
    { feature: 'avg_score', label: 'Average score', value: 43, typical: 66, contribution: 1.6, direction: 'increases_risk', reason: 'Average assessment score 43% (typical 66%)' },
    { feature: 'active_days', label: 'Active days', value: 50, typical: 44, contribution: -0.4, direction: 'decreases_risk', reason: 'Active on 50 days so far (typical 44)' },
  ],
}

describe('RiskSummary', () => {
  it('states the risk in words and shows reasons in both directions', () => {
    render(<RiskSummary prediction={prediction} />)
    expect(screen.getByRole('heading', { level: 1 })).toHaveTextContent('high risk')
    expect(screen.getByText('74%')).toBeInTheDocument()
    expect(screen.getByText(/Average assessment score 43%/)).toBeInTheDocument()
    expect(screen.getByText(/Active on 50 days/)).toBeInTheDocument()
  })
})

describe('Answer', () => {
  it('renders citations as links and never injects HTML', () => {
    const { container } = render(
      <Answer
        id={5}
        content={'**Precision** is about flagged cases [1].\n- point <img src=x onerror=alert(1)>\n- invented [9]'}
        citations={[{ ref: 1, document_id: 2, title: 'Course notes', page: 6, snippet: 'Precision is the share…', similarity: 0.4 }]}
      />,
    )
    expect(container.querySelector('strong')).toHaveTextContent('Precision')
    expect(container.querySelector('img')).toBeNull()
    expect(screen.getByTitle('Course notes, page 6')).toHaveAttribute('href', '#cite-5-1')
    expect(container.textContent).not.toContain('[9]')
  })
})

describe('TopicRoute', () => {
  it('labels each topic status in words, not colour alone', () => {
    const topics: Mastery[] = [
      { topic_id: 1, title: 'Python', sequence: 1, status: 'weak', mastery: 0.4, class_mastery: 0.7, evidence: [], weak_prerequisites: [], next_due_day: null },
      { topic_id: 2, title: 'Pandas', sequence: 2, status: 'upcoming', mastery: null, class_mastery: null, evidence: [], weak_prerequisites: ['Python'], next_due_day: 120 },
    ]
    render(
      <MemoryRouter>
        <TopicRoute topics={topics} />
      </MemoryRouter>,
    )
    expect(screen.getByText('Needs work')).toBeInTheDocument()
    expect(screen.getByText('Coming up')).toBeInTheDocument()
    expect(screen.getByText('Builds on Python')).toBeInTheDocument()
  })
})
