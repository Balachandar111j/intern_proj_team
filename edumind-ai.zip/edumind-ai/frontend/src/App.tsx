import { lazy, Suspense, type ReactNode } from 'react'
import { BrowserRouter, Link, Navigate, Route, Routes } from 'react-router-dom'
import type { Role } from './api/client'
import { AuthProvider, homeFor, useAuth } from './auth/AuthContext'
import Shell from './components/Shell'
import { Loading } from './components/ui'
import Login from './pages/Login'
import Register from './pages/Register'

// Pages load on demand, so the login screen doesn't download the charting library.
const Admin = lazy(() => import('./pages/Admin'))
const FacultyClass = lazy(() => import('./pages/FacultyClass'))
const FacultyStudent = lazy(() => import('./pages/FacultyStudent'))
const StudentOverview = lazy(() => import('./pages/StudentOverview'))
const StudentTopics = lazy(() => import('./pages/StudentTopics'))
const Tutor = lazy(() => import('./pages/Tutor'))

/** Client-side guard for navigation only; the API enforces every permission itself. */
function RequireRole({ role, children }: { role: Role; children: ReactNode }) {
  const { user, ready } = useAuth()
  if (!ready) return <Loading />
  if (!user) return <Navigate to="/login" replace />
  if (user.role !== role) return <Navigate to={homeFor(user.role)} replace />
  return (
    <Shell>
      <Suspense fallback={<Loading />}>{children}</Suspense>
    </Shell>
  )
}

function Home() {
  const { user, ready } = useAuth()
  if (!ready) return <Loading />
  return <Navigate to={user ? homeFor(user.role) : '/login'} replace />
}

function NotFound() {
  return (
    <div className="mx-auto max-w-md px-6 py-20">
      <h1 className="text-2xl font-bold">This page doesn’t exist.</h1>
      <p className="mt-2 text-ink-2">
        Check the address, or{' '}
        <Link to="/" className="font-bold text-you underline-offset-2 hover:underline">
          go to your dashboard
        </Link>
        .
      </p>
    </div>
  )
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/app" element={<RequireRole role="student"><StudentOverview /></RequireRole>} />
          <Route path="/app/topics" element={<RequireRole role="student"><StudentTopics /></RequireRole>} />
          <Route path="/app/tutor" element={<RequireRole role="student"><Tutor /></RequireRole>} />
          <Route path="/faculty" element={<RequireRole role="faculty"><FacultyClass /></RequireRole>} />
          <Route path="/faculty/tutor" element={<RequireRole role="faculty"><Tutor /></RequireRole>} />
          <Route
            path="/faculty/courses/:courseId/students/:studentId"
            element={<RequireRole role="faculty"><FacultyStudent /></RequireRole>}
          />
          <Route path="/admin" element={<RequireRole role="admin"><Admin /></RequireRole>} />
          <Route path="/admin/tutor" element={<RequireRole role="admin"><Tutor /></RequireRole>} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  )
}
