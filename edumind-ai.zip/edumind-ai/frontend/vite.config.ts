/// <reference types="vitest/config" />
import tailwindcss from '@tailwindcss/vite'
import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

const API = process.env.VITE_API_PROXY ?? 'http://127.0.0.1:8000'

// In development, Vite proxies API calls to FastAPI so the browser sees one origin
// (cookie sessions work without CORS). In production FastAPI serves the built files.
export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    proxy: {
      '/api': API,
      '/health': API,
      '/ready': API,
      '/docs': API,
      '/openapi.json': API,
    },
  },
  test: {
    environment: 'jsdom',
    setupFiles: ['./src/test-setup.ts'],
  },
})
